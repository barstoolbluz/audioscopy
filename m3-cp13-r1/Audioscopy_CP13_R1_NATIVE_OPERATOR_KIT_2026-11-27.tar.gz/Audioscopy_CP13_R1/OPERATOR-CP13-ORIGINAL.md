# CP13 consolidated native operator qualification

CP7 patched native Threadripper source is the frozen baseline. CP8 through CP12 are integrated in the candidate. This run replaces separate CP8, CP9, CP10, CP11 and CP12 operator invocations. Run once on each native architecture, then return both evidence archives and their checksums. Do not promote an optional backend by default from source review alone.

Requirements: Python >=3.10, Rust 1.99.1 with rustfmt and Clippy, native GCC/Clang and ar, GNU time on Linux or BSD time on macOS. Native Linux x86-64 and AArch64, macOS arm64/x86-64. No Rosetta or compiler overrides. Dependencies may download on the first invocation. Choose a quiet allowed CPU on Linux, with its sibling idle. The pinned CP7 Nix shell is also supported; omit `rustup run 1.99.1` inside it.

```sh
python3 -B qualification-cp13/qualify_cp13.py --verify-only
(cd qualification-cp7 && python3 -B -m unittest -v test_runner)
# Threadripper:
rustup run 1.99.1 python3 -B qualification-cp13/qualify_cp13.py \
  --work "$HOME/audioscopy-qualification/cp13-portable" --cpu 1 \
  --format-candidate --layout-control --long --perf
# M3:
rustup run 1.99.1 python3 -B qualification-cp13/qualify_cp13.py \
  --work "$HOME/audioscopy-qualification/cp13-m3-portable" \
  --format-candidate --layout-control --long
```

The explicit `--format-candidate` option runs pinned rustfmt on a copy, never the delivered input. It retains the unified patch, complete formatted source archive and exact source manifest in stage 04. It refuses any changes to the previously qualified ordinary Rust DSP or the dependency locks. All subsequent gates use that exact formatted source. No Clippy fixes or numerical changes are applied automatically. The option avoids a formatting-only operator bounce; a format failure is a failed gate and the unmodified source may still be investigated. Omit the option if qualifying the archive exactly as delivered (format checking still runs).

Stage receipts distinguish hygiene, independent default/all/feature builds, ordinary baseline and ISA parity, wide public spectrum, cross-spectrum, explicit noise-passage and integrated loudness references, native C references, environment isolation, individual paired performance cohorts and optional perf. The new NEON precision mode (8) must execute on native AArch64 and reproduce scalar DD limbs. The existing ordinary NEON implementation has separate dispatch checks. A failed gate does not suppress unrelated later gates; unavailable dependencies or binaries are reported. Re-run the **identical** command to reuse successful verified stage receipts and retain failed attempts. Any changed source, toolchain, flags, options or architecture requires a new `--work` directory. `--codegen native` is a separate Rust codegen cohort. The C kernels keep the same controlled C flags in either cohort.

`--long` adds 60-second high-rate wide spectrum/cross/loudness cohorts. `--perf` is optional: unavailable counters do not invalidate numerical qualification. Return the EVIDENCE archive printed by the runner and its `.sha256`, including failures if any. Preserve the input engineering archive separately. Do not equate a PASS with TonePoet integration or a universal resolution guarantee.
