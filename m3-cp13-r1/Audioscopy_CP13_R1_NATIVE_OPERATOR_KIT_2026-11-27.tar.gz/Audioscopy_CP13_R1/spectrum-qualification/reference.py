#!/usr/bin/env python3
"""Independent exact-input Decimal spectrum oracle.

Full complex decimation-in-frequency FFT (different graph from packed-real
kernel), Machin pi, Taylor sine/cosine, direct DFT spot checks. No third-party
packages. Compare C shared objects or public Rust spectrum_f64le driver.
"""
import argparse
import ctypes as c
import decimal as d
import functools
import gzip
import hashlib
import json
import math
from pathlib import Path
import random
import struct
import subprocess
import tempfile

D=d.Decimal
MODES={1:'dd-auto',2:'x87',3:'dd-portable',4:'dd-fma',5:'research-f64',6:'dd-avx2',7:'dd-avx512',8:'dd-neon'}


def atan_inv(n):
    x=D(1)/n; x2=x*x; a=x; total=a; k=1
    while True:
        a=-a*x2; next_=total+a/(2*k+1)
        if next_==total:return total
        total=next_;k+=1


@functools.lru_cache(maxsize=None)
def pi(prec):
    with d.localcontext() as ctx:
        ctx.prec=prec+10
        p=16*atan_inv(5)-4*atan_inv(239)
        ctx.prec=prec
        return +p


def sincos(x):
    # Arguments bounded by pi; independently sum sine and cosine series.
    a=x; b=D(1); s=a; t=b; k=1; xx=-x*x
    while True:
        a=a*xx/(2*k*(2*k+1)); b=b*xx/((2*k-1)*2*k)
        ns=s+a; nt=t+b
        if ns==s and nt==t:return s,t
        s=ns;t=nt;k+=1


@functools.lru_cache(maxsize=16)
def coefficients(n,prec):
    with d.localcontext() as ctx:
        ctx.prec=prec
        p=pi(prec); w=[]; roots=[]
        for i in range(n):
            a=sincos(p*(D(i)+D('0.5'))/n)[0]
            w.append(sincos(p*a*a/2)[0])
        for i in range(n//2):
            if i==0: roots.append((D(1),D(0)))
            elif i==n//4: roots.append((D(0),D(-1)))
            else:
                sn,cs=sincos(-2*p*i/n); roots.append((cs,sn))
        return w,roots


def cmul(a,b):return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])


def fft_dif(x,roots):
    n=len(x); a=[(v,D(0)) for v in x]; span=n
    while span>=2:
        h=span//2; stride=n//span
        for off in range(0,n,span):
            for j in range(h):
                i=off+j; k=i+h; u=a[i];v=a[k]
                a[i]=(u[0]+v[0],u[1]+v[1]); a[k]=cmul((u[0]-v[0],u[1]-v[1]),roots[j*stride])
        span//=2
    out=[None]*n; bits=n.bit_length()-1
    for k,v in enumerate(a):out[int(f'{k:0{bits}b}'[::-1],2)]=v
    return out


def direct_bin(x,roots,k):
    n=len(x); r=D(0);i=D(0)
    for j,v in enumerate(x):
        idx=(k*j)%n; sign=1 if idx<n//2 else -1; a,b=roots[idx%(n//2)]
        r+=sign*v*a;i+=sign*v*b
    return r,i


def fft_len(rate):return 1<<(((rate+5)//6-1).bit_length())


def oracle(pcm,rate,ch,prec,spot=True):
    with d.localcontext() as ctx:
        ctx.prec=prec
        n=fft_len(rate);h=n//2;length=len(pcm)//ch; w,roots=coefficients(n,prec)
        grid=[D.from_float(x) for x in pcm]; sums=[D(0)]*(h+1)
        for start in range(-h,length,h):
            for channel in range(ch):
                x=[grid[(start+i)*ch+channel]*w[i] if 0<=start+i<length else D(0) for i in range(n)]
                a=fft_dif(x,roots)
                if spot:
                    for k in (0,1,n//7,h-1,h):
                        b=direct_bin(x,roots,k)
                        scale=max(max(map(abs,x)),D('1e-1000'))
                        assert max(abs(a[k][j]-b[j]) for j in (0,1))<scale*D(10)**(-prec+7),(k,a[k],b)
                for k in range(h+1):
                    r,i=a[k];sums[k]+=(r*r+i*i)*(1 if k in (0,h) else 2)
        norm=D(n)*ch*length
        bins=[p/norm for p in sums]
        expected=sum(x*x for x in grid)/(ch*length)
        assert abs(sum(bins)-expected)<=max(expected,D('1e-1000'))*D(10)**(-prec+7)
        return bins,expected


def fixtures():
    rng=random.Random(0x435038)
    rate=8000;n=fft_len(rate);h=n//2
    yield 'silence',rate,1,[0.0]*(h+5)
    yield 'short_stereo',rate,2,[rng.randrange(-2**23,2**23)*2.**-23 for _ in range(2*17)]
    yield 'pcm32_three_channel',rate,3,[rng.randrange(-2**31,2**31)*2.**-31 for _ in range(3*(h+137))]
    yield 'irregular_partial',12001,1,[0.5,-0.25,0.125,0.0,2.**-40]*247
    yield 'dc_edge',rate,1,[0.75]*(n+19)
    # Two equal symmetric pairs in the first half-hop. Both overlapping
    # windows have the same exact DC sum. Round only the designed sample
    # coefficients to binary64; oracle evaluates that exact input, not the
    # ideal mathematical null. Real residual is far below typical leakage.
    with d.localcontext() as ctx:
        ctx.prec=100;w,_=coefficients(n,100);i=h//8;j=h//3
        a=D('0.5');b=-a*(w[i]+w[h-1-i])/(w[j]+w[h-1-j]);x=[0.0]*h
        x[i]=x[h-1-i]=float(a);x[j]=x[h-1-j]=float(b)
    yield 'near_null_dc',rate,1,x
    tiny=float.fromhex('0x0.0000000000001p-1022')
    yield 'subnormal_only',rate,1,[tiny,-tiny,3*tiny,0.0,5*tiny]*31
    yield 'scale_jump',rate,1,[tiny,-tiny]*(h//2)+[0.5,-0.25,0.125]*37


class Bin(c.Structure):
    _fields_=[('hi',c.c_double),('lo',c.c_double),('exponent',c.c_int32)]


class Kernel:
    def __init__(self,path):
        self.lib=c.CDLL(str(Path(path).resolve()));l=self.lib
        l.audioscopy_spectral_available.argtypes=[c.c_int];l.audioscopy_spectral_available.restype=c.c_int
        l.audioscopy_spectral_new.argtypes=[c.c_uint32,c.c_size_t,c.c_int,c.POINTER(c.c_void_p),c.POINTER(c.c_size_t),c.POINTER(c.c_int)];l.audioscopy_spectral_new.restype=c.c_int
        l.audioscopy_spectral_push.argtypes=[c.c_void_p,c.POINTER(c.c_double),c.c_size_t];l.audioscopy_spectral_push.restype=c.c_int
        l.audioscopy_spectral_finish.argtypes=[c.c_void_p,c.POINTER(Bin),c.c_size_t];l.audioscopy_spectral_finish.restype=c.c_int
        l.audioscopy_spectral_free.argtypes=[c.c_void_p];l.audioscopy_spectral_free.restype=None
    def available(self,mode):return bool(self.lib.audioscopy_spectral_available(mode))
    def new(self,rate,ch,mode):
        p=c.c_void_p();n=c.c_size_t();actual=c.c_int()
        assert self.lib.audioscopy_spectral_new(rate,ch,mode,c.byref(p),c.byref(n),c.byref(actual))==1
        return p,n.value,actual.value
    def run(self,pcm,rate,ch,mode,chunk):
        p,n,actual=self.new(rate,ch,mode)
        try:
            assert n==fft_len(rate)
            data=(c.c_double*len(pcm))(*pcm)
            for start in range(0,len(pcm)//ch,chunk):
                take=min(chunk,len(pcm)//ch-start)
                ptr=c.cast(c.byref(data,start*ch*8),c.POINTER(c.c_double))
                assert self.lib.audioscopy_spectral_push(p,ptr,take)==1
            bins=(Bin*(n//2+1))();assert self.lib.audioscopy_spectral_finish(p,bins,len(bins))==1
            return actual,[(b.hi,b.lo,b.exponent) for b in bins]
        finally:self.lib.audioscopy_spectral_free(p)


class Driver:
    def __init__(self,path):self.path=Path(path).resolve()
    def available(self,mode):
        return str(mode) in subprocess.check_output([str(self.path),'--available'],text=True).split()
    def run(self,pcm,rate,ch,mode,chunk):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'pcm.f64le';p.write_bytes(struct.pack(f'<{len(pcm)}d',*pcm))
            out=subprocess.check_output([str(self.path),str(mode),str(rate),str(ch),str(chunk),str(p)],text=True).splitlines()
        head=out[0].split();assert head[0]=='SPECTRUM' and int(head[2])==fft_len(rate) and int(head[3])==len(pcm)//ch
        return int(head[1]),[(struct.unpack('>d',bytes.fromhex(r))[0],struct.unpack('>d',bytes.fromhex(l))[0],int(e)) for r,l,e in (s.split() for s in out[1:])]


def signature(bins):
    return b''.join(struct.pack('<ddi',*b) for b in bins)


def decimal_power(b):
    hi,lo,e=b
    assert math.isfinite(hi) and math.isfinite(lo) and (hi==0 or .5<=hi<=1.0) and abs(lo)<=math.ulp(hi)
    assert hi>=0 and (hi!=0 or lo==0)
    return (D.from_float(hi)+D.from_float(lo))*D(2)**e



def store_record(directory,name,mode,bins):
    raw=signature(bins);digest=hashlib.sha256(raw).hexdigest()
    if directory:
        directory.mkdir(parents=True,exist_ok=True)
        with gzip.open(directory/f"{name}-{mode}.bin.gz","wb") as f:f.write(raw)
    return digest


def large_sparse(lib,modes,records_dir):
    rate=768000;n=fft_len(rate);h=n//2;frames=h+23;ch=2
    impulses=[(0,0,.5),(13,1,-.25),(h//3,0,.125),(h//3,1,-.375),
              (h-1,0,2.**-45),(h,1,.25),(h+22,0,-.5),(h+21,1,.125)]
    pcm=[0.0]*(frames*ch)
    for pos,c,v in impulses:pcm[pos*ch+c]=v
    chosen=[0,1,17,n//13,n//4-1,n//4,n//4+1,h-1,h]
    with d.localcontext() as ctx:
        ctx.prec=105;p=pi(105);expected=sum(D.from_float(v)**2 for _,_,v in impulses)/(frames*ch);ref={k:D(0) for k in chosen}
        for start in range(-h,frames,h):
            for c in range(ch):
                data=[]
                for pos,channel,v in impulses:
                    if channel!=c or not 0<=pos-start<n:continue
                    i=pos-start;a=sincos(p*(D(i)+D('0.5'))/n)[0];w=sincos(p*a*a/2)[0];data.append((i,D.from_float(v)*w))
                for k in chosen:
                    re=D(0);im=D(0)
                    for i,v in data:
                        j=(i*k)%n
                        if j>h:j-=n
                        sn,cs=sincos(-2*p*j/n);re+=v*cs;im+=v*sn
                    ref[k]+=(re*re+im*im)*(1 if k in (0,h) else 2)/(n*frames*ch)
        scalar_fma=None
        for mode in modes:
            actual,bins=lib.run(pcm,rate,ch,mode,4093)
            assert len(bins)==h+1
            actual2,bins2=lib.run(pcm,rate,ch,mode,1025)
            assert actual==actual2 and signature(bins)==signature(bins2)
            if mode in (3,4):scalar_fma=signature(bins)
            if mode in (6,7,8) and scalar_fma is not None:assert signature(bins)==scalar_fma
            powers=[decimal_power(b) for b in bins]
            energy_error=abs(sum(powers)-expected)/expected
            selected_error=max(abs(powers[k]-ref[k]) for k in chosen)/max(ref.values())
            limit=D('3e-16') if mode==2 else D('3e-28') if mode!=5 else D('3e-13')
            assert energy_error<limit and selected_error<limit,(mode,energy_error,selected_error)
            print(json.dumps(dict(fixture='large_sparse_direct',mode=MODES[mode],actual=actual,frames=frames,rate=rate,channels=ch,selected_bins=chosen,selected_reference={str(k):str(ref[k]) for k in chosen},bins_sha256=store_record(records_dir,'large_sparse_direct',mode,bins),max_relative_to_peak=str(selected_error),parseval_relative_error=str(energy_error))),flush=True)
    return len(modes)


def main():
    ap=argparse.ArgumentParser();ap.add_argument('path');ap.add_argument('--driver',action='store_true');ap.add_argument('--quick',action='store_true');ap.add_argument('--records-dir',type=Path);args=ap.parse_args()
    lib=Driver(args.path) if args.driver else Kernel(args.path)
    modes=[m for m in MODES if lib.available(m)]; assert 1 in modes and 3 in modes
    rows=0
    for name,rate,ch,pcm in fixtures():
        if args.quick and name not in ('near_null_dc','subnormal_only','short_stereo'):continue
        ref,expected=oracle(pcm,rate,ch,88); check,_=oracle(pcm,rate,ch,112,False)
        with d.localcontext() as ctx:
            ctx.prec=112
            peak=max(ref);norm=max(peak,D('1e-1000'))
            assert max(abs(a-b) for a,b in zip(ref,check))<=norm*D('1e-78')
            scalar_fma=None
            for mode in modes:
                actual,bins=lib.run(pcm,rate,ch,mode,127)
                assert len(bins)==len(ref)
                other=lib.run(pcm,rate,ch,mode,4093)
                assert actual==other[0] and signature(bins)==signature(other[1]),(name,mode,'chunk parity')
                if mode in (3,4):scalar_fma=signature(bins)
                if mode in (6,7,8) and scalar_fma is not None:assert signature(bins)==scalar_fma,(name,mode,"vector graph parity")
                powers=[decimal_power(b) for b in bins]
                error=max(abs(a-b) for a,b in zip(powers,check))/norm
                energy_error=abs(sum(powers)-expected)/max(expected,D('1e-1000'))
                dc_error=abs(powers[0]-check[0])/max(abs(check[0]),D('1e-1000'))
                limit=D('3e-16') if mode==2 else D('3e-28') if mode!=5 else D('3e-13')
                assert error<limit and energy_error<limit,(name,mode,error,energy_error)
                if name=='near_null_dc' and mode in (1,3,4,6,7,8):assert dc_error<D('2e-12'),(name,mode,dc_error)
                if name=='near_null_dc' and mode==2:assert dc_error<D('0.01'),(name,mode,dc_error)
                row=dict(fixture=name,mode=MODES[mode],actual=actual,frames=len(pcm)//ch,rate=rate,channels=ch,max_relative_to_peak=str(error),parseval_relative_error=str(energy_error),dc_reference=str(check[0]),dc_power=str(powers[0]),dc_relative_error=str(dc_error),bins_sha256=store_record(args.records_dir,name,mode,bins))
                print(json.dumps(row),flush=True);rows+=1
    if not args.quick:rows+=large_sparse(lib,modes,args.records_dir)
    print(f'SPECTRUM_REFERENCE_PASS {rows} comparisons',flush=True)

if __name__=='__main__':main()
