/* SPDX-License-Identifier: GPL-2.0-or-later
 * Native environment isolation, independent allocations and concurrency.
 * On x86 compare the exact control/status words and MXCSR before and after
 * every call, including forced 24-bit x87, FTZ, DAZ and sticky exceptions.
 */
#define _POSIX_C_SOURCE 200809L
#include <fenv.h>
#include <math.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../audioscopy/native/spectral_precision.h"
static void check(int ok) { if(!ok){fputs("environment test failed\n",stderr);abort();} }
struct environment { int round,flags;
#if defined(__x86_64__)
    unsigned short cw,sw; unsigned int mxcsr;
#endif
};
static struct environment snapshot(void) {
    struct environment e={0};e.round=fegetround();e.flags=fetestexcept(FE_ALL_EXCEPT);
#if defined(__x86_64__)
    __asm__ volatile("fnstcw %0" : "=m"(e.cw) :: "memory");
    __asm__ volatile("fnstsw %0" : "=am"(e.sw) :: "memory");
    __asm__ volatile("stmxcsr %0" : "=m"(e.mxcsr) :: "memory");
#endif
    return e;
}
static void same(struct environment a) {
    struct environment b=snapshot();check(a.round==b.round && a.flags==b.flags);
#if defined(__x86_64__)
    check(a.cw==b.cw && a.sw==b.sw && a.mxcsr==b.mxcsr);
#endif
}
struct worker { int round,mode;const struct ac_spectral_bin *reference;const double *pcm; };
static void *run(void *v) {
    struct worker *w=v;fenv_t initial;check(fegetenv(&initial)==0);check(fesetround(w->round)==0);
    check(feraiseexcept(FE_INEXACT|FE_UNDERFLOW)==0);
#if defined(__x86_64__)
    unsigned short cw;unsigned int mxcsr;
    __asm__ volatile("fnstcw %0" : "=m"(cw) :: "memory");cw&=~0x0300u;
    __asm__ volatile("fldcw %0" :: "m"(cw) : "memory");
    __asm__ volatile("stmxcsr %0" : "=m"(mxcsr) :: "memory");mxcsr|=0x8040u;
    __asm__ volatile("ldmxcsr %0" :: "m"(mxcsr) : "memory");
#endif
    struct environment e=snapshot();
    for(int repeat=0;repeat<8;++repeat){
        void *p=NULL;size_t n=0;int actual=0;struct ac_spectral_bin out[1025];
        check(audioscopy_spectral_new(8000,2,w->mode,&p,&n,&actual)==1 && n==2048);same(e);
        check(audioscopy_spectral_push(p,w->pcm,7)==1);same(e);
        check(audioscopy_spectral_push(p,w->pcm+14,1040)==1);same(e);
        check(audioscopy_spectral_finish(p,out,1025)==1);same(e);
        for(size_t k=0;k<1025;++k){
            check(memcmp(&out[k].hi,&w->reference[k].hi,sizeof(double))==0);
            check(memcmp(&out[k].lo,&w->reference[k].lo,sizeof(double))==0);
            check(out[k].exponent==w->reference[k].exponent);
        }
        audioscopy_spectral_free(p);same(e);
    }
    check(fesetenv(&initial)==0);return NULL;
}
int main(void){
    double pcm[2094];uint32_t rng=0x3e14b7c1u;
    for(size_t i=0;i<2094;++i){rng=rng*1664525u+1013904223u;pcm[i]=((double)(rng>>8)-8388608.0)*0x1p-24;}
    pcm[0]=0x0.0000000000001p-1022;pcm[1]=-0x0.0000000000001p-1022;
    const int rounds[]={FE_TONEAREST,FE_DOWNWARD,FE_UPWARD,FE_TOWARDZERO};int tested=0;
    for(int mode=1;mode<=8;++mode){
        if(mode==5 || !audioscopy_spectral_available(mode))continue;
        void *p=NULL;size_t n=0;int actual=0;struct ac_spectral_bin reference[1025];
        check(audioscopy_spectral_new(8000,2,mode,&p,&n,&actual)==1);
        check(audioscopy_spectral_push(p,pcm,1047)==1);check(audioscopy_spectral_finish(p,reference,1025)==1);audioscopy_spectral_free(p);
        pthread_t threads[4];struct worker workers[4];
        for(int j=0;j<4;++j){workers[j]=(struct worker){rounds[j],mode,reference,pcm};check(pthread_create(&threads[j],NULL,run,&workers[j])==0);}
        for(int j=0;j<4;++j)check(pthread_join(threads[j],NULL)==0);
        ++tested;
    }
    printf("SPECTRAL_ENVIRONMENT_PASS %d backends, %d independent concurrent plans, exact bin limbs and caller environment\n",tested,tested*32);return 0;
}
