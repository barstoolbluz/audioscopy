#!/usr/bin/env python3
"""Independently check the nearest-limb split of every DD coefficient."""
from fractions import Fraction
from math import factorial
from pathlib import Path
import re
from reference import pi
p=Path(__file__).resolve().parent.parent/'audioscopy/native/spectral_constants.h'
pairs=re.findall(r'\{\s*(-?0x[\da-f.]+p[+-]\d+),\s*(-?0x[\da-f.]+p[+-]\d+)\s*\}',p.read_text())
exact=[Fraction(pi(160))/2]+[Fraction((-1)**k,factorial(2*k+1)) for k in range(20)]
assert len(pairs)==len(exact)
for value,(h,l) in zip(exact,pairs):
    hi=float(value);lo=float(value-Fraction(hi))
    assert (hi,lo)==(float.fromhex(h),float.fromhex(l)),(h,l,hi.hex(),lo.hex())
print('CONSTANTS_PASS',len(exact))
