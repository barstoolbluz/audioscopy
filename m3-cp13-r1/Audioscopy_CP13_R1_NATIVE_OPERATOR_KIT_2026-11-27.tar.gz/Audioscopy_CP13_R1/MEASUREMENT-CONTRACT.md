# Round 1 measurement contract and implementation crosswalk

Date: 2026-11-25. Governing document: `tonepoet-advanced-analysis-inventory-v2.md`,
§3.1–3.6. The table maps the requested rows to the delivered API and test
fixtures. The numerical thresholds below are engineering decisions, not
previously specified owner choices. Their reliability must be qualified with
real programme fixtures before claiming a production classifier is calibrated.

| Inventory row | File result / method | Album rule | Known-answer test in `audioscopy/tests/measurements.rs` |
|---|---|---|---|
| Loudness range | Existing native EBU Tech 3342 LRA | Continuous same-clock/role meter via `AlbumAnalyzer`; cached multiple tracks/mixed formats unavailable | `loudness_range_and_ungated_short_term`; `continuous_album_loudness_and_ordered_curves` |
| Short-term maximum | Max ungated complete 3 s observation at rational 100 ms hops | Max eligible track | Same loudness tests |
| Loudness over time | End time/LUFS curve, no artificial EOF graph windows | Ordered track curves | Same loudness tests |
| Limiting | Count of 50 ms sample-peak blocks ≥−1 dB relative to track max / all blocks × 100 | Duration-weighted mean | `limiting_and_flat_extrema`; `album_dynamics_bits_source_pattern_spectrum` |
| Flat-topped peaks | Per-channel local plateau count, ≥3 near-equal samples within 1 dB of track maximum | Sum | Same dynamics tests |
| Bits in use | Low-bit OR + exact affine GCD grid; float normalized grid test | Highest comparable integer depth; noninteger-only or mixed grids explicit | `exact_bits_padding_affine_grid_float_and_silence`; album dynamics test |
| Effective bits | Approximate noise-derived resolution, not source bit depth | Pooled quiet floor (provisional inventory rule) | `quiet_floor_range_bits_spectrum_tone_and_bands`; album pooled noise test |
| Likely source rate | Steep occupied cutoff near a standard lower source Nyquist; otherwise reason | Most common inferred rate, tie mixed | `spectral_cutoff_and_codec_pattern`; album dynamics test |
| Lossy coding pattern | Lowpass shelf or occupied-adjacent spectral gaps; pattern only | Number found / total tracks | Same spectral tests |
| Bandwidth | Highest materially occupied spectral bin (kHz) | Minimum track | `spectrum_power_bandwidth_and_above_twenty`; album dynamics test |
| Above 20 kHz | Power above 20 kHz / total, n/a at Nyquist ≤22.05 kHz | Pooled linear energy ratio over applicable tracks | Same spectrum and album dynamics tests |
| Average spectrum | One-sided long-term power density | Duration-pooled power spectrum, native clocks mapped to finest display grid | Same spectrum and album dynamics tests |
| Noise floor | Weighted/banded pooled quiet mean square | Pool qualifying quiet time | `quiet_floor_range_bits_spectrum_tone_and_bands`; `cached_noise_reweight_reband_and_five_bands`; album pooled noise test |
| Dynamic range | Absolute sample peak level minus quiet floor | Maximum album peak to pooled floor | Same noise tests |
| Noise spectrum | Weighted/banded quiet power density curve | Pooled quiet spectrum | Same noise tests |
| Hum and idle tones | Largest narrow spectral line with frequency and line power, or no detected tone | Largest eligible track line | Same noise tests |
| Noise by band | Integrated weighted power in the five listed bands, outside view n/a | Pool quiet power in each band | Same noise tests |
| Clicks per minute | Local prediction-error impulses / real minutes | Total events / total duration | `clicks_and_dither_evidence`; album pooled noise test |
| Dither | Quiet exact binary grid, peak/sign evidence and spectrum; none/flat/shaped or reason | Most common identified classification; tie mixed | Same clicks/dither and album pooled noise tests |
| Correlation | Mean-removed Pearson correlation | Duration-weighted mean | `stereo_relationships_delay_and_bass_width`; `album_stereo_rules` |
| Balance | Signed left/right energy ratio dB | Real-time channel-energy sums | Same stereo tests |
| Width | Side/mid energy ratio dB | Duration-weighted arithmetic mean of track dB | Same stereo tests |
| Mono compatibility | Nonnegative level lost by averaging L/R | Worst eligible track | Same stereo tests |
| Inter-channel delay | Upper-band cross-correlation, interpolated lag in µs; no unique peak → reason | Median identified track | Same stereo tests |
| Bass width | First material side energy after occupied mono bass bands; `Full` if no mono region | Median track cutoff (Full treated as 0 Hz) | Same stereo tests |

## Exact and heuristic conventions

- **Loudness:** The new ungated short-term meter uses the same native filter
  coefficient construction and channel weights as existing true-peak. It sums
  30 nonnegative 100 ms energies rather than a subtractive rolling sum. The
  exact native LRA implementation and tests are preserved. An unavailable
  upstream LRA for silence/insufficient windows remains unavailable, even though
  the inventory labels the row “Never.” No valid mathematical number exists for
  that distribution. Full short-term windows start at 3 s.
- **Resolution:** GCD on exact integer codes is an exact affine-grid test, not
  evidence of the source quantizer. Integer code normalization is validated.
  Report the normalized low-bit depth and observed affine-lattice index width
  independently. A nonbinary or offset lattice with at least three positions
  supports the smaller observed width even with incomplete headroom. Two
  distinct values alone do not establish a nontrivial affine subset. An
  aligned coarser binary grid retains the normalized convention except for
  a complete-sized binary span with at least four positions and at least
  as many samples. None of these tests establishes mastering/source depth.
  A gain change followed by rounding can destroy an exact lattice, in which
  case an exact lower source bit depth cannot be inferred. Floats that do not
  fit the normalized grid are reported as noninteger, not guessed to be 24-bit.
- **Spectrum:** half-hop sine-of-Hann squared-complementary windows; fixed
  one-sided Parseval normalization. All real frames, including partial and
  boundary windows, contribute once to the denominator. Cached noise records
  use schema 2; the incorrect schema 1 is rejected.
- **Bandwidth:** relative bin-power threshold −80 dB to the maximum bin. It is
  a content extent estimate; sidelobes, noise, short segments and low-level
  content set its uncertainty. Frequency resolution is roughly 3–6 Hz, not a
  guarantee of cutoff accuracy to a single bin. The base bandwidth uses the
  highest bin in the fully observed windows meeting the full recording's
  −80 dB accumulated bin-power floor. Nonzero interior energy alone is not
  sufficient. Endpoint inference
  uses the Blackman–Harris tapered first/last half-hop and shorter views.
  A candidate must be a local spectral peak at or above −80 dB of both its
  endpoint maximum and the full recording's maximum accumulated power bin.
  Endpoint power uses the same fixed one-sided 1/(N × channels) FFT
  normalization as the retained spectrum; it is not rescaled by endpoint
  duration, level or taper energy. Lower-frequency local peaks remain
  eligible when higher peaks fail the programme-wide test. Extensions must
  still exceed the base by four physical resolution bins. Without a material
  complete-window bin the longest actual-support endpoint view(s)
  establish the base, using the same materiality test. Finite tapers and
  low-level or very short content can still limit cutoff accuracy. Endpoint
  candidates never contribute to the retained spectrum. Source-rate, codec
  and stereo inference still prefer fully observed windows and can
  underrepresent endpoint-only content; measured power includes it.
- **Source rate:** tests standard rates from 8 kHz to 384 kHz whose half-rate
  is at least 6% below current Nyquist; requires energy in four adjacent
  near-edge subbands, an occupied prior band, ≥30 dB mean-density drop above
  the edge and <−40 dB total residual above the edge. A single tone does not
  establish a source Nyquist. Analog rolloff and ambiguous cases are withheld.
- **Lossy pattern:** searches 12–20 kHz codec-like shelves in 1 kHz increments
  with ≥30 dB density drop and sustained low upper energy, plus 500 Hz gaps
  between occupied bands. A pooled signature or at least 3 full-window hits
  in ≥25% of nonzero windows qualifies. Intentional EQ/lowpass can trigger it;
  a high-quality lossy encode can pass without detection. Not proof of codec
  history. Test fixtures exercise known patterns, not codec identification.
- **Hum:** local maximum with ≥16× local background power; integrate the peak
  and neighboring bins, interpolate frequency from log power. DC is bias,
  not a tone; Nyquist line is supported. Applies the view's weighting to the
  line power. A quiet broadband passage with no identifiable narrow peak
  returns `Tone(None)`, not a fabricated frequency.
- **Clicks:** five-frame symmetric local predictor, absolute prediction error
  >0.001 and >8× neighboring sample variation, one counted event per frame
  across channels and 1 ms refractory. Percussive music can trigger false
  positives; this is a lightweight impulsive-defect estimate, not restoration.
- **Dither:** separate candidate quiet runs use at most eight nominal integer
  LSBs or eight LSBs of the largest demonstrable zero-aligned binary grid.
  Candidate grid/peak/sign evidence is merged without retaining PCM. Both
  signs and broadband shape remain required for nonzero dither. Arbitrary
  affine spacing does not establish a binary grid. Exact normalized integer
  grids in float PCM can qualify. Analog noise can mask or mimic dither;
  this is not proof of mastering history.
- **Delay:** cross power of the 2–10 kHz band (upper end also limited to
  0.45×sample rate) is summed over windows; search ±1 ms, require normalized
  |correlation| ≥0.5, upper-band power at least 1e-6 of each channel's full
  power, and no rival >95% outside a main-lobe exclusion, then
  interpolate the absolute peak. Inverted channels can still give a delay;
  pure periodic tones/independent channels may be ambiguous. Search boundary
  maxima are withheld. Positive means the right channel lags.
- **Bass width:** scan 25 Hz bands from DC to 1 kHz. Ignore effectively empty
  bands (relative −80 dB power threshold); side-to-mid power below −30 dB
  indicates mono. First occupied band with material side after mono returns
  its lower boundary. If all occupied bass is mono, `MonoBelow(1000)` is the
  upper search bound. Mono files and other non-stereo layouts are n/a for the
  stereo group, as specified by the interface context.
- **Quiet pooling:** time-weighted bin power; if at least one track supports a
  requested band, tracks with quiet time but no support in that band contribute
  zero power over their quiet duration. If no track supports the band, n/a.
  Effective bits and dynamic range are recomputed under the same view. Weighting
  is frequency response, not an ITU-R 468 quasi-peak detector. Categorical
  dither and click measurements ignore the view. The two-block bounded
  refinement uses aggregate per-channel RMS of actual edge fragments.
  An isolated excursion above eight times threshold amplitude, or a peak
  above twice threshold amplitude in a 1 ms slice with RMS above twice
  threshold, establishes a clear separator. Quiet crests alone do not.
  Half the adjacent quiet block's minimum per-channel energy headroom may
  qualify a partial cycle when its peak is within 3 dB of that neighbor's
  above-threshold crest; no extreme-excursion context is used. Only real
  frames contribute to duration and spectra. If a mixed-block edge fails
  its aggregate test, the detector may trim at most two 1 ms local slices
  from its separator-facing end. The retained contiguous fragment must
  satisfy the adjacent quiet block's existing peak and per-channel RMS
  allowance. The full-fragment and exact instantaneous decisions are
  preserved; no context is borrowed again and the original minimum gap
  is unchanged. A last partial block is still tested as a whole. Near a
  tonal zero crossing, the estimated transition can differ from the
  unknown original boundary by a few samples. Ambiguous low-contrast
  transitions retain the coarse/instantaneous-edge convention.

## Validation scope

Native qualification remains blocked in the corrective delivery environment. The Rust
fixtures are delivered as executable tests and are **not reported as passing**.
The independent NumPy/SciPy script has executed successfully and checks
analytic/known fixture behavior for the main numerical paths; it does not
exercise Rust implementations or establish real-music classifier accuracy.

### K-weighting numerical realization (post-R5 candidate)

The existing native BS.1770 transfer, channel weighting, clocks, gating and continuous-album LRA semantics remain the contract. Audioscopy explicitly opts into a conditioned binary64 realization (difference-driven RLB, trapezoidal-integrator shelf). The full-range follow-up makes the conditioned realization the default for native `true-peak` PCM rates with the shelf below Nyquist; the authorized admission correction rejects nonzero full-meter native rates below 3,364 Hz. `Libebur128126` retains its established arithmetic and historical rate admission, including possible instability below 3,364 Hz. Audioscopy continues to select the same explicit native constructors. No change to other R5 measurements or noise records. Homogeneous filter tails below representable binary64 squared energy may be cleared only on exact zero excitation. See `K-WEIGHTING-REPORT.md` for tested numerical limits and the outstanding native gates.

## Additive CP13 precision contract

The ordinary rows above are unchanged. Optional correlation, average-power spectrum, stereo complex cross-spectrum, explicit quiet-passage floor/band pooling and native integrated loudness have separate public precision APIs. See PER-MEASUREMENT-SUPPORT.md and STAGE11-15-CONSOLIDATED-PRECISION-REPORT.md for definitions, support and limits. Wide cross uses conj(L)*R, independently scaled channels, one-sided auto powers and signed cross components; quiet reduction requires caller-selected independent runs; integrated loudness uses complete native rational-clock observations and typed outcomes. Extended precision does not remove estimator limitations or input quantization. No wide automatic quiet detection, LRA, short-term, album or compatibility contract is asserted.
