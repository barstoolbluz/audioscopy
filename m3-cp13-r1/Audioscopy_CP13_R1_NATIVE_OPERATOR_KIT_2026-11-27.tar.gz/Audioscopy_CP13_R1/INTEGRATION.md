# CP8 integration

Keep sibling crate trees together and locks frozen. CP7 returned hygiene corrections are incorporated and their passed source is preserved separately. No changes to ordinary DSP or true-peak source. CP8 adds optional `precision-spectrum` feature and private native C11 kernels, additive public streaming API and tests; CP7 precision correlation remains unchanged apart from documentation/module registration. Both crates GPL-2.0-or-later. Do not publish or merge as a qualified release until pinned Rust and ARM/target execution pass. Follow OPERATOR.md. For historical integration details see prior-checkpoint/INTEGRATION.md in the engineering archive. TonePoet downstream suite remains required.

## CP13 update

Use the consolidated runner rather than separate historical CP8/CP9/CP10/CP11/CP12 invocations. The existing ordinary path, true-peak crate and dependency locks are preserved. New optional `precision-spectrum` public interfaces are `CrossSpectrumAnalyzer`, `QuietNoiseAnalyzer`, `QuietNoisePool`; optional `precision-loudness` is `WideLoudnessMeter`. Explicit DD NEON spectral mode is experimental. The public `PowerBin` is re-exported from its original spectral module as well as precision root. No changes to TonePoet are included; qualify full downstream integration before release. See CHECKPOINT.md, OPERATOR.md and PER-MEASUREMENT-SUPPORT.md.
