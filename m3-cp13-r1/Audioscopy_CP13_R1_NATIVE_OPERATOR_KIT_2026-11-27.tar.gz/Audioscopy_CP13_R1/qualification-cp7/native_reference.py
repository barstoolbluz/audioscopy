#!/usr/bin/env python3
"""Exact-input dyadic Pearson oracle, stdlib only; tests public Rust driver."""
import argparse
import decimal as d
import json
import math
import pathlib
import random
import struct
import subprocess


def moments(pattern):
    # Per-channel common dyadic denominator; Pearson is scale invariant.
    cols = list(zip(*pattern))
    grids = []
    for col in cols:
        ratios = [x.as_integer_ratio() for x in col]
        denom = max(b for _, b in ratios)
        grids.append([a * (denom // b) for a, b in ratios])
    l, r = grids
    n = len(l)
    return (n * sum(x*x for x in l) - sum(l)**2,
            n * sum(x*x for x in r) - sum(r)**2,
            n * sum(x*y for x, y in zip(l, r)) - sum(l)*sum(r))


def reference(pattern, prec):
    l, r, c = moments(pattern)
    with d.localcontext() as ctx:
        ctx.prec = prec
        return d.Decimal(c) / d.Decimal(l*r).sqrt() if l and r else d.Decimal(0)


def fixtures():
    p = [(0,0),(1,0),(1,1),(0,1),(1,1),(1,1),(0,0)]
    for bits in (16,24,32,54):
        yield f'pcm{bits}_dc', [(0.5+x*2.**(1-bits),0.5+y*2.**(1-bits)) for x,y in p], 10000
    yield 'long_pcm32_7M', [(0.5+x*2.**-31,0.5+y*2.**-31) for x,y in p], 1000000
    for sign in (1,-1):
        for shift in (25,30,40,48):
            yield f'near_{sign:+d}_{shift}', [(x,sign*x+y*2.**-shift) for x,y in [(-.5,-.5),(-.5,.5),(.5,-.5),(.5,.5)]], 16385
    yield 'near_zero', [(x,y+x*2.**-48) for x,y in [(-.5,-.5),(-.5,.5),(.5,-.5),(.5,.5)]], 16385
    for scale in (float.fromhex('0x0.0000000000001p-1022'),2.**-1000,2.**-600):
        yield 'tiny_both_'+scale.hex(), [((1+x)*scale,(1+y)*scale) for x,y in p],1000
        yield 'tiny_one_'+scale.hex(), [((1+x)*scale,y-.5) for x,y in p],1000
    rng = random.Random(0x7D91)
    q = [(rng.randrange(-2**23,2**23)*2.**-23,rng.randrange(-2**23,2**23)*2.**-23) for _ in range(8193)]
    yield 'random_pcm24',q,1
    yield 'scale_jump',[(x*2.**-1000,y*2.**-1000) if i<1024 else (x*2.**-500,y) if i<2048 else (x,y) for i,(x,y) in enumerate(q[:3039])],1
    yield 'distant_anchor',[(-1.,1.)]+[(.75+rng.randrange(-8,9)*2.**-53,-.75+rng.randrange(-8,9)*2.**-53) for _ in range(4999)],1
    yield 'constant',[(.5,-.25)],2049
    yield 'one_frame',[(.5,-.25)],1


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('driver',type=pathlib.Path); ap.add_argument('--x87',action='store_true'); ap.add_argument('--quick',action='store_true'); args=ap.parse_args()
    modes=['binary64','dd']+(['x87'] if args.x87 else [])
    path=pathlib.Path('fixture.f64le'); rows=[]
    for name,p,reps in fixtures():
        if args.quick and reps>100000: continue
        ref=reference(p,180); low=reference(p,120)
        assert abs(ref-low)<d.Decimal('1e-115')
        raw=b''.join(struct.pack('<dd',*f) for f in p)
        with path.open('wb') as f:
            for pos in range(0,reps,1024): f.write(raw*min(1024,reps-pos))
        try:
            for mode in modes:
                prior=None
                for chunk in ([4093,1025] if reps>100000 else [4093,7,1025]):
                    s=subprocess.check_output([str(args.driver.resolve()),mode,str(path),str(chunk)],text=True).strip().split()
                    assert s[0]=='RESULT' and len(s)==4, s
                    assert s[1]=={'binary64':'Binary64','dd':'DoubleDouble','x87':'X87'}[mode], s
                    if prior is not None: assert s==prior,(name,mode,s,prior)
                    prior=s
                hi,lo=(struct.unpack('>d',bytes.fromhex(x))[0] for x in s[2:]); assert math.isfinite(hi) and math.isfinite(lo)
                with d.localcontext() as ctx:
                    ctx.prec=180; error=abs(d.Decimal.from_float(hi)+d.Decimal.from_float(lo)-ref)
                row=dict(fixture=name,frames=len(p)*reps,backend=mode,hi=hi.hex(),lo=lo.hex(),abs_error=str(error),reference=str(ref))
                rows.append(row);print(json.dumps(row),flush=True)
                if mode!='binary64':
                    assert error < d.Decimal('4e-15' if mode=='x87' else '4e-27'),row
                if mode=='dd' and name.startswith('near_') and name.endswith('_48'):
                    assert lo!=0.0,row
        finally: path.unlink(missing_ok=True)
    print(f'REFERENCE_PASS {len(rows)} comparisons',flush=True)

if __name__=='__main__': main()
