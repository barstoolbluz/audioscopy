#!/usr/bin/env python3
"""Native CP7 qualification. Immutable identity, per-stage receipts, failed evidence.
Requires Python 3.10+, Rust 1.99.1, and native C compiler for Linux x86_64 x87.
"""
import argparse
import gzip
import fcntl
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import statistics
import subprocess
import sys
import tarfile
import tempfile
import time

KIT=Path(__file__).resolve().parent
ROOT=KIT.parent

def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def inventory(path, exclude=()):
    return {p.relative_to(path).as_posix():sha(p) for p in sorted(path.rglob('*')) if p.is_file() and p.name not in exclude}

def verify(path, manifest):
    n=0
    for line in manifest.read_text().splitlines():
        digest,name=line.split('  ',1); p=(path/name).resolve()
        if not p.is_relative_to(path.resolve()) or not p.is_file() or sha(p)!=digest: raise RuntimeError(f'manifest mismatch: {name}')
        n+=1
    return n

def unpack(path, dest):
    with tarfile.open(path,'r:gz') as f:
        for member in f.getmembers():
            if not (member.isdir() or member.isfile()) or not (dest/member.name).resolve().is_relative_to(dest.resolve()): raise RuntimeError('unsafe baseline member')
        f.extractall(dest)

def output(cmd,env=None): return subprocess.check_output(cmd,text=True,env=env).strip()

def json_write(path,obj):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n');tmp.replace(path)

class Runner:
    def __init__(self,args,identity,env):
        self.args=args; self.work=args.work; self.env=env; self.identity=identity;self.stages=self.work/'stages'; self.stages.mkdir(parents=True,exist_ok=True); self.failed=[]
        self.lock=(self.work/'run.lock').open('a');fcntl.flock(self.lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        p=self.work/'identity.json'
        if p.exists() and json.loads(p.read_text())!=identity: raise RuntimeError('work identity mismatch; use a new --work directory')
        json_write(p,identity)
    def stage(self,name,fn,required=True):
        root=self.stages/name;root.mkdir(exist_ok=True)
        prev=sorted(root.glob('attempt-*'))
        for p in reversed(prev):
            r=p/'receipt.json'
            if r.exists():
                v=json.loads(r.read_text())
                if v['status']=='PASS' and inventory(p,('receipt.json',))==v['files']:
                    print('REUSE',name,p.name,flush=True);return p
        p=root/f'attempt-{max([int(x.name.split("-")[-1]) for x in prev],default=0)+1:04d}';p.mkdir()
        print('RUN',name,flush=True);start=time.time(); status='PASS'; error=None
        try:fn(p)
        except Exception as exc:
            status='FAIL' if required else 'UNAVAILABLE';error=repr(exc)
            if required:self.failed.append(name)
        finally:json_write(p/'receipt.json',dict(status=status,error=error,elapsed=time.time()-start,files=inventory(p,('receipt.json',))))
        print(status,name,error or '',flush=True)
        return p if status=='PASS' else None
    def run(self,p,name,cmd,cwd=None,bench=False):
        cmd=[str(x) for x in cmd];env=self.env
        if bench and self.args.cpu is not None:cmd=['taskset','-c',str(self.args.cpu),*cmd]
        (p/(name+'.command.json')).write_text(json.dumps(dict(argv=cmd,cwd=str(cwd or Path.cwd())),indent=2)+'\n')
        with (p/(name+'.log')).open('wb') as f:
            r=subprocess.run(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=14400)
        if r.returncode: raise RuntimeError(f'{name} exit {r.returncode}')
        return (p/(name+'.log')).read_text(errors='replace')
    def package(self):
        json_write(self.work/'status.json',dict(failed=self.failed,status='PASS' if not self.failed else 'INCOMPLETE_OR_FAIL'))
        path=self.work.parent/(self.work.name+'-evidence-'+time.strftime('%Y%m%d-%H%M%S')+'-'+str(os.getpid())+'.tar.gz')
        members=inventory(self.stages)
        (self.work/'MANIFEST-SHA256.txt').write_text(''.join(f'{h}  stages/{n}\n' for n,h in members.items())+''.join(f'{sha(self.work/n)}  {n}\n' for n in ['identity.json','status.json']))
        files=[self.work/'identity.json',self.work/'status.json',self.work/'MANIFEST-SHA256.txt',self.stages]
        with tarfile.open(path,'w:gz',compresslevel=3) as f:
            for p in files:f.add(p,arcname=p.name)
        path.with_suffix(path.suffix+'.sha256').write_text(f'{sha(path)}  {path.name}\n')
        print('EVIDENCE',path,flush=True)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--work',type=Path);ap.add_argument('--verify-only',action='store_true');ap.add_argument('--codegen',choices=['portable','native'],default='portable');ap.add_argument('--cpu',type=int);ap.add_argument('--reps',type=int,default=5);ap.add_argument('--perf',action='store_true');args=ap.parse_args()
    assert args.reps>=3
    print('MANIFEST',verify(ROOT,ROOT/'MANIFEST-SHA256.txt'),flush=True)
    baseline=KIT/'cp6-patched-baseline.tar.gz'; verify(KIT,KIT/(baseline.name+'.sha256'))
    with tempfile.TemporaryDirectory() as t:
        dest=Path(t);unpack(baseline,dest);print('BASELINE',verify(dest,dest/'MANIFEST-SHA256.txt'),flush=True)
    if args.verify_only:return 0
    if args.work is None:ap.error('--work is required')
    args.work=args.work.expanduser().resolve();assert not args.work.is_relative_to(ROOT)
    if args.cpu is not None and platform.system()!='Linux':ap.error('--cpu requires Linux taskset')
    env=dict(os.environ)
    for k in env:
        if k in {'RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_BUILD_TARGET','CARGO_TARGET_DIR'} or k.startswith(('CARGO_PROFILE_','CARGO_TARGET_')):raise RuntimeError('unset compiler override '+k)
    rust=output(['rustc','-vV']);assert rust.startswith('rustc 1.99.1 '),rust
    arch=platform.machine();system=platform.system();host=re.search(r'^host: (.*)$',rust,re.M).group(1)
    x86=arch in ('x86_64','AMD64');arm=arch in ('arm64','aarch64');assert x86 or arm
    assert host.startswith('x86_64-' if x86 else 'aarch64-'),host
    x87=host=='x86_64-unknown-linux-gnu' and system=='Linux'
    # Exclude changing frequency, load and uptime from the resume identity.
    if system=='Linux':
        stable={'vendor_id','model name','cpu family','model','stepping','microcode','flags','Features','CPU implementer','CPU architecture','CPU part','CPU revision'}
        flags='\n'.join(sorted(set(line.strip() for line in Path('/proc/cpuinfo').read_text().splitlines() if line.split(':',1)[0].strip() in stable)))
    elif system=='Darwin':
        keys=['hw.model','hw.machine','hw.ncpu','hw.memsize']+(['machdep.cpu.features','machdep.cpu.leaf7_features'] if x86 else [])
        flags='\n'.join(output(['sysctl',key]) for key in keys)
        if x86 and subprocess.run(['sysctl','-n','sysctl.proc_translated'],capture_output=True,text=True).stdout.strip()=='1':raise RuntimeError('Rosetta is not native qualification')
    else:raise RuntimeError('native operator kit supports Linux and macOS')
    if args.codegen=='native':env['RUSTFLAGS']='-C target-cpu=native'
    idn=dict(manifest=sha(ROOT/'MANIFEST-SHA256.txt'),rust=rust,cargo=output(['cargo','--version']),os=platform.platform(),cpu=platform.processor(),machine=arch,host=host,cpu_info_hash=hashlib.sha256(flags.encode()).hexdigest(),codegen=args.codegen,cpu_pin=args.cpu,reps=args.reps,perf=args.perf,cc=env.get('CC','cc'),ar=env.get('AR','ar'),cc_version=output([env.get('CC','cc'),'--version']) if x87 else None)
    r=Runner(args,idn,env);w=args.work
    try:
        src=w/'sources';base=src/'base';cand=src/'candidate'
        # Reconstruct immutable source on each invocation. Target trees are
        # separate. A resumed gate still hashes its prior evidence/binaries.
        if src.exists():shutil.rmtree(src)
        base.mkdir(parents=True);cand.mkdir();unpack(baseline,base)
        for crate in ['audioscopy','true-peak']:shutil.copytree(ROOT/crate,cand/crate)
        modes={'base':(base,''),'default':(cand,''),'split':(cand,'experimental-stereo-spectrum-split')}
        if x86:
            for isa,feature in [('avx2','experimental-spectral-avx2'),('avx512','experimental-spectral-avx512')]:
                if isa=='avx2' and 'avx2' not in flags.lower():continue
                if isa=='avx512' and 'avx512f' not in flags.lower():continue
                modes[isa]=(cand,feature);modes['split-'+isa]=(cand,feature+',experimental-stereo-spectrum-split')
        if arm:modes.update(neon=(cand,'experimental-loudness-neon'),**{'split-neon':(cand,'experimental-loudness-neon,experimental-stereo-spectrum-split')})
        def cargo(p,name,tree,crate,mode,cmd,feat=''):
            target=w/'targets'/mode/crate;argv=['cargo',*cmd,'--locked','--target-dir',str(target)];argv+=['--features',feat] if feat else []
            # Cargo options go before the test-harness separator.
            return r.run(p,name,argv,tree/crate)
        def hygiene(p):
            failures=[]
            for crate in ['audioscopy','true-peak']:
                for name,cmd in [('fmt',['cargo','fmt','--all','--','--check']),('clippy',['cargo','clippy','--locked','--target-dir',str(w/'targets'/'hygiene'/crate),'--all-targets','--all-features','--','-D','warnings'])]:
                    try:r.run(p,crate+'-'+name,cmd,cand/crate)
                    except Exception as e:failures.append(str(e))
            if failures:raise RuntimeError('; '.join(failures))
        r.stage('05-hygiene',hygiene)
        def tests(p):
            for crate in ['true-peak','audioscopy']:
                for mode,extra in [('default',[]),('all-features',['--all-features'])]:cargo(p,crate+'-'+mode,cand,crate,mode,['test','--release','--no-fail-fast',*extra])
        r.stage('10-regressions',tests)
        # Add the identical external probe after hygiene, to both trees.
        for tree in (base,cand):shutil.copy2(KIT/'cp7_parity.rs',tree/'audioscopy/examples/cp7_parity.rs')
        binaries={}
        for mode,(tree,feat) in modes.items():
            def build(p,mode=mode,tree=tree,feat=feat):
                cargo(p,'build',tree,'audioscopy',mode,['build','--release','--example','numerical_profile','--example','cp7_parity'],feat)
                for name in ('numerical_profile','cp7_parity'):shutil.copy2(w/'targets'/mode/'audioscopy/release/examples'/name,p/name)
                if mode not in ('base','default'):
                    argv=['cargo','test','--locked','--release','--target-dir',str(w/'targets'/mode/'audioscopy'),'--features',feat,'--lib','--','--nocapture']
                    log=r.run(p,'isa-tests',argv,tree/'audioscopy')
                    if 'avx2' in mode: assert 'WIDE_SIMD_SELECTED avx2' in log
                    if 'avx512' in mode: assert 'WIDE_SIMD_SELECTED avx512f' in log
                    if 'split' in mode: assert 'STEREO_SPLIT_PORTABLE_EXECUTED' in log
                    if 'neon' in mode:
                        log=r.run(p,'neon-tests',['cargo','test','--locked','--release','--target-dir',str(w/'targets'/mode/'true-peak'),'--features','experimental-loudness-neon','--lib','--','--nocapture'],tree/'true-peak')
                        assert 'NEON_KERNEL_EXECUTED' in log and 'NEON_DISPATCH_EXECUTED' in log
            p=r.stage('20-build-'+mode,build)
            if p:binaries[mode]=p
        parity={}
        for mode,p in binaries.items():
            def probe(d,p=p):
                s=r.run(d,'parity',[p/'cp7_parity'],bench=True);lines=[x for x in s.splitlines() if x.startswith('CP7_PARITY\t')];assert len(lines)==60,len(lines)
                (d/'records.sha256').write_text(hashlib.sha256(('\n'.join(lines)+'\n').encode()).hexdigest()+'\n')
                with gzip.open(d/'parity.log.gz','wb') as f:f.write((d/'parity.log').read_bytes())
                (d/'parity.log').unlink()
            d=r.stage('30-parity-'+mode,probe)
            if d:parity[mode]=(d/'records.sha256').read_text()
        def parity_gate(p):
            json_write(p/'hashes.json',parity);assert set(parity)==set(modes) and len(set(parity.values()))==1,'public parity mismatch or missing modes'
        r.stage('31-parity-gate',parity_gate)
        def precision(p):
            feat='precision-x87' if x87 else 'precision'
            cargo(p,'build',cand,'audioscopy','precision',['build','--release','--example','precision_profile','--example','precision_f64le'],feat)
            for name in ('precision_profile','precision_f64le'):shutil.copy2(w/'targets/precision/audioscopy/release/examples'/name,p/name)
            r.run(p,'reference',[sys.executable,'-B',KIT/'native_reference.py',p/'precision_f64le',*(['--x87'] if x87 else [])],p,True)
            if x87:
                cc=env.get('CC','cc');r.run(p,'c-environment-build',[cc,'-std=c11','-O3','-fno-fast-math','-ffp-contract=off','-frounding-math','-pthread',ROOT/'precision-qualification/x87_environment.c',cand/'audioscopy/native/correlation_x87.c','-lm','-o',p/'x87-environment']);r.run(p,'c-environment',[p/'x87-environment'])
        pp=r.stage('40-precision-reference',precision)
        # One full workload is one resumable cohort. Alternate starting
        # order, pair repetitions within a cohort, never pool attempts.
        def timing(p,choices,argv,precision=False):
            rows=[]
            for pair in range(-1,args.reps):
                names=list(choices);offset=(pair+1)%len(names);names=names[offset:]+names[:offset]
                for mode in names:
                    command=[choices[mode],*([mode,*argv] if precision else argv)]
                    timer=Path(shutil.which('time') or '/usr/bin/time'); command=([timer,'-l'] if system=='Darwin' else [timer,'-f','PEAK_RSS_KIB=%M'])+command
                    s=r.run(p,f'{pair+1:02d}-{mode}',command,bench=True)
                    line=next(x for x in s.splitlines() if x.startswith('PRECISION_PROFILE ' if precision else 'PROFILE\t'))
                    wall=float(re.search(r'wall_s=([0-9.]+)',line).group(1)) if precision else float(line.split('\t')[-1]);assert wall>0
                    rss=re.search(r'PEAK_RSS_KIB=(\d+)',s) if system!='Darwin' else re.search(r'(\d+)\s+maximum resident set size',s)
                    assert rss,'missing RSS';rows.append(dict(pair=pair,mode=mode,wall_s=wall,rss_kib=int(rss.group(1))/(1024 if system=='Darwin' else 1),record=line));json_write(p/'raw.json',rows)
            ref=next(iter(choices));summary={m:dict(median_wall_s=statistics.median(x['wall_s'] for x in rows if x['mode']==m and x['pair']>=0),median_speedup=statistics.median(next(x['wall_s'] for x in rows if x['mode']==ref and x['pair']==i)/next(x['wall_s'] for x in rows if x['mode']==m and x['pair']==i) for i in range(args.reps)),peak_rss_kib=max(x['rss_kib'] for x in rows if x['mode']==m and x['pair']>=0)) for m in choices};json_write(p/'summary.json',summary)
        groups=[('stereo',192000,2,60),('stereo',768000,2,60),('stereo_spectral',48000,2,6),('stereo_spectral',768000,2,6),('spectrum',48000,2,6),('spectrum',768000,2,6),('noise',192000,2,6),('all',48000,1,6),('all',48000,2,6),('all',768000,2,6),('all',768000,2,60),('all',48000,3,6),('all',192000,6,6),('loudness',768000,2,6),('loudness',768000,6,6),('album_loudness',192000,2,6),('album',48000,2,6)]
        if set(binaries)==set(modes):
            for group in groups:
                r.stage('50-timing-'+'-'.join(map(str,group)),lambda p,g=group:timing(p,{m:binaries[m]/'numerical_profile' for m in modes},list(map(str,g))))
        else:r.failed.append('missing-benchmark-binaries')
        if pp:
            for rate,seconds in [(48000,6),(192000,6),(768000,6),(768000,60)]:
                r.stage(f'60-precision-{rate}-{seconds}',lambda p,rate=rate,seconds=seconds:timing(p,{m:pp/'precision_profile' for m in ['binary64','dd']+(['x87'] if x87 else [])},[str(rate),str(seconds)],True))
        if args.perf and 'default' in binaries:
            r.stage('70-perf',lambda p:r.run(p,'perf',['perf','stat','-e','cycles,instructions,cache-references,cache-misses,branches,branch-misses',binaries['default']/'numerical_profile','all','768000','2','6'],bench=True),False)
        def assembly(p):
            for mode,dir in binaries.items():r.run(p,mode,['otool','-tvV',dir/'numerical_profile'] if system=='Darwin' else ['objdump','-Cd',dir/'numerical_profile'])
        r.stage('71-assembly',assembly,False)
    except BaseException as exc:
        r.failed.append(repr(exc));raise
    finally:r.package()
    return int(bool(r.failed))

if __name__=='__main__':sys.exit(main())
