# CP7 focused native qualification (Linux x86-64 and native Apple Silicon)

This is a candidate, not a release. All stages run against immutable source plus frozen locks. Prior R6 evidence reused rather than rerunning 97 historical workloads for every feature; 17 targeted workloads across geometries/measurement groups, public parity, default and all-feature regression suites, independent public precision fixtures, actual ISA execution markers, RSS and optional hardware-counter evidence. Each successful stage carries hashes and a receipt, every failed attempt stays in evidence, and failed timing cohorts rerun in full. Never pool different identities. For a changed source/patch/compiler/codegen use a new --work. Runner selftests passed in the cloud, but native Rust orchestration has not been executed there. If an early compile or lint failure occurs, return the archive and exact corrective patch if you make one. No automatic source rewriting.

Requirements: native Rust 1.99.1, Cargo, rustfmt, Clippy, Python >=3.10, native C compiler and ar on GNU/Linux x86_64 for x87, standard /usr/bin/time (GNU on Linux, BSD on Darwin), optional perf/taskset/objdump. Work outside any Cargo workspace or overriding .cargo/config.toml. Dependencies may download on first invocation. Quiet AC-powered host; keep CPU sibling idle. On M3 do not use Rosetta. Avoid compiler wrappers, custom Rust flags or Cargo profile overrides. Keep portable and native codegen separate. Verify external SHA-256 with sha256sum -c or shasum -a 256 -c (macOS).

```sh
# From the extracted CP7 directory (engineering bundle OR operator kit).
python3 -B qualification-cp7/qualify_cp7.py --verify-only
(cd qualification-cp7 && python3 -B -m unittest -v test_runner)
# If toolchain is not already pinned:
rustup toolchain install 1.99.1 --component rustfmt --component clippy

# Threadripper, portable codegen, logical CPU 1 if available:
rustup run 1.99.1 python3 -B qualification-cp7/qualify_cp7.py \
  --work "$HOME/audioscopy-qualification/cp7-portable" --cpu 1 --perf

# Apple Silicon, native ARM, portable-codegen cohort:
rustup run 1.99.1 python3 -B qualification-cp7/qualify_cp7.py \
  --work "$HOME/audioscopy-qualification/cp7-m3-portable"

# Optional distinct native-codegen cohort (not a replacement for portable):
rustup run 1.99.1 python3 -B qualification-cp7/qualify_cp7.py \
  --work "$HOME/audioscopy-qualification/cp7-native" --codegen native --cpu 1 --perf
```

Omit `rustup run 1.99.1` when pinned compiler is on PATH (e.g. Nix). The supplied flake pins the prior shell; use `nix develop ./qualification-cp7` on supported Linux; native macOS rustup is preferred. Omit `--cpu` on macOS. `--perf` is optional and blocked counters are reported UNAVAILABLE, not silently passed. `--reps` default five plus one warmup. Keep all inputs unchanged on resume. Result file and checksum printed as EVIDENCE, in the work directory's parent. Return both; runner records tests, failures, exact binary hashes/bytes, raw timing rows, public parity digests/raw compressed logs and optional disassembly. A PASS only means specified gates completed, not automatic backend promotion or release sign-off. If the input is forcibly killed, re-run same command to package existing partial receipts and resume. SIGKILL cannot itself invoke cleanup. Source-level preflight before Rust is available does not establish native execution. The original R6 runner is preserved for historical reproducibility and is not the current CP7 runner.
