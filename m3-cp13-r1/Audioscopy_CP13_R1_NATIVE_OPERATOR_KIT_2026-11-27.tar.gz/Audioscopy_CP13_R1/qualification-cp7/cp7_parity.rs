//! Exact public-result comparison for wide spectral candidates.
use audioscopy::{
    AlbumAnalyzer, Analyzer, ChannelRole, Encoding, Format, Measurement as M, Measurements,
    NoiseView, Settings,
};

fn signal(rate: u32, channels: usize) -> (Vec<f64>, Vec<f64>) {
    let mut a = Vec::with_capacity(rate as usize * channels);
    let mut q = Vec::with_capacity(rate as usize * channels);
    let mut seed = 0x587a_4b27_91c3_511d_u64;
    for i in 0..rate {
        let tone = if i % 97 < 48 { 1_048_576 } else { -1_048_576 };
        for ch in 0..channels {
            seed ^= seed << 13;
            seed ^= seed >> 7;
            seed ^= seed << 17;
            let noise = ((seed >> 48) as i32) - 32768;
            let amplitude = if ch.is_multiple_of(3) { 2 } else { 1 };
            a.push(f64::from(amplitude * tone + noise) / 8388608.0);
            q.push(f64::from(noise / 4096) / 8388608.0);
        }
    }
    (a, q)
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    use ChannelRole::*;
    let spectral = [M::AverageSpectrum, M::Above20Khz];
    let noise = [
        M::NoiseFloor,
        M::EffectiveBits,
        M::NoiseSpectrum,
        M::HumAndIdleTones,
        M::NoiseByBand,
        M::DynamicRange,
    ];
    let bandwidth = [M::Bandwidth, M::LikelySourceRate, M::LossyCodingPattern];
    let stereo = [M::BassWidth, M::InterChannelDelay];
    let loudness = [M::LoudnessRange, M::ShortTermMaximum, M::LoudnessOverTime];
    for (rate, roles) in [
        (8001, vec![Mono]),
        (44101, vec![Left, Right]),
        (48000, vec![Left, Right, Center]),
        (192000, vec![Left, Right]),
        (768000, vec![Left, Right, Center, Lfe, LeftSurround, RightSurround]),
    ] {
        let channels = roles.len();
        let format = Format {
            sample_rate: rate,
            channels,
            encoding: Encoding::Integer(24),
            loudness_roles: Some(roles),
        };
        let (active, quiet) = signal(rate, channels);
        for (label, selection) in [
            ("spectrum", Measurements::new(&spectral)),
            ("noise", Measurements::new(&noise)),
            ("bandwidth", Measurements::new(&bandwidth)),
            ("stereo_spectral", Measurements::new(&stereo)),
            ("loudness", Measurements::new(&loudness)),
            ("all", Measurements::all()),
        ] {
            let mut track = Analyzer::new(format.clone(), selection, Settings::default())?;
            let mut album = AlbumAnalyzer::new(selection, Settings::default());
            album.begin_track(format.clone())?;
            for (i, block) in [&active, &quiet, &active, &active, &quiet, &active]
                .into_iter()
                .enumerate()
            {
                if i == 3 {
                    album.end_track()?;
                    album.begin_track(format.clone())?;
                }
                for chunk in block.chunks(4093 * channels) {
                    track.push_interleaved(chunk)?;
                    album.push_interleaved(chunk)?;
                }
            }
            album.end_track()?;
            let track = track.finish()?;
            let album = album.finish()?;
            assert_eq!(track.frames(), u64::from(rate) * 6);
            assert_eq!(album.tracks().len(), 2);
            let view = NoiseView::default();
            let values = |t: &audioscopy::Track| {
                M::ALL.into_iter().filter(|m| selection.contains(*m))
                    .map(|m| t.measure(m, view)).collect::<Vec<_>>()
            };
            println!(
                "CP7_PARITY\ttrack-{label}-{rate}-{channels}\t{:?}",
                (values(&track), track.noise_record())
            );
            println!(
                "CP7_PARITY\talbum-{label}-{rate}-{channels}\t{:?}",
                (
                    album.loudness_method(),
                    M::ALL.into_iter().filter(|m| selection.contains(*m))
                        .map(|m| album.measure(m, view)).collect::<Vec<_>>(),
                    album.tracks().iter().map(|t| (values(t), t.noise_record())).collect::<Vec<_>>()
                )
            );
        }
    }
    Ok(())
}
