{
  description = "audioscopy local qualification kit r6: every tool the runner needs";

  # Same inputs as the audioscopy repository flake. flake.lock is copied from
  # that repository so nixpkgs and rust-overlay resolve to the same revisions.
  inputs = {
    nixpkgs.url = "github:NixOS/nixpkgs/nixos-unstable";
    flake-utils.url = "github:numtide/flake-utils";
    rust-overlay = {
      url = "github:oxalica/rust-overlay";
      inputs.nixpkgs.follows = "nixpkgs";
    };
  };

  outputs = { self, nixpkgs, flake-utils, rust-overlay }:
    flake-utils.lib.eachDefaultSystem (system:
      let
        pkgs = import nixpkgs {
          inherit system;
          overlays = [ (import rust-overlay) ];
        };
        rustToolchain = pkgs.rust-bin.stable."1.99.1".default.override {
          extensions = [ "rust-src" "clippy" "rustfmt" ];
        };
        python = pkgs.python3.withPackages (ps: [ ps.mpmath ps.numpy ps.scipy ]);
      in
      {
        devShells.default = pkgs.mkShell {
          packages = [
            rustToolchain
            python
            pkgs.time        # GNU time, for peak RSS
            pkgs.perf        # optional perf stages
            pkgs.util-linux  # taskset, lscpu
            pkgs.binutils    # nm, objdump
            pkgs.gnupatch
            pkgs.gnutar
            pkgs.coreutils
            pkgs.gnused
            pkgs.gnugrep
            pkgs.diffutils   # cmp
            pkgs.bash
          ];
        };
      });
}
