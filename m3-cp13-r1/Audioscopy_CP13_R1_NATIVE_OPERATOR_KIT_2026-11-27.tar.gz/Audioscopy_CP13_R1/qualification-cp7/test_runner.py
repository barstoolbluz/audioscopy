import argparse
from pathlib import Path
import tempfile
import unittest
import qualify_cp7 as q
import native_reference as n

class Tests(unittest.TestCase):
    def test_receipts_resume_and_retry(self):
        with tempfile.TemporaryDirectory() as t:
            a=argparse.Namespace(work=Path(t)/'work')
            r=q.Runner(a,{'fixture':1},{})
            def good(p): (p/'data').write_text('ok')
            def bad(p): raise RuntimeError('deliberate')
            first=r.stage('one',good);self.assertEqual(r.stage('one',bad),first)
            (first/'data').write_text('tampered')
            self.assertIsNone(r.stage('one',bad))
            last=r.stage('one',good);self.assertNotEqual(first,last)
            r.package();self.assertTrue(list(Path(t).glob('*.tar.gz.sha256')))
            r.lock.close()
    def test_oracle(self):
        from decimal import Decimal
        p=[(0.,0.),(1.,0.),(1.,1.),(0.,1.),(1.,1.),(1.,1.),(0.,0.)]
        self.assertLess(abs(n.reference(p,120)-Decimal(5)/Decimal(12)),Decimal('1e-27'))
        self.assertEqual(n.reference([(1.,0.)],120),0)

if __name__=='__main__':unittest.main()
