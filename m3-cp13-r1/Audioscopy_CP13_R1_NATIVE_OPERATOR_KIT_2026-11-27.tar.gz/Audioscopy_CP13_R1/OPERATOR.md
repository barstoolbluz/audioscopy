# CP13-R1 native qualification

## Threadripper: close failed gates only

Use the same Nix shell that produced CP13 (Rust 1.99.1, same GCC/ar, same CPU). Extract this archive into a new directory, retain the original CP13 evidence archive. No need to rerun passed numerical, parity or timing stages. The focused runner checks original archive SHA, exact source delta and native toolchain identity. It retains failed attempts and supports resume with identical arguments.

```bash
python3 -B qualification-cp13/qualify_corrective.py --verify-only
python3 -B qualification-cp13/qualify_corrective.py \
  --work "$HOME/audioscopy-qualification/cp13-r1-portable" \
  --prior-evidence "$HOME/audioscopy-qualification/cp13-portable-evidence-20261127-121432-3146397.tar.gz"
```

Adjust the prior archive path only if you stored it elsewhere. Return the new evidence archive and checksum. The focused run is supplemental to the original returned CP13 evidence; it is not standalone full native qualification. If exact CPU/toolchain identity changed, use the full runner below. No `--perf` is required for the corrective.

## M3: complete first native ARM qualification

In a pinned Rust 1.99.1 environment with native Clang/ar, Python 3.10+, and BSD time:

```bash
python3 -B qualification-cp13/qualify_cp13.py --verify-only
python3 -B qualification-cp13/qualify_cp13.py \
  --work "$HOME/audioscopy-qualification/cp13-r1-m3-portable" \
  --layout-control --long
```

Do not use an old CP13 work directory. If using rustup rather than the pinned Nix shell, prefix commands with `rustup run 1.99.1`. Native formatting from the Threadripper run is already incorporated, so omit `--format-candidate`. If platform-specific formatting is needed, use it explicitly in a fresh work directory and retain its patch. For a full new Threadripper cohort, use the full CP13 runner with a new work directory and `--cpu 1 --layout-control --long` (optional `--perf`). See `OPERATOR-CP13-ORIGINAL.md` for details of the full runner. No automatic promotion of experimental backends.
