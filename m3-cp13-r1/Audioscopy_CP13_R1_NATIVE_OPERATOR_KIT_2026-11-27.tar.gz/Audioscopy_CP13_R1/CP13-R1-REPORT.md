# CP13-R1: focused qualification correction, 2026-11-27

Verdict: **test-only correction required; no demonstrated numerical or DSP defect.** Native CP13 as delivered (with explicit native formatting) returned 47 PASS, 4 FAIL, 1 UNAVAILABLE. It is not a fully qualified release until the failed gates close. Neither this environment nor this correction supplies native ARM evidence.

## Evidence

Original operator kit SHA-256 `7ca8344eff8f049d030aab0bb25cabf5f898a6a37d3cfebb7997e7a900a3f4b1`. Returned evidence archive SHA-256 `67a0b228c61f4e65ab699539493d98d487659397ef042fdd877212b4563ecee8`. Both external checksums verified, original kit 210 entries and engineering archive 577 entries verified; evidence 1,272 entries and 52 receipts verified. The exact native formatted source 179 files, manifest `18911b5f362750963baa9fcd3eed217e7d3247f0f7d135c1dd96caf224efe9fb`, was extracted from stage 04; its 13-file rustfmt diff reconstructed exactly against the original kit. The original operator and engineering crate trees matched before formatting. Preserve the original 109 MB evidence archive separately; the correction includes its manifest, identity, audit summary and reproduction scripts, not the binaries/logs themselves.

All six ordinary probes produced 60 identical records each (360 total). CP7, CP7 same-source control and CP13 default profiler binaries all hash to `98daeeca04a4e328fdb5c6b8a35186dd71265c2ef71c43f9ae3fbbf70adc1b86`. Audit independently recomputed 415 measured timings, 325 non-reference paired comparisons and all reported RSS maxima from raw logs. Public Rust wide references: 214 passes (spectrum 54, cross 48, noise 36, loudness 76); C reference suite: 543 passes (spectrum 63, cross 56, noise 294, loudness 130). Both native environment tests passed. Perf unavailable (kernel.perf_event_paranoid=3).

## Corrections

- R1-D01: explicit `usize` closure argument in `audioscopy/tests/precision_loudness.rs`, addressing E0271. The original test suite did not compile; three gates share this cause. No measurement code changed. Replay through original Rust `precision_loudness_f64le` on the local Xeon using the host loader produced identical outputs at chunks 127 and 4093, all three available backends reporting 10,003 frames, 3,200 required, finite outcome, nine absolute and nine relative observations. The remaining unit assertions, including resource-limit behavior, still require the native Rust test run.
- R1-D02: `fft_len` must be 2048 at 12001 Hz (`ceil(12001/6)=2001`, next power of two 2048), not 4096. The API/contract explicitly use the ordinary grid. Replay of the actual test PCM through the returned Rust driver yielded 1693 frames, 2048-point FFT, 1025 one-sided bins, Parseval energy 0.08328646730076354 in each of the five tested backends, identical results at chunks 127 and 4093, and exact DD scalar-FMA/AVX2/AVX512 limb parity. Do not change production FFT sizing.
- R1-D03: delete the obsolete top-level MIT and Apache license texts from both crate trees; Cargo manifests and COPYING already state GPL-2.0-or-later. Preserve the Apache-2.0 third-party fixture notice and dependency-license attributions. Earlier checkpoints remain archival evidence, not the current crate licensing declaration.

The corrected crate trees differ from the native-formatted CP13 candidate in exactly two test lines and four obsolete root license files. All production Rust and C files, build scripts, examples, fixture contents and dependency locks are byte-identical to the native-formatted candidate. `qualification-cp13/corrective/` preserves both manifests, source delta, original rustfmt patch, independent audit and replay scripts/results. No new optimization or dispatch change is introduced.

## Native timings (portable Rust codegen, 60 s stereo at 768 kHz)

| Backend | average spectrum (s) | cross-spectrum (s) | integrated loudness (s) |
|---|---:|---:|---:|
| x87 | 9.1371 | 10.3558 | 2.1269 |
| DD portable | 28.3476 | 32.7295 | 10.2392 |
| DD scalar FMA | 23.7326 | 28.1369 | 9.3823 |
| DD AVX2 | 16.9435 | 21.4088 | n/a |
| DD AVX512 | 17.7666 | 22.6259 | n/a |

AVX2 beat AVX512 in every supplied wide spectral/noise cohort by median wall time. Keep ISA selection explicit; one host does not establish a general default. Default ordinary binary is identical to CP7; split portable speedup 1.074x for combined stereo-spectral at 768 kHz, split AVX2 1.073x and AVX512 1.097x. Power-only speedups are near unity. Do not generalize combined-workload gains to all measurements. Peak RSS per mode retained in audit-results.json.

## Qualification closure

Run `qualification-cp13/qualify_corrective.py` on the original Threadripper, using the original Nix toolchain and return archive. It verifies exact source delta and original archive SHA, uses a new immutable work identity, reruns hygiene and the three affected regression/feature gates, and packages each stage. A successful focused run plus the original passed evidence closes CP13's failed Threadripper gates; no fresh full benchmark or reference matrix is justified for test-only changes. It does not certify ARM or TonePoet integration. If source or compiler changes, use full qualification. On M3, run the original full CP13 runner on the corrected source, since no CP13 native ARM evidence has been returned. No `--format-candidate` is needed; formatting is already incorporated. Keep the separate prior evidence files.

Native Rust 1.99.1 unavailable here: corrected Rust test compilation and strict Clippy have not been executed in this environment. Replays used the existing returned Rust binaries, not newly built corrected tests. True-peak high-precision research is a separate next commission, not mixed into this correction.
