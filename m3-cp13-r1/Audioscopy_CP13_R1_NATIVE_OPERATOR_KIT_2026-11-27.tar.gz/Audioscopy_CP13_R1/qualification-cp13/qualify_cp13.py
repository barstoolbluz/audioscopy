#!/usr/bin/env python3
"""Consolidated CP8-CP13 qualification; independent measurement receipts.

Uses CP7's receipt/evidence infrastructure. Source and build paths for the
ordinary baseline and candidate are deliberately identical (serial slot).
Run identities include the exact manifest, pinned compiler, timer and flags.
"""
import argparse,difflib,gzip,hashlib,json,os,platform,re,shutil,statistics,subprocess,sys,tarfile,tempfile
from pathlib import Path

KIT=Path(__file__).resolve().parent;ROOT=KIT.parent
sys.path.insert(0,str(ROOT/'qualification-cp7'))
from qualify_cp7 import Runner,sha,verify,unpack,json_write,output,inventory


def flags_for(system,arch):
    if system=='Linux':
        stable={'vendor_id','model name','cpu family','model','stepping','microcode','flags','Features','CPU implementer','CPU architecture','CPU part','CPU revision'}
        return '\n'.join(sorted(set(line.strip() for line in Path('/proc/cpuinfo').read_text().splitlines() if line.split(':',1)[0].strip() in stable)))
    if system=='Darwin':
        if arch=='x86_64' and subprocess.run(['sysctl','-n','sysctl.proc_translated'],capture_output=True,text=True).stdout.strip()=='1':raise RuntimeError('Rosetta is not native qualification')
        keys=['hw.model','hw.machine','hw.ncpu','hw.memsize']+(['machdep.cpu.features','machdep.cpu.leaf7_features'] if arch=='x86_64' else [])
        return '\n'.join(output(['sysctl',key]) for key in keys)
    raise RuntimeError('native Linux/macOS only')


def timing(r,p,timer,system,choices,argv,wide=False):
    rows=[];names=list(choices)
    for pair in range(-1,r.args.reps):
        offset=(pair+1)%len(names)
        for mode in names[offset:]+names[:offset]:
            command=[timer,'-l'] if system=='Darwin' else [timer,'-f','PEAK_RSS_KIB=%M']
            command+=[choices[mode],*([mode,*argv] if wide else argv)]
            text=r.run(p,f'{pair+1:02d}-{mode}',command,bench=True)
            line=next(x for x in text.splitlines() if x.startswith('WIDE_PROFILE ' if wide else 'PROFILE\t'))
            wall=float(re.search(r'wall_s=([0-9.]+)',line).group(1)) if wide else float(line.split('\t')[-1]);assert wall>0
            rss=re.search(r'(\d+)\s+maximum resident set size',text) if system=='Darwin' else re.search(r'PEAK_RSS_KIB=(\d+)',text)
            assert rss,'missing RSS';rows.append(dict(mode=mode,pair=pair,wall_s=wall,rss_kib=int(rss.group(1))/(1024 if system=='Darwin' else 1),record=line));json_write(p/'raw.json',rows)
    by={(x['pair'],x['mode']):x for x in rows};ref=names[0]
    summary={m:dict(median_wall_s=statistics.median(by[i,m]['wall_s'] for i in range(r.args.reps)),median_speedup=statistics.median(by[i,ref]['wall_s']/by[i,m]['wall_s'] for i in range(r.args.reps)),peak_rss_kib=max(by[i,m]['rss_kib'] for i in range(r.args.reps))) for m in names};json_write(p/'summary.json',summary)


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--work',type=Path);ap.add_argument('--verify-only',action='store_true');ap.add_argument('--cpu',type=int);ap.add_argument('--codegen',choices=['portable','native'],default='portable');ap.add_argument('--reps',type=int,default=5);ap.add_argument('--perf',action='store_true');ap.add_argument('--long',action='store_true');ap.add_argument('--layout-control',action='store_true');ap.add_argument('--format-candidate',action='store_true',help='explicitly format a copied source tree; preserve archive, manifest and diff of formatted candidate');args=ap.parse_args()
    assert args.reps>=3
    print('MANIFEST',verify(ROOT,ROOT/'MANIFEST-SHA256.txt'),flush=True)
    baseline=ROOT/'qualification-cp8/cp7-qualified-baseline.tar.gz';verify(baseline.parent,baseline.parent/(baseline.name+'.sha256'))
    with tempfile.TemporaryDirectory() as t:
        base=Path(t);unpack(baseline,base);print('CP7_BASELINE',verify(base,base/'MANIFEST-SHA256.txt'),flush=True)
        for crate in ('audioscopy','true-peak'):assert sha(base/crate/'Cargo.lock')==sha(ROOT/crate/'Cargo.lock')
        # No changes to the previously qualified ordinary DSP implementation.
        for crate in ('audioscopy','true-peak'):
            for p in (base/crate/'src').rglob('*.rs'):
                rel=p.relative_to(base/crate)
                if crate=='audioscopy' and rel.parts[:2]==('src','precision'):continue
                assert sha(p)==sha(ROOT/crate/rel),(crate,str(rel))
    if args.verify_only:return 0
    if args.work is None:ap.error('--work is required')
    args.work=args.work.expanduser().resolve();assert not args.work.is_relative_to(ROOT)
    arch=platform.machine();system=platform.system();x86=arch in ('x86_64','AMD64');arm=arch in ('arm64','aarch64');assert x86 or arm
    if args.cpu is not None and system!='Linux':ap.error('--cpu requires Linux')
    env=dict(os.environ)
    for k in env:
        if k in {'RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_BUILD_TARGET','CARGO_TARGET_DIR'} or k.startswith(('CARGO_PROFILE_','CARGO_TARGET_')):raise RuntimeError('unset compiler override '+k)
    rust=output(['rustc','-vV']);assert rust.startswith('rustc 1.99.1 '),rust;host=re.search(r'^host: (.*)$',rust,re.M).group(1)
    assert host.startswith('x86_64-' if x86 else 'aarch64-'),host
    x87=host=='x86_64-unknown-linux-gnu' and system=='Linux';flags=flags_for(system,arch)
    timer='/usr/bin/time' if system=='Darwin' else shutil.which('time') or '/usr/bin/time';assert Path(timer).is_file(),timer
    remap=f'--remap-path-prefix={args.work}=/audioscopy-cp13-work';rustflags=[remap]+(['-Ctarget-cpu=native'] if args.codegen=='native' else [])
    env['CARGO_ENCODED_RUSTFLAGS']='\x1f'.join(rustflags)
    cc=env.get('CC','cc');ar=env.get('AR','ar')
    identity=dict(manifest=sha(ROOT/'MANIFEST-SHA256.txt'),baseline=sha(baseline),rust=rust,cargo=output(['cargo','--version']),os=platform.platform(),machine=arch,host=host,cpu_info_hash=hashlib.sha256(flags.encode()).hexdigest(),cpu_pin=args.cpu,reps=args.reps,codegen=args.codegen,rustflags=rustflags,perf=args.perf,long=args.long,layout_control=args.layout_control,format_candidate=args.format_candidate,rustfmt=output(['rustfmt','--version']),timer=timer,cc=cc,ar=ar,cc_version=output([cc,'--version']))
    r=Runner(args,identity,env);w=args.work
    try:
        src=w/'sources';base=src/'base';cand=src/'candidate'
        if src.exists():shutil.rmtree(src)
        base.mkdir(parents=True);cand.mkdir();unpack(baseline,base)
        for crate in ('audioscopy','true-peak'):shutil.copytree(ROOT/crate,cand/crate)
        def unchanged_ordinary(tree):
            for crate in ('audioscopy','true-peak'):
                assert sha(base/crate/'Cargo.lock')==sha(tree/crate/'Cargo.lock')
                for f in (base/crate/'src').rglob('*.rs'):
                    rel=f.relative_to(base/crate)
                    if crate=='audioscopy' and rel.parts[:2]==('src','precision'):continue
                    assert sha(f)==sha(tree/crate/rel),(crate,str(rel))
        if args.format_candidate:
            def formatting(p):
                staged=p/'formatted-tree';staged.mkdir()
                for crate in ('audioscopy','true-peak'):shutil.copytree(cand/crate,staged/crate)
                try:
                    for crate in ('audioscopy','true-peak'):r.run(p,crate+'-fmt',['cargo','fmt','--all'],staged/crate)
                    unchanged_ordinary(staged)
                    before=inventory(cand);after=inventory(staged)
                    assert set(before)==set(after),'formatting created or removed files'
                    changed=[n for n in before if before[n]!=after[n]]
                    assert all(n.endswith('.rs') for n in changed),'unexpected non-Rust formatting change'
                    diff=[]
                    for n in changed:
                        diff.extend(difflib.unified_diff((cand/n).read_text().splitlines(True),(staged/n).read_text().splitlines(True),'a/'+n,'b/'+n))
                    (p/'rustfmt.patch').write_text(''.join(diff))
                    (p/'formatted-source-manifest.txt').write_text(''.join(f'{h}  {n}\n' for n,h in sorted(after.items())))
                    with tarfile.open(p/'formatted-sources.tar.gz','w:gz') as tar:
                        for crate in ('audioscopy','true-peak'):tar.add(staged/crate,arcname=crate)
                    json_write(p/'format-identity.json',dict(changed=changed,input_manifest=sha(ROOT/'MANIFEST-SHA256.txt'),formatted_manifest=sha(p/'formatted-source-manifest.txt')))
                finally:shutil.rmtree(staged)
            done=r.stage('04-format-candidate',formatting)
            if done:
                shutil.rmtree(cand);cand.mkdir();unpack(done/'formatted-sources.tar.gz',cand)
                verify(cand,done/'formatted-source-manifest.txt');unchanged_ordinary(cand)
        unchanged_ordinary(cand)
        def cargo(p,name,tree,crate,tag,command,feat=''):
            cmd=['cargo',*command,'--locked','--target-dir',str(w/'targets'/tag/crate)];cmd+=['--features',feat] if feat else []
            return r.run(p,name,cmd,tree/crate)
        def hygiene(p):
            errors=[]
            for crate in ('audioscopy','true-peak'):
                for name,cmd in [('fmt',['cargo','fmt','--all','--','--check']),('clippy',['cargo','clippy','--locked','--target-dir',str(w/'targets'/'hygiene'/crate),'--all-targets','--all-features','--','-D','warnings'])]:
                    try:r.run(p,crate+'-'+name,cmd,cand/crate)
                    except Exception as exc:errors.append(str(exc))
            if errors:raise RuntimeError('; '.join(errors))
        r.stage('05-hygiene',hygiene)
        for crate in ('true-peak','audioscopy'):
            for mode,extra in [('default',[]),('all-features',['--all-features'])]:
                r.stage('10-regressions-'+crate+'-'+mode,lambda p,crate=crate,mode=mode,extra=extra:cargo(p,'tests',cand,crate,mode,['test','--release','--no-fail-fast',*extra]))
        for feature in ('precision-spectrum','precision-loudness'):
            r.stage('11-feature-'+feature,lambda p,feature=feature:cargo(p,'tests',cand,'audioscopy',feature,['test','--release','--no-fail-fast','--lib','--tests'],feature))
        # Both source and target paths are the same for each ordinary build.
        # This removes the observed workspace-path confound; it cannot prove
        # that distinct source or feature sets have identical binary layout.
        modes={'base':(base,''),'default':(cand,'')}
        if args.layout_control:modes['base-control']=(base,'')
        modes['split']=(cand,'experimental-stereo-spectrum-split')
        if x86:
            for isa,feature in [('avx2','experimental-spectral-avx2'),('avx512f','experimental-spectral-avx512')]:
                if isa in flags.lower():modes['split-'+isa]=(cand,'experimental-stereo-spectrum-split,'+feature)
        if arm:modes.update(neon=(cand,'experimental-loudness-neon'),**{'split-neon':(cand,'experimental-loudness-neon,experimental-stereo-spectrum-split')})
        slot=w/'ordinary-slot';target=w/'ordinary-target';binaries={}
        for mode,(tree,feat) in modes.items():
            def build(p,tree=tree,feat=feat,mode=mode):
                for path in (slot,target):
                    if path.exists():shutil.rmtree(path)
                slot.mkdir()
                for crate in ('audioscopy','true-peak'):shutil.copytree(tree/crate,slot/crate)
                shutil.copy2(ROOT/'qualification-cp7/cp7_parity.rs',slot/'audioscopy/examples/cp7_parity.rs')
                cmd=['cargo','build','--release','--locked','--target-dir',str(target),'--example','numerical_profile','--example','cp7_parity']
                if feat:cmd+=['--features',feat]
                r.run(p,'build',cmd,slot/'audioscopy')
                for name in ('numerical_profile','cp7_parity'):shutil.copy2(target/'release/examples'/name,p/name)
                if 'split' in mode:
                    log=r.run(p,'split-tests',['cargo','test','--locked','--release','--target-dir',str(target/'split-tests'),'--features',feat,'--lib','--','--nocapture'],slot/'audioscopy')
                    assert 'STEREO_SPLIT_PORTABLE_EXECUTED' in log
                    if 'avx2' in mode:assert 'WIDE_SIMD_SELECTED avx2' in log
                    if 'avx512' in mode:assert 'WIDE_SIMD_SELECTED avx512f' in log
                if 'neon' in mode:
                    log=r.run(p,'neon-tests',['cargo','test','--locked','--release','--target-dir',str(target/'neon-tests'),'--features','experimental-loudness-neon','--lib','--','--nocapture'],slot/'true-peak');assert 'NEON_KERNEL_EXECUTED' in log and 'NEON_DISPATCH_EXECUTED' in log
            done=r.stage('20-build-'+mode,build)
            if done:binaries[mode]=done
        parity={}
        for mode,path in binaries.items():
            def probe(p,path=path):
                s=r.run(p,'parity',[path/'cp7_parity'],bench=True);lines=[x for x in s.splitlines() if x.startswith('CP7_PARITY\t')];assert len(lines)==60
                (p/'records.sha256').write_text(hashlib.sha256(('\n'.join(lines)+'\n').encode()).hexdigest()+'\n')
                with gzip.open(p/'parity.log.gz','wb') as f:f.write((p/'parity.log').read_bytes())
                (p/'parity.log').unlink()
            done=r.stage('30-parity-'+mode,probe)
            if done:parity[mode]=(done/'records.sha256').read_text()
        def parity_gate(p):
            json_write(p/'hashes.json',parity);assert set(parity)==set(modes) and len(set(parity.values()))==1
            if args.layout_control:
                hashes={m:sha(binaries[m]/'numerical_profile') for m in ('base','base-control','default')};json_write(p/'layout-control.json',dict(hashes=hashes,identical_same_source=hashes['base']==hashes['base-control']))
        r.stage('31-parity-gate',parity_gate)
        feat='precision-spectrum,precision-loudness'+(',precision-x87' if x87 else '')
        names=('precision_spectrum_f64le','precision_spectrum_profile','precision_f64le','precision_profile','precision_cross_f64le','precision_noise_f64le','precision_loudness_f64le','precision_batch_profile')
        expected={'1','3'}
        if x87:expected.add('2')
        lower=flags.lower()
        if x86 and 'fma' in lower and 'avx' in lower:
            expected.add('4')
            if 'avx2' in lower:
                expected.add('6')
                if 'avx512f' in lower:expected.add('7')
        if arm:expected.add('8')
        loud_expected=expected-{'6','7','8'}
        def precision(p):
            cargo(p,'build',cand,'audioscopy','wide',['build','--release',*[v for name in names for v in ('--example',name)]],feat)
            for name in names:shutil.copy2(w/'targets'/'wide'/'audioscopy/release/examples'/name,p/name)
        pp=r.stage('40-wide-build',precision)
        if pp:
            for key,folder,driver,avail in (
                ('spectrum','spectrum-qualification','precision_spectrum_f64le',expected),
                ('cross','cross-qualification','precision_cross_f64le',expected),
                ('noise','noise-qualification','precision_noise_f64le',expected),
                ('loudness','loudness-qualification','precision_loudness_f64le',loud_expected)):
                def reference(p,key=key,folder=folder,driver=driver,avail=avail):
                    actual=set(r.run(p,'available',[pp/driver,'--available']).split());assert actual==avail,(actual,avail)
                    json_write(p/'available.json',sorted(actual))
                    cmd=[sys.executable,'-B',ROOT/folder/'reference.py',pp/driver,'--driver']
                    if key=='spectrum':cmd+=['--records-dir',p/'reference-bins']
                    r.run(p,'reference',cmd,p,True)
                r.stage('41-reference-'+key,reference)
            if arm:r.stage('42-correlation-reference',lambda p:r.run(p,'reference',[sys.executable,'-B',ROOT/'qualification-cp7/native_reference.py',pp/'precision_f64le'],p,True))
        else:r.failed.append('missing-wide-binaries')
        cflags=[cc,'-std=c11','-O3','-fno-fast-math','-ffp-contract=off','-frounding-math','-fno-lto','-Wall','-Wextra','-Werror']+(['-DAUDIOSCOPY_ENABLE_X87'] if x87 else [])
        for folder in ('spectrum-qualification','optimization-qualification'):
            def environment(p,folder=folder):
                r.run(p,'build',cflags+['-pthread',ROOT/folder/'environment.c',cand/'audioscopy/native/spectral_precision.c','-lm','-o',p/'environment'])
                r.run(p,'environment',[p/'environment'])
            r.stage('43-environment-'+folder,environment)
        def research_build(p):
            ext='.dylib' if system=='Darwin' else '.so'
            r.run(p,'build',cflags+['-DAUDIOSCOPY_SPECTRAL_RESEARCH','-fPIC','-dynamiclib' if system=='Darwin' else '-shared',cand/'audioscopy/native/spectral_precision.c','-lm','-o',p/('wide'+ext)])
            (p/'library-name.txt').write_text('wide'+ext)
        research=r.stage('44-native-research-build',research_build)
        if research:
            lib=research/(research/'library-name.txt').read_text()
            for folder in ('spectrum-qualification','cross-qualification','noise-qualification','loudness-qualification'):
                r.stage('45-native-reference-'+folder,lambda p,folder=folder:r.run(p,'reference',[sys.executable,'-B',ROOT/folder/'reference.py',lib],p,True))
        else:r.failed.append('missing-research-library')
        if set(binaries)==set(modes):
            groups=[('stereo',768000,2,60),('spectrum',768000,2,6),('stereo_spectral',768000,2,6),('all',48000,2,6),('all',768000,2,60)]
            if arm:groups.extend([('loudness',768000,2,6),('loudness',768000,6,6),('album_loudness',192000,2,6)])
            for group in groups:
                # Prior x86 wide SIMD was qualified in CP7; only relevant
                # focused cohorts need its opt-in combinations now.
                cohort={m:d/'numerical_profile' for m,d in binaries.items() if m in ('base','base-control','default') or group[0] in ('spectrum','stereo_spectral') or (arm and group[0] in ('loudness','album_loudness'))}
                r.stage('50-ordinary-'+'-'.join(map(str,group)),lambda p,g=group,cohort=cohort:timing(r,p,timer,system,cohort,list(map(str,g))))
        else:r.failed.append('missing-ordinary-binaries')
        if pp:
            modes=['0']+sorted(expected,key=int)
            # Auto mode duplicates a forced path: validate it numerically but
            # benchmark only distinct execution paths.
            modes=[m for m in modes if m!='1'];choices={m:pp/'precision_spectrum_profile' for m in modes}
            groups=[(48000,2,6),(192000,2,6),(768000,2,6),(192000,3,3)]
            if args.long:groups.append((768000,2,60))
            for g in groups:r.stage('60-wide-'+'-'.join(map(str,g)),lambda p,g=g:timing(r,p,timer,system,choices,list(map(str,g)),True))
        if pp:
            for kind,rate,ch,seconds in [('cross',48000,2,6),('cross',768000,2,6),('noise',192000,2,6),('loudness',48000,2,6),('loudness',768000,2,6),('loudness',192000,6,6)]+([('cross',768000,2,60),('loudness',768000,2,60)] if args.long else []):
                avail=loud_expected if kind=='loudness' else expected
                choices={m:pp/'precision_batch_profile' for m in sorted(avail-{'1'},key=int)}
                g=(kind,rate,ch,seconds)
                r.stage('65-wide-'+'-'.join(map(str,g)),lambda p,g=g,choices=choices:timing(r,p,timer,system,choices,list(map(str,g)),True))
        if args.perf and pp and system=='Linux':
            def perf(p):
                for m in [x for x in ['0','2','4','6','7','8'] if x in modes]:r.run(p,'mode-'+m,['perf','stat','-e','cycles,instructions,cache-references,cache-misses,branches,branch-misses',pp/'precision_spectrum_profile',m,'768000','2','6'],bench=True)
            r.stage('70-perf',perf,False)
    except BaseException as exc:r.failed.append(repr(exc));raise
    finally:r.package()
    return int(bool(r.failed))

if __name__=='__main__':sys.exit(main())
