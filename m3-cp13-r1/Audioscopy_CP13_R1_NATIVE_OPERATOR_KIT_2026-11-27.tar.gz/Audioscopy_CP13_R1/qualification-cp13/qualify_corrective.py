#!/usr/bin/env python3
"""Close only the four failed CP13 Threadripper gates after the test-only repair.
All previously passing numerical/benchmark evidence remains independently identified.
Run the full qualify_cp13.py on a new architecture or different toolchain.
"""
import argparse
import hashlib
import json
import os
import platform
import shutil
import sys
from pathlib import Path

KIT = Path(__file__).resolve().parent
ROOT = KIT.parent
CORRECTIVE = KIT / 'corrective'
sys.path.insert(0, str(ROOT / 'qualification-cp7'))
from qualify_cp7 import Runner, inventory, json_write, output, sha, verify
from qualify_cp13 import flags_for


TESTS = {'audioscopy/tests/precision_loudness.rs', 'audioscopy/tests/precision_spectrum.rs'}
LICENSES = {f'{crate}/{name}' for crate in ('audioscopy', 'true-peak') for name in ('LICENSE-MIT', 'LICENSE-APACHE')}


def read_manifest(path):
    rows = {}
    for line in path.read_text().splitlines():
        digest, name = line.split('  ', 1)
        assert name not in rows
        rows[name] = digest
    return rows


def check_source(root):
    old_file = CORRECTIVE / 'formatted-source-manifest.txt'
    format_id = json.loads((CORRECTIVE / 'format-identity.json').read_text())
    prior = json.loads((CORRECTIVE / 'prior-identity.json').read_text())
    assert sha(old_file) == format_id['formatted_manifest']
    assert sha(CORRECTIVE / 'prior-operator-manifest.txt') == prior['manifest'] == format_id['input_manifest']
    old = read_manifest(old_file)
    new = read_manifest(CORRECTIVE / 'corrected-source-manifest.txt')
    assert old.keys() - new.keys() == LICENSES
    assert not new.keys() - old.keys()
    assert {n for n in old.keys() & new.keys() if old[n] != new[n]} == TESTS
    actual = {f'{crate}/{n}': h for crate in ('audioscopy', 'true-peak') for n, h in inventory(root / crate).items()}
    assert actual == new, 'corrective source manifest mismatch'
    return prior


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--verify-only', action='store_true')
    ap.add_argument('--work', type=Path)
    ap.add_argument('--prior-evidence', type=Path)
    args = ap.parse_args()
    print('MANIFEST', verify(ROOT, ROOT / 'MANIFEST-SHA256.txt'), flush=True)
    prior = check_source(ROOT)
    print('SOURCE_DELTA PASS (two tests, four obsolete license texts; all production source unchanged)', flush=True)
    if args.verify_only:
        return 0
    if args.work is None or args.prior_evidence is None:
        ap.error('--work and --prior-evidence are required')
    args.work = args.work.expanduser().resolve()
    assert not args.work.is_relative_to(ROOT)
    prior_archive = args.prior_evidence.expanduser().resolve()
    expected = (CORRECTIVE / 'prior-evidence.sha256').read_text().split()[0]
    assert sha(prior_archive) == expected, 'incorrect prior evidence archive'
    env = dict(os.environ)
    for k in env:
        if k in {'RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_BUILD_TARGET','CARGO_TARGET_DIR'} or k.startswith(('CARGO_PROFILE_','CARGO_TARGET_')):
            raise RuntimeError('unset compiler override ' + k)
    rust = output(['rustc', '-vV'])
    cargo = output(['cargo', '--version'])
    fmt = output(['rustfmt', '--version'])
    cc, ar = env.get('CC', 'cc'), env.get('AR', 'ar')
    cc_version = output([cc, '--version'])
    system, arch = platform.system(), platform.machine()
    assert system == 'Linux' and arch == prior['machine'], 'use full CP13 runner on a new architecture'
    flags = flags_for(system, arch)
    assert hashlib.sha256(flags.encode()).hexdigest() == prior['cpu_info_hash'], 'CPU identity changed: use full CP13 runner'
    assert (rust,cargo,fmt,cc_version,cc,ar) == tuple(prior[k] for k in ('rust','cargo','rustfmt','cc_version','cc','ar')), 'toolchain changed: use original Nix shell or full CP13 runner'
    rustflags = [f'--remap-path-prefix={args.work}=/audioscopy-cp13-work']
    env['CARGO_ENCODED_RUSTFLAGS'] = '\x1f'.join(rustflags)
    args.cpu = None
    identity = dict(kind='CP13-R1-focused', manifest=sha(ROOT / 'MANIFEST-SHA256.txt'), corrected_source=sha(CORRECTIVE / 'corrected-source-manifest.txt'), prior_archive=expected, prior_formatted_source=sha(CORRECTIVE / 'formatted-source-manifest.txt'), rust=rust, cargo=cargo, rustfmt=fmt, cc=cc, ar=ar, cc_version=cc_version, host=prior['host'], cpu_info_hash=prior['cpu_info_hash'], os=platform.platform(), codegen='portable', rustflags=rustflags)
    r = Runner(args, identity, env)
    try:
        src = args.work / 'candidate'
        if src.exists():
            shutil.rmtree(src)
        src.mkdir()
        for crate in ('audioscopy', 'true-peak'):
            shutil.copytree(ROOT / crate, src / crate)
        check_source(src)
        def record(p):
            json_write(p / 'reuse.json', dict(prior_archive=expected, prior_status=json.loads((CORRECTIVE / 'prior-status.json').read_text()), source_delta=json.loads((CORRECTIVE / 'source-delta.json').read_text()), scope='four failed gates only; other evidence remains in original return'))
        r.stage('01-reuse-identity', record)
        def hygiene(p):
            errors = []
            for crate in ('audioscopy', 'true-peak'):
                for name, command in [('fmt', ['cargo','fmt','--all','--','--check']), ('clippy',['cargo','clippy','--locked','--target-dir',str(args.work/'targets'/'hygiene'/crate),'--all-targets','--all-features','--','-D','warnings'])]:
                    try:
                        r.run(p, crate + '-' + name, command, src / crate)
                    except Exception as exc:
                        errors.append(str(exc))
            if errors:
                raise RuntimeError('; '.join(errors))
        r.stage('05-hygiene', hygiene)
        def tests(p, tag, feature=None):
            command = ['cargo','test','--release','--locked','--no-fail-fast','--target-dir',str(args.work/'targets'/tag/'audioscopy')]
            command += ['--all-features'] if feature is None else ['--lib','--tests','--features',feature]
            r.run(p,'tests',command,src/'audioscopy')
        r.stage('10-regressions-audioscopy-all-features', lambda p: tests(p,'all-features'))
        for feature in ('precision-spectrum','precision-loudness'):
            r.stage('11-feature-' + feature, lambda p,feature=feature: tests(p,feature,feature))
        def final_source(p):
            check_source(src)
            json_write(p/'source.json', dict(corrected_manifest=identity['corrected_source'], source_preserved=True))
        r.stage('99-source-identity',final_source)
    except BaseException as exc:
        r.failed.append(repr(exc))
        raise
    finally:
        r.package()
    return int(bool(r.failed))


if __name__ == '__main__':
    sys.exit(main())
