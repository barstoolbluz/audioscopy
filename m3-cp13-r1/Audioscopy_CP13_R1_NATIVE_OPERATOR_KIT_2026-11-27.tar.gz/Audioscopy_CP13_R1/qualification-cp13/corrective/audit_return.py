#!/usr/bin/env python3
"""Recompute CP13 return receipts, public parity, paired timing and source identities.
Run against an extracted, checksum-verified CP13 return and the original kit.
"""
import argparse
import gzip
import hashlib
import json
import re
import statistics
from collections import Counter
from pathlib import Path


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def manifest(path):
    rows = {}
    for line in path.read_text().splitlines():
        digest, name = line.split('  ', 1)
        assert name not in rows
        rows[name] = digest
    return rows


def verify(root, rows):
    for name, digest in rows.items():
        p = (root / name).resolve()
        assert p.is_relative_to(root.resolve()) and p.is_file() and sha(p) == digest, name


def audit(evidence, kit):
    entries = manifest(evidence / 'MANIFEST-SHA256.txt')
    verify(evidence, entries)
    actual = {p.relative_to(evidence).as_posix() for p in evidence.rglob('*') if p.is_file()}
    assert actual == set(entries) | {'MANIFEST-SHA256.txt'}
    identity = json.loads((evidence / 'identity.json').read_text())
    kit_manifest = kit / 'MANIFEST-SHA256.txt'
    assert sha(kit_manifest) == identity['manifest']
    verify(kit, manifest(kit_manifest))
    stages = {}
    for p in sorted(evidence.glob('stages/*/attempt-*/receipt.json')):
        r = json.loads(p.read_text())
        verify(p.parent, r['files'])
        actual = {q.relative_to(p.parent).as_posix() for q in p.parent.rglob('*') if q.is_file()}
        assert actual == set(r['files']) | {'receipt.json'}, p
        key = p.parent.parent.name
        assert key not in stages, 'expected one attempt in this original return'
        stages[key] = r['status']
    assert set(json.loads((evidence / 'status.json').read_text())['failed']) == {n for n,s in stages.items() if s == 'FAIL'}
    hashes = {}
    for p in sorted(evidence.glob('stages/30-parity-*/attempt-*/parity.log.gz')):
        with gzip.open(p, 'rt') as f:
            lines = [x for x in f.read().splitlines() if x.startswith('CP7_PARITY\t')]
        assert len(lines) == 60
        h = hashlib.sha256(('\n'.join(lines)+'\n').encode()).hexdigest()
        assert h == (p.parent / 'records.sha256').read_text().strip()
        hashes[p.parent.parent.name.removeprefix('30-parity-')] = h
    assert len(hashes) == 6 and len(set(hashes.values())) == 1
    layout = json.loads((evidence / 'stages/31-parity-gate/attempt-0001/layout-control.json').read_text())
    for mode, h in layout['hashes'].items():
        assert sha(evidence / f'stages/20-build-{mode}/attempt-0001/numerical_profile') == h
    assert len(set(layout['hashes'].values())) == 1
    timings, measured, paired = {}, 0, 0
    reps = identity['reps']
    for p in sorted(evidence.glob('stages/*/attempt-*/raw.json')):
        rows = json.loads(p.read_text())
        summary = json.loads((p.parent / 'summary.json').read_text())
        modes = list(dict.fromkeys(x['mode'] for x in rows))
        by = {(x['pair'],x['mode']):x for x in rows}
        assert len(by) == len(rows) == (reps+1)*len(modes)
        measured += reps*len(modes)
        paired += reps*(len(modes)-1)
        for mode in modes:
            for i in range(-1, reps):
                row = by[i,mode]
                log = (p.parent / f'{i+1:02d}-{mode}.log').read_text()
                assert row['record'] in log
                assert float(re.search(r'PEAK_RSS_KIB=(\d+)',log).group(1)) == row['rss_kib']
                rec = row['record']
                wall = float(re.search(r'wall_s=([0-9.]+)',rec).group(1)) if rec.startswith('WIDE_PROFILE') else float(rec.split('\t')[-1])
                assert wall == row['wall_s']
            s = summary[mode]
            assert s['median_wall_s'] == statistics.median(by[i,mode]['wall_s'] for i in range(reps))
            assert s['median_speedup'] == statistics.median(by[i,modes[0]]['wall_s']/by[i,mode]['wall_s'] for i in range(reps))
            assert s['peak_rss_kib'] == max(by[i,mode]['rss_kib'] for i in range(reps))
        timings[p.parent.parent.name] = summary
    refs = {}
    for p in sorted(evidence.glob('stages/*/attempt-*/reference.log')):
        if not p.parent.parent.name.startswith(('41-reference-','45-native-reference-')):
            continue
        line = p.read_text().splitlines()[-1]
        m = re.fullmatch(r'\w+_REFERENCE_PASS (\d+) comparisons', line)
        assert m, p
        refs[p.parent.parent.name] = int(m.group(1))
    return dict(manifest_entries=len(entries), stages=stages, counts=Counter(stages.values()), parity_hashes=hashes, parity_records=len(hashes)*60, layout=layout, timing_samples=measured, nonreference_pairs=paired, timings=timings, reference_counts=refs)


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('evidence', type=Path)
    ap.add_argument('kit', type=Path)
    args = ap.parse_args()
    print(json.dumps(audit(args.evidence,args.kit),indent=2,sort_keys=True))
