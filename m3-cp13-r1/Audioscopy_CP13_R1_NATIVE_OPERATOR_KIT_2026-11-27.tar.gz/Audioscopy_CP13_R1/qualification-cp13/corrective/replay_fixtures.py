#!/usr/bin/env python3
"""Replay the two corrected fixtures using original CP13 public Rust drivers.
Optional loader supports running Nix-linked executables on another Linux host.
This is execution of existing binaries, not a build/test qualification.
"""
import argparse
import json
import math
import struct
import subprocess
import tempfile
from pathlib import Path


def replay(driver_dir, loader):
    prefix = [loader] if loader else []
    output = {'spectrum': {}, 'loudness': {}}
    def run(driver, *args):
        return subprocess.check_output(prefix + [str(driver_dir / driver), *map(str,args)],text=True).strip()
    with tempfile.TemporaryDirectory() as t:
        file = Path(t) / 'input.f64le'
        pcm = [((i*79%2048)-1024)/2048.0 for i in range(5079)]
        file.write_bytes(struct.pack(f'<{len(pcm)}d',*pcm))
        expected = sum(x*x for x in pcm)/len(pcm)
        results = {}
        for mode in map(int,run('precision_spectrum_f64le','--available').split()):
            if mode == 1:
                continue
            def spectrum(chunk):
                return run('precision_spectrum_f64le',mode,12001,3,chunk,file)
            text = spectrum(127)
            assert text == spectrum(4093)
            header,*bins = text.splitlines()
            assert header == f'SPECTRUM {mode} 2048 1693' and len(bins) == 1025
            def value(line):
                hi,lo,e = line.split()
                f = lambda x: struct.unpack('>d',bytes.fromhex(x))[0]
                return math.ldexp(f(hi)+f(lo),int(e))
            got = sum(value(line) for line in bins)
            assert abs(got-expected) < 1e-14
            results[mode] = bins
            output['spectrum'][mode] = dict(header=header, bins=len(bins), expected=expected, actual=got, chunk_parity=True)
        for mode in (6,7,8):
            if mode in results:
                assert results[mode] == results[4 if 4 in results else 3]
        pcm = [v for i in range(10003) for v in ((.25,-.25) if i%2==0 else (-.25,.25))]
        file.write_bytes(struct.pack(f'<{len(pcm)}d',*pcm))
        for mode in map(int,run('precision_loudness_f64le','--available').split()):
            if mode == 1:
                continue
            def loudness(chunk):
                return run('precision_loudness_f64le',mode,8001,'1,1',chunk,file)
            text = loudness(127)
            assert text == loudness(4093)
            assert text.split()[:7] == ['LOUDNESS',str(mode),'10003','3200','4','9','9']
            output['loudness'][mode] = dict(record=text,chunk_parity=True)
    return output


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('driver_dir',type=Path)
    ap.add_argument('--loader')
    a = ap.parse_args()
    print(json.dumps(replay(a.driver_dir,a.loader),indent=2,sort_keys=True))
