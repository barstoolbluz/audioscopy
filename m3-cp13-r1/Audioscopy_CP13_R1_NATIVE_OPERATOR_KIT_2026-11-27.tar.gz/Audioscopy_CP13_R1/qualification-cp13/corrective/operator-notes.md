# CP13 Threadripper run: operator notes

Date: 2026-11-27. Host: AMD Ryzen Threadripper 7970X, Debian 13, Linux 6.12.
All tools from `nix develop ./qualification-cp7` (Rust 1.99.1, GCC 16.2.0, GNU time).

Kit: `Audioscopy_CP13_NATIVE_OPERATOR_KIT_2026-11-27.tar.gz`
(SHA-256 `7ca8344eff8f049d030aab0bb25cabf5f898a6a37d3cfebb7997e7a900a3f4b1`), run
as delivered, no local deviation. `--verify-only`: MANIFEST 210, CP7_BASELINE 168.
Runner self-tests: 2 pass. The CP8 engineering archive delivered separately has
SHA-256 `9432b5aa...055a38`, equal to `checkpoints/cp8-engineering-archive.sha256`.

Command (OPERATOR.md, inside the Nix shell, without `rustup run`):

    python3 -B qualification-cp13/qualify_cp13.py --work ~/audioscopy-qualification/cp13-portable --cpu 1 --format-candidate --layout-control --long --perf

Evidence: `cp13-portable-evidence-20261127-121432-3146397.tar.gz`
(SHA-256 `67a0b228c61f4e65ab699539493d98d487659397ef042fdd877212b4563ecee8`).
Result: 47 PASS, 4 FAIL, 1 UNAVAILABLE, exit 1.

## Failures: two defects, both in new test files

1. `audioscopy/tests/precision_loudness.rs:45` does not compile (E0271).
   `let run = |chunk| ...` is first called as `run(127)`, so `chunk` is
   inferred as `i32`; `pcm.chunks(chunk * 2)` needs `usize`. Causes:
   `05-hygiene` (audioscopy Clippy), `10-regressions-audioscopy-all-features`,
   `11-feature-precision-loudness`. No precision-loudness Rust test ran.
   Probable fix: `|chunk: usize|`.

2. `audioscopy/tests/precision_spectrum.rs:93`,
   `chunk_boundaries_parseval_and_vector_parity`: `assert_eq!(p.fft_len, 4096)`
   fails with left 2048, right 4096, at 12001 Hz. The documented window rule
   `next_power_of_two(ceil(rate / 6))` gives 2048, so the expectation looks
   wrong; confirm. The other 3 tests in the file and all other
   `precision-spectrum` targets pass.

fmt is clean for both crates (stage 04 format candidate). true-peak Clippy is
clean. Every other stage passes, including builds, parity, the wide spectrum,
cross, noise and loudness references, native C references and environment tests.

`70-perf`: UNAVAILABLE, `kernel.perf_event_paranoid=3`.

## Licence

Both Cargo.toml files are GPL-2.0-or-later and both crates have COPYING, but
both trees still ship `LICENSE-MIT` and `LICENSE-APACHE`. Remove them.
`true-peak/tests/fixtures/LICENSE.gradio-apache-2.0.txt` is a third-party
fixture licence; the owner decides.
