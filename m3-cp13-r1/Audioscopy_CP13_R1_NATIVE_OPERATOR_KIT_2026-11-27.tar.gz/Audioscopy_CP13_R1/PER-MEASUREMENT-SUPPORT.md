# CP13 precision/backend support matrix

All ordinary measurements retain their CP7 qualified source; optional features do not promote ISA dispatch. CP7 patched x86-64 is qualified. CP13 Threadripper public Rust references, native C references and performance stages passed. Two test defects prevented full formal qualification; CP13-R1 corrects them without modifying production code. Focused native corrective and native ARM qualification outstanding. See CP13-R1-REPORT.md.

| Measurement | Ordinary default | Optional precision interface / status |
|---|---|---|
| Stereo Pearson correlation | Conditioned binary64 | `precision`, DD; `precision-x87`, true extended80. CP7 x86 Rust native pass; ARM pending. |
| Average-power spectrum | Binary64 RustFFT/accumulation | `precision-spectrum`, `SpectrumAnalyzer`; wide coefficients, FFT, sums, scaled limbs. x87/DD portable/scalar FMA/AVX2/AVX512; experimental NEON. |
| Stereo complex cross-spectrum | Existing ordinary stereo estimators unchanged | `CrossSpectrumAnalyzer`; per-channel auto power and signed conj(L)*R. Same wider spectral backends, separate channel scaling. |
| Explicit quiet-passages noise floor/bands, effective bits and peak/floor ratio | Existing automatic detector and binary64 estimates | `QuietNoiseAnalyzer`, `QuietNoisePool`; same wider spectral backends, explicit passages, fixed clock; unweighted/A/ITU-R468. |
| Native integrated loudness | Conditioned native binary64 | `precision-loudness`, `WideLoudnessMeter`; x87, portable DD, scalar FMA DD, typed outcome and scaled energy. 3364-2822400 Hz. |
| Existing stereo balance, bass width, delay, mono compatibility, bandwidth, codec/source rate, automatic quiet detection, hum/dither/idle tones, LRA, short-term, libebur128, album processing | CP7 algorithms | No replacement or wider implementation promised. |
| Sample/true peak and exact grid bits in use | Certified/exact CP7 implementations | Unchanged. |

`Extended80` Auto uses x87 on supported native GNU/Linux x86-64 with feature, otherwise DD. DD Auto selects baseline/scalar FMA; AVX2/AVX512/NEON require explicit requests. No silent binary64 downgrade. DD significand does not confer the extended80 exponent range. Native wide spectrum/loudness require supported native C11 target. Linear limbs/exponents preserve more precision than dB/LUFS display, which remains binary64. No universal accuracy guarantee, no recovery of information lost before measurement. Both crates GPL-2.0-or-later, locks unchanged.
