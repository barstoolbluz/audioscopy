#!/usr/bin/env python3
"""Independent Decimal canonical biquad + explicit-window oracle.
The production recurrence is conditioned state space and event cells; this
reference uses direct-form I, full per-frame energies and prefix sums.
"""
import argparse, ctypes as c, decimal as d, functools, json, math, random, struct, subprocess, sys, tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'spectrum-qualification'))
from reference import D, MODES, Bin, Kernel, pi, sincos, decimal_power

class Result(c.Structure):
    _fields_=[('frames',c.c_uint64),('required_frames',c.c_uint64),('absolute_count',c.c_uint64),('relative_count',c.c_uint64),('outcome',c.c_int32),('energy',Bin)]

class LoudKernel(Kernel):
    def __init__(self,path):
        super().__init__(path);l=self.lib
        l.audioscopy_loudness_new.argtypes=[c.c_uint32,c.c_size_t,c.POINTER(c.c_ubyte),c.c_size_t,c.c_int,c.POINTER(c.c_void_p),c.POINTER(c.c_int)];l.audioscopy_loudness_new.restype=c.c_int
        l.audioscopy_loudness_push.argtypes=[c.c_void_p,c.POINTER(c.c_double),c.c_size_t];l.audioscopy_loudness_push.restype=c.c_int
        l.audioscopy_loudness_finish.argtypes=[c.c_void_p,c.POINTER(Result)];l.audioscopy_loudness_finish.restype=c.c_int
        l.audioscopy_loudness_free.argtypes=[c.c_void_p];l.audioscopy_loudness_free.restype=None
        l.audioscopy_loudness_probe.argtypes=[c.c_uint32,c.c_int,c.POINTER(c.c_double),c.c_size_t,c.POINTER(Bin)];l.audioscopy_loudness_probe.restype=c.c_int
    def new(self,rate,weights,mode,limit=4000000):
        p=c.c_void_p();actual=c.c_int();w=(c.c_ubyte*len(weights))(*weights)
        assert self.lib.audioscopy_loudness_new(rate,len(w),w,limit,mode,c.byref(p),c.byref(actual))==1
        return p,actual.value
    def run(self,pcm,rate,weights,mode,chunk):
        p,actual=self.new(rate,weights,mode);ch=len(weights);l=self.lib
        try:
            x=(c.c_double*len(pcm))(*pcm)
            for start in range(0,len(pcm)//ch,chunk):
                take=min(chunk,len(pcm)//ch-start);ptr=c.cast(c.byref(x,start*ch*8),c.POINTER(c.c_double));assert l.audioscopy_loudness_push(p,ptr,take)==1
            r=Result();assert l.audioscopy_loudness_finish(p,c.byref(r))==1
            assert r.frames==len(pcm)//ch and r.required_frames==(2*rate+2)//5
            return (actual,r.outcome,r.absolute_count,r.relative_count,(r.energy.hi,r.energy.lo,r.energy.exponent))
        finally:l.audioscopy_loudness_free(p)
    def probe(self,pcm,rate,mode):
        x=(c.c_double*len(pcm))(*pcm);out=(Bin*len(pcm))();assert self.lib.audioscopy_loudness_probe(rate,mode,x,len(pcm),out)==1
        return [(b.hi,b.lo,b.exponent) for b in out]
    def budget(self):
        p,_=self.new(8000,[1],3,1);l=self.lib
        try:
            x=(c.c_double*5000)(*([.5,-.5]*2500));assert l.audioscopy_loudness_push(p,x,len(x))==-1
            assert l.audioscopy_loudness_push(p,x,1)==0 and l.audioscopy_loudness_finish(p,c.byref(Result()))==0
        finally:l.audioscopy_loudness_free(p)

class Driver:
    def __init__(self,path):self.path=Path(path).resolve()
    def available(self,mode):return str(mode) in subprocess.check_output([str(self.path),'--available'],text=True).split()
    def run(self,pcm,rate,weights,mode,chunk):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'pcm.f64le';p.write_bytes(struct.pack(f'<{len(pcm)}d',*pcm))
            s=subprocess.check_output([str(self.path),str(mode),str(rate),','.join(map(str,weights)),str(chunk),str(p)],text=True).split()
        assert s[0]=='LOUDNESS' and int(s[2])==len(pcm)//len(weights) and int(s[3])==(2*rate+2)//5
        return (int(s[1]),int(s[4]),int(s[5]),int(s[6]),(struct.unpack('>d',bytes.fromhex(s[7]))[0],struct.unpack('>d',bytes.fromhex(s[8]))[0],int(s[9])))

@functools.lru_cache(maxsize=None)
def coefficients(rate,prec):
    with d.localcontext() as ctx:
        ctx.prec=prec;p=pi(prec)
        vh=D(10)**(D('3.999843853973347')/20);vb=vh**D('0.4996667741545416')
        def biquad(f,q,shelf):
            sn,cs=sincos(p*f/rate);k=sn/cs;r=1/q;den=1+k*r+k*k
            a=(2*(k*k-1)/den,(1-k*r+k*k)/den)
            b=((vh+vb*k*r+k*k)/den,2*(k*k-vh)/den,(vh-vb*k*r+k*k)/den) if shelf else (D(1),D(-2),D(1))
            return a,b
        return (biquad(D('38.13547087602444'),D('0.5003270373238773'),False),biquad(D('1681.974450955533'),D('0.7071752369554196'),True))

def filt(pcm,rate,prec=100):
    with d.localcontext() as ctx:
        ctx.prec=prec
        (a,b),(aa,bb)=coefficients(rate,prec)
        x1=x2=y1=y2=z1=z2=D(0);out=[]
        for x in pcm:
            x=x if isinstance(x,D) else D.from_float(x)
            y=b[0]*x+b[1]*x1+b[2]*x2-a[0]*y1-a[1]*y2
            z=bb[0]*y+bb[1]*y1+bb[2]*y2-aa[0]*z1-aa[1]*z2
            x2,x1=x1,x;y2,y1=y1,y;z2,z1=z1,z;out.append(z)
        return out

def window_means(energies,rate):
    w=(2*rate+2)//5;prefix=[D(0)]
    for x in energies:prefix.append(prefix[-1]+x)
    i=0;out=[]
    while (start:=i*rate//10)+w<=len(energies):
        out.append((prefix[start+w]-prefix[start])/w);i+=1
    return out

def gate():return D(10)**((D(-70)+D('.691'))/10)

def oracle(pcm,rate,weights,prec=100):
    with d.localcontext() as ctx:
        ctx.prec=prec;ch=len(weights);n=len(pcm)//ch;zero=D(0);w=(2*rate+2)//5
        if n==0:return 0,0,0,zero
        if n<w:return 1,0,0,zero
        e=[zero]*n
        for i,weight in enumerate(weights):
            if weight:
                factor=D(1) if weight==1 else D('1.41')
                for k,y in enumerate(filt(pcm[i::ch],rate,prec)):e[k]+=factor*y*y
        absolute=[x for x in window_means(e,rate) if x>gate()]
        if not absolute:return 2,0,0,zero
        threshold=sum(absolute)/len(absolute)/10
        relative=[x for x in absolute if x>threshold]
        if not relative:return 3,len(absolute),0,zero
        return 4,len(absolute),len(relative),sum(relative)/len(relative)

def signed(b):
    h,l,e=b;assert math.isfinite(h) and math.isfinite(l) and (h==0 or .5<=abs(h)<=1.0)
    return (D.from_float(h)+D.from_float(l))*D(2)**e

def gate_fixtures():
    rate=8000;w=(2*rate+2)//5;basis=[1. if i%2 else -1. for i in range(w)]
    e=sum(y*y for y in filt(basis,rate))/w;root=float((gate()/e).sqrt());lo=root;hi=root
    for _ in range(16):lo=math.nextafter(lo,0.);hi=math.nextafter(hi,math.inf)
    yield 'absolute_below',rate,[1],[lo*x for x in basis]
    yield 'absolute_above',rate,[1],[hi*x for x in basis]
    # Compute a near-relative-gate crossing from the exact linear response
    # of two disjoint basis segments. No repeated numerical search/filter.
    n=rate*12//10;boundary=rate*6//10
    a=[(.1 if i%2 else -.1) if i<boundary else 0. for i in range(n)]
    b=[0. if i<boundary else (1. if i%2 else -1.) for i in range(n)]
    aa=filt(a,rate);bb=filt(b,rate)
    A=window_means([x*x for x in aa],rate);B=window_means([2*x*y for x,y in zip(aa,bb)],rate);C=window_means([x*x for x in bb],rate)
    def difference(alpha):
        v=[a+b*alpha+c*alpha*alpha for a,b,c in zip(A,B,C)];absolute=[x for x in v if x>gate()];return v[-1]-sum(absolute)/len(absolute)/10
    low=D('.005');high=D('.08');assert difference(low)<0<difference(high)
    for _ in range(100):
        mid=(low+high)/2
        if difference(mid)>0:high=mid
        else:low=mid
    root=float((low+high)/2);lo=root;hi=root
    for _ in range(32):lo=math.nextafter(lo,0.);hi=math.nextafter(hi,math.inf)
    yield 'relative_below',rate,[1],[a[i] if i<boundary else lo*b[i] for i in range(n)]
    yield 'relative_above',rate,[1],[a[i] if i<boundary else hi*b[i] for i in range(n)]

def fixtures(quick):
    rng=random.Random(0x43503131)
    yield 'empty',8000,[1],[]
    yield 'insufficient',8000,[1],[.1]*3199
    yield 'silence',8000,[1],[0.]*8000
    yield 'one_window',8000,[1],[.25 if i%2 else -.25 for i in range(3200)]
    yield 'multichannel',12001,[1,1,1,0,2,2],[rng.randrange(-2**23,2**23)*2.**-24 if ch!=3 else 8. for i in range(7201) for ch in range(6)]
    yield 'dc_variation',8000,[1,1],[x for i in range(8001) for x in (.5+(i%31-15)*2.**-40,-.25+(i%19-9)*2.**-43)]
    if not quick:
        for rate in range(8001,8010):
            yield 'odd_clock',rate,[1],[rng.randrange(-2**15,2**15)*2.**-16 for _ in range(rate*7//10)]
        yield from gate_fixtures()

def main():
    p=argparse.ArgumentParser();p.add_argument('path');p.add_argument('--driver',action='store_true');p.add_argument('--quick',action='store_true');a=p.parse_args();lib=Driver(a.path) if a.driver else LoudKernel(a.path);modes=[m for m in (1,2,3,4,5) if lib.available(m)];assert 1 in modes and 3 in modes
    count=0
    with d.localcontext() as ctx:
        ctx.prec=100
        if not a.driver:
            lib.budget();rng=random.Random(47)
            for rate in (3364,3365,8000,44101,768000,2822399,2822400):
                pcm=[.5]+[.25+((i%11)-5)*2.**-40 for i in range(4095)]
                ref=filt(pcm,rate);norm=max(map(abs,ref))
                for mode in modes:
                    got=[signed(b) for b in lib.probe(pcm,rate,mode)];err=max(abs(x-y) for x,y in zip(got,ref))/norm
                    limit=D('4e-15') if mode==2 else D('3e-26') if mode!=5 else D('1e-10')
                    assert err<limit,(rate,mode,err);print(json.dumps(dict(fixture='filter_probe',rate=rate,mode=MODES[mode],max_relative_to_peak=str(err))),flush=True);count+=1
        for name,rate,weights,pcm in fixtures(a.quick):
            expected=oracle(pcm,rate,weights)
            for mode in modes:
                actual,outcome,ab,rel,b=lib.run(pcm,rate,weights,mode,127);assert (actual,outcome,ab,rel,b)==lib.run(pcm,rate,weights,mode,4093)
                got=decimal_power(b);err=abs(got-expected[3])/max(expected[3],D('1e-1000'))
                limit=D('4e-15') if mode==2 else D('4e-26') if mode!=5 else D('1e-10')
                gate_match=(outcome,ab,rel)==expected[:3]
                if mode!=5 or not name.startswith(('absolute_','relative_')):assert gate_match and err<limit,(name,rate,mode,(outcome,ab,rel),expected,err)
                print(json.dumps(dict(fixture=name,rate=rate,mode=MODES[mode],actual=actual,frames=len(pcm)//len(weights),outcome=outcome,absolute=ab,relative=rel,reference=list(expected[:3]),energy_ref=str(expected[3]),energy_got=str(got),relative_error=str(err),gate_match=gate_match)),flush=True);count+=1
    print(f'LOUDNESS_REFERENCE_PASS {count} comparisons',flush=True)
if __name__=='__main__':main()
