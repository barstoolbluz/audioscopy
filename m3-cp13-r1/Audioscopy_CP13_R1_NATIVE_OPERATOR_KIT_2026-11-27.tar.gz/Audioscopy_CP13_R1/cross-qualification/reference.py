#!/usr/bin/env python3
"""CP9 independent Decimal full-complex DIF and sparse direct-DFT cross oracle.

Exact decoded PCM, full complex FFT (not the packed-real production graph).
All four signed/scaled components are compared separately. The normalization
reference never rounds small channel energies through binary64.
"""
import argparse, ctypes as c, decimal as d, hashlib, json, math, random, struct, subprocess, sys, tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'spectrum-qualification'))
from reference import D, MODES, Bin, Kernel, coefficients, fft_dif, fft_len, sincos, pi

class CrossBin(c.Structure):
    _fields_=[(name,Bin) for name in ('left','right','real','imag')]

class CrossKernel(Kernel):
    def __init__(self,path):
        super().__init__(path)
        self.lib.audioscopy_cross_new.argtypes=[c.c_uint32,c.c_int,c.POINTER(c.c_void_p),c.POINTER(c.c_size_t),c.POINTER(c.c_int)]
        self.lib.audioscopy_cross_new.restype=c.c_int
        self.lib.audioscopy_cross_finish.argtypes=[c.c_void_p,c.POINTER(CrossBin),c.c_size_t]
        self.lib.audioscopy_cross_finish.restype=c.c_int
    def run(self,pcm,rate,mode,chunk):
        p=c.c_void_p();n=c.c_size_t();actual=c.c_int()
        assert self.lib.audioscopy_cross_new(rate,mode,c.byref(p),c.byref(n),c.byref(actual))==1
        try:
            assert n.value==fft_len(rate)
            data=(c.c_double*len(pcm))(*pcm)
            for start in range(0,len(pcm)//2,chunk):
                take=min(chunk,len(pcm)//2-start)
                ptr=c.cast(c.byref(data,start*16),c.POINTER(c.c_double))
                assert self.lib.audioscopy_spectral_push(p,ptr,take)==1
            bins=(CrossBin*(n.value//2+1))()
            assert self.lib.audioscopy_cross_finish(p,bins,len(bins))==1
            return actual.value,[tuple((b.hi,b.lo,b.exponent) for b in (x.left,x.right,x.real,x.imag)) for x in bins]
        finally:self.lib.audioscopy_spectral_free(p)

class Driver:
    def __init__(self,path):self.path=Path(path).resolve()
    def available(self,mode):return str(mode) in subprocess.check_output([str(self.path),'--available'],text=True).split()
    def run(self,pcm,rate,mode,chunk):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'pcm.f64le';p.write_bytes(struct.pack(f'<{len(pcm)}d',*pcm))
            rows=subprocess.check_output([str(self.path),str(mode),str(rate),str(chunk),str(p)],text=True).splitlines()
        h=rows.pop(0).split();assert h[0]=='CROSS' and int(h[2])==fft_len(rate) and int(h[3])==len(pcm)//2
        def parse(row):
            q=row.split();assert len(q)==12
            return tuple((struct.unpack('>d',bytes.fromhex(q[i]))[0],struct.unpack('>d',bytes.fromhex(q[i+1]))[0],int(q[i+2])) for i in range(0,12,3))
        return int(h[1]),[parse(row) for row in rows]

def signed(b):
    h,l,e=b
    assert math.isfinite(h) and math.isfinite(l) and (h==0 or .5<=abs(h)<=1) and abs(l)<=math.ulp(h)
    assert h!=0 or (l==0 and e==0)
    return (D.from_float(h)+D.from_float(l))*D(2)**e

def signature(bins):return b''.join(struct.pack('<ddi',*b) for x in bins for b in x)

def oracle(pcm,rate,prec):
    with d.localcontext() as ctx:
        ctx.prec=prec;n=fft_len(rate);h=n//2;length=len(pcm)//2;w,roots=coefficients(n,prec)
        x=[D.from_float(v) for v in pcm];acc=[[D(0)]*4 for _ in range(h+1)]
        for start in range(-h,length,h):
            f=[fft_dif([x[(start+i)*2+ch]*w[i] if 0<=start+i<length else D(0) for i in range(n)],roots) for ch in range(2)]
            for k in range(h+1):
                a,b=f[0][k];c,e=f[1][k];v=(a*a+b*b,c*c+e*e,a*c+b*e,a*e-b*c);wt=1 if k in (0,h) else 2
                for j in range(4):acc[k][j]+=wt*v[j]
        den=D(n)*length
        return [[z/den for z in row] for row in acc]

def fixtures():
    rng=random.Random(0x435039);h=fft_len(8000)//2;tiny=float.fromhex('0x0.0000000000001p-1022')
    yield 'zero',8000,[0.0]*30
    yield 'short_pcm32',8000,[rng.randrange(-2**31,2**31)*2.**-31 for _ in range(82)]
    yield 'delayed_impulses',8000,[v for i in range(h+19) for v in (.5 if i in (17,h+2) else 0.,-.25 if i in (21,h+6) else 0.)]
    yield 'anticorrelation',8000,[v for i in range(h+27) for v in ((i%19-9)/32,-(i%19-9)/32)]
    yield 'asymmetric_subnormal',8000,[v for i in range(73) for v in ((i%7-3)/8,(i%5-2)*tiny)]
    yield 'irregular_partial',12001,[rng.randrange(-2**15,2**15)*2.**-15 for _ in range(2*1067)]
    yield 'independent_scale_jump',8000,[v for i in range(h+19) for v in ((i%11-5)*2.**(-120 if i<h else -4),(i%7-3)*2.**(-100 if i<h else -200))]
    yield 'one_silent',8000,[v for i in range(h+3) for v in (0.,(i%9-4)/16)]

def verify(lib,modes,name,rate,pcm,ref):
    # Cross scale uses the geometric mean of channel-peak auto powers,
    # not max(L,R), which would conceal the very small channel.
    with d.localcontext() as ctx:
        ctx.prec=110
        lp=max(r[0] for r in ref);rp=max(r[1] for r in ref);cp=(lp*rp).sqrt()
        norm=[lp or D('1e-1000'),rp or D('1e-1000'),cp or D('1e-1000'),cp or D('1e-1000')]
        scalar=None
        for mode in modes:
            actual,bins=lib.run(pcm,rate,mode,127);other=lib.run(pcm,rate,mode,4093)
            assert len(bins)==len(ref) and actual==other[0] and signature(bins)==signature(other[1]),(name,mode,'chunk parity')
            if mode in (3,4):scalar=signature(bins)
            if mode in (6,7,8) and scalar is not None:assert signature(bins)==scalar,(name,mode,'vector parity')
            got=[[signed(b) for b in row] for row in bins]
            err=[max(abs(a[j]-b[j]) for a,b in zip(got,ref))/norm[j] for j in range(4)]
            limit=D('3e-16') if mode==2 else D('4e-28') if mode!=5 else D('4e-13')
            assert max(err)<limit,(name,mode,err)
            assert all(a[0]>=0 and a[1]>=0 for a in got)
            assert got[0][3]==got[-1][3]==0
            # Cross Parseval, with independently normalized channel energies.
            exact=sum(D.from_float(a)*D.from_float(b) for a,b in zip(pcm[::2],pcm[1::2]))/(len(pcm)//2)
            errparse=abs(sum(a[2] for a in got)-exact)/(norm[2]*len(ref))
            assert errparse<limit,(name,mode,errparse)
            print(json.dumps(dict(fixture=name,mode=MODES[mode],actual=actual,rate=rate,frames=len(pcm)//2,error=[str(v) for v in err],cross_parseval_scaled_error=str(errparse),sha256=hashlib.sha256(signature(bins)).hexdigest())),flush=True)

def main():
    p=argparse.ArgumentParser();p.add_argument('path');p.add_argument('--driver',action='store_true');p.add_argument('--quick',action='store_true');a=p.parse_args();lib=Driver(a.path) if a.driver else CrossKernel(a.path)
    modes=[m for m in MODES if lib.available(m)];assert 1 in modes and 3 in modes
    count=0
    for name,rate,pcm in fixtures():
        if a.quick and name not in ('short_pcm32','asymmetric_subnormal','delayed_impulses'):continue
        ref=oracle(pcm,rate,104);verify(lib,modes,name,rate,pcm,ref);count+=len(modes)
    print(f'CROSS_REFERENCE_PASS {count} comparisons',flush=True)
if __name__=='__main__':main()
