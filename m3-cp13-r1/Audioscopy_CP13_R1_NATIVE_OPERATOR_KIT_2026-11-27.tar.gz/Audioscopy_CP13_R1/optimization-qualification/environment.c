/* SPDX-License-Identifier: GPL-2.0-or-later
 * All wider measurement APIs: environment isolation and concurrency.
 * On x86 compare the exact control/status words and MXCSR before and after
 * every call, including forced 24-bit x87, FTZ, DAZ and sticky exceptions.
 */
#define _POSIX_C_SOURCE 200809L
#include <fenv.h>
#include <math.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../audioscopy/native/spectral_precision.h"
#define check(ok) do { if(!(ok)){fprintf(stderr,"environment test failed at line %d: %s\n",__LINE__,#ok);abort();} } while(0)
struct environment { int round,flags;
#if defined(__x86_64__)
    unsigned short cw,sw; unsigned int mxcsr;
#endif
};
static struct environment snapshot(void) {
    struct environment e={0};e.round=fegetround();e.flags=fetestexcept(FE_ALL_EXCEPT);
#if defined(__x86_64__)
    __asm__ volatile("fnstcw %0" : "=m"(e.cw) :: "memory");
    __asm__ volatile("fnstsw %0" : "=am"(e.sw) :: "memory");
    __asm__ volatile("stmxcsr %0" : "=m"(e.mxcsr) :: "memory");
#endif
    return e;
}
static void same_at(struct environment a,int line) {
    (void)line;
    struct environment b=snapshot();check(a.round==b.round && a.flags==b.flags);
#if defined(__x86_64__)
    if(a.cw!=b.cw || a.sw!=b.sw || a.mxcsr!=b.mxcsr){fprintf(stderr,"caller line %d cw %x %x sw %x %x mxcsr %x %x\n",line,a.cw,b.cw,a.sw,b.sw,a.mxcsr,b.mxcsr);abort();}
#endif
}
#define same(e) same_at(e,__LINE__)
static void bin_equal(struct ac_spectral_bin a,struct ac_spectral_bin b){
    check(memcmp(&a.hi,&b.hi,sizeof(double))==0 && memcmp(&a.lo,&b.lo,sizeof(double))==0 && a.exponent==b.exponent);
}
struct results { struct ac_cross_bin cross[1025];struct ac_spectral_bin noise[6];struct ac_loudness_result loud; };
static void measure(int mode,const double *pcm,struct results *out,struct environment e){
    void *p=NULL;size_t n=0;int actual=0;struct ac_spectral_bin bins[1025];
    check(audioscopy_cross_new(8000,mode,&p,&n,&actual)==1 && n==2048);same(e);
    check(audioscopy_spectral_push(p,pcm,17)==1);same(e);
    check(audioscopy_spectral_push(p,pcm+34,3184)==1);same(e);
    check(audioscopy_cross_finish(p,out->cross,1025)==1);same(e);
    audioscopy_spectral_free(p);same(e);
    for(size_t i=0;i<1025;++i)bins[i]=out->cross[i].left;
    check(audioscopy_noise_new(8000,mode,2,2,&p,&actual)==1);same(e);
    check(audioscopy_noise_add(p,bins,1025,3201)==1);same(e);
    check(audioscopy_noise_finish(p,out->noise,6)==1);same(e);
    audioscopy_noise_free(p);same(e);
    if(mode<=4){
        unsigned char weights[2]={1,1};
        check(audioscopy_loudness_new(8000,2,weights,10,mode,&p,&actual)==1);same(e);
        check(audioscopy_loudness_push(p,pcm,17)==1);same(e);
        check(audioscopy_loudness_push(p,pcm+34,3184)==1);same(e);
        check(audioscopy_loudness_finish(p,&out->loud)==1);same(e);
        audioscopy_loudness_free(p);same(e);
    }
}
struct worker {int mode,round;const double *pcm;const struct results *ref;};
static void *run(void *v){
    struct worker *w=v;fenv_t initial;check(fegetenv(&initial)==0);check(fesetround(w->round)==0);check(feraiseexcept(FE_INEXACT|FE_UNDERFLOW)==0);
#if defined(__x86_64__)
    unsigned short cw;unsigned int mxcsr;
    __asm__ volatile("fnstcw %0" : "=m"(cw) :: "memory");cw&=~0x0300u;
    __asm__ volatile("fldcw %0" :: "m"(cw) : "memory");
    __asm__ volatile("stmxcsr %0" : "=m"(mxcsr) :: "memory");mxcsr|=0x8040u;
    __asm__ volatile("ldmxcsr %0" :: "m"(mxcsr) : "memory");
#endif
    struct environment e=snapshot();struct results *out=calloc(1,sizeof(*out));check(out!=NULL);
    for(int repeat=0;repeat<4;++repeat){
        measure(w->mode,w->pcm,out,e);
        for(size_t i=0;i<1025;++i){bin_equal(out->cross[i].left,w->ref->cross[i].left);bin_equal(out->cross[i].right,w->ref->cross[i].right);bin_equal(out->cross[i].real,w->ref->cross[i].real);bin_equal(out->cross[i].imag,w->ref->cross[i].imag);}
        for(size_t i=0;i<6;++i)bin_equal(out->noise[i],w->ref->noise[i]);
        if(w->mode<=4){check(out->loud.outcome==w->ref->loud.outcome && out->loud.absolute_count==w->ref->loud.absolute_count && out->loud.relative_count==w->ref->loud.relative_count && out->loud.frames==w->ref->loud.frames);bin_equal(out->loud.energy,w->ref->loud.energy);}
    }
    free(out);check(fesetenv(&initial)==0);return NULL;
}
int main(void){
    double pcm[6402];uint32_t rng=0x3e14b7c1u;
    for(size_t i=0;i<6402;++i){rng=rng*1664525u+1013904223u;pcm[i]=((double)(rng>>8)-8388608.0)*0x1p-24;}
    pcm[0]=0x0.0000000000001p-1022;pcm[1]=-0x0.0000000000001p-1022;
    const int rounds[]={FE_TONEAREST,FE_DOWNWARD,FE_UPWARD,FE_TOWARDZERO};int tested=0;
    struct results *ref=calloc(1,sizeof(*ref));check(ref!=NULL);
    for(int mode=1;mode<=8;++mode){
        if(mode==5 || !audioscopy_spectral_available(mode))continue;
        fprintf(stderr,"testing mode=%d\n",mode);measure(mode,pcm,ref,snapshot());
        pthread_t threads[4];struct worker workers[4];
        for(int j=0;j<4;++j){workers[j]=(struct worker){mode,rounds[j],pcm,ref};check(pthread_create(&threads[j],NULL,run,&workers[j])==0);}
        for(int j=0;j<4;++j)check(pthread_join(threads[j],NULL)==0);
        ++tested;
    }
    free(ref);printf("WIDE_ENVIRONMENT_PASS %d backends, %d concurrent measurement sequences\n",tested,tested*16);return 0;
}
