# CP8: end-to-end wide average spectrum and CP7 native evidence

2026-11-27. Engineering checkpoint, not native Rust release approval.

## CP7 return

Both nested evidence archives and the outer handoff passed SHA-256; 3,520 manifest entries and stage receipt inventories verified. The first run failed rustfmt; the second passed all required stages (40 PASS, perf UNAVAILABLE). Both reported 490 test passes, zero failures, six ignored. These counts sum feature configurations, not unique tests. Recomputed 1,100 paired ratios and 840 public parity records, and verified 150 exact reference results across the two runs. The exact second-run source was reconstructed by applying the supplied GNU-time runner correction and four-file pinned rustfmt patch to the delivered CP7 operator kit. The resulting manifest SHA-256 is 8af5c7c197eae65b58a2e93bdbf3590fc231f16ea3dcc151e4e0fb938880f60b, equal to the passed receipt. The frozen reconstructed source is in qualification-cp8/cp7-qualified-baseline.tar.gz. Ordinary crate DSP code and locks are unchanged in CP8. The returned CP7 evidence does not establish ARM native execution or hardware counters.

Both x86 runs show a worthwhile roughly 10-16% stereo-spectral improvement from split processing. The incremental AVX-512 benefit over AVX2 is not consistent. Identical baseline source in distinct run directories also moves by several percent, so do not attribute all observed differences to the candidate's instructions. CP8 keeps existing experimental flags opt-in pending ARM and isolated layout-control comparisons. Both raw runs' timing and reference records and audit are under prior-evidence/cp7-returned. The original full native return (including bulky duplicate binaries and raw compressed parity output) is not duplicated; preserve it separately.

## New kernel

Optional `precision-spectrum` adds a separate streaming API for the mathematical average-power spectrum, not a replacement for Analyzer or the spectral estimators. `precision-x87` additionally permits actual GNU/Linux x86-64 extended80. `DoubleDouble` auto-selects baseline or scalar x86 FMA; forced AVX2 and AVX-512 are available only on supporting CPUs. C11 is compiled only for explicitly requested spectrum support on the documented native targets; no new Cargo dependencies. No implicit binary64 downgrade. Precision selection and actual backend are explicit.

The kernel uses the same FFT geometry (next power of two of ceil(rate/6)), half-hop sine-of-Hann window, edge padding and normalization by real frames and channels. It uses a packed-real radix-2 FFT, genuine wide coefficient generation, wide power and compensated accumulation, not a widened sum of binary64 RustFFT outputs. Independent butterflies share SIMD lanes without reordering the scalar arithmetic graph. Explicit FMA implements the product residual; contraction elsewhere is disabled. Each result bin contains two binary64 limbs and a separate exponent. A zero bin has zero exponent; the dBFS view uses a binary64 logarithm. Results are linear power per bin, not power spectral density or the existing chart grid. The existing estimator's window leakage and finite input resolution remain fundamental. Double-double significand is approximately 106 bits but its internal exponent is binary64: normalization and scaled outputs preserve all-subnormal tracks, not arbitrary relative dynamic range. No wide cross-spectrum, loudness, noise-floor or album claim.

## Independent executable research

The actual new native C code (not merely an analogue) was compiled on a Linux x86-64 Xeon Platinum 8573C environment with GCC and Clang using strict floating-point flags. No Rust toolchain or ARM machine here. `spectrum-qualification/reference.py` uses exact input floats, 88/112-digit Decimal, Machin pi, independently summed sine and cosine, full complex DIF FFT, direct DFT spot checks, Parseval and an independent sparse high-rate DFT. Nine fixture groups including the 131072-point sparse oracle, irregular rates, multichannel PCM32, short/partial windows and all-subnormal inputs; 63 comparisons per compiler, 126 total. Final quick replay also preserved raw output limbs for 21 comparisons. Both vector modes exactly match scalar FMA limbs for tested fixtures and chunk geometries. `verify_constants.py` independently reconstructs all 21 rational/Decimal coefficient pairs. GCC and Clang environment tests each passed 192 concurrent plans with varied rounding, x87 precision controls, FTZ/DAZ and sticky exception state. GCC ASan+UBSan passed the same test. See raw logs, actual binaries, ISA excerpts, source, and reproducible commands in spectrum-qualification.

The near-null DC reference is 5.5408964140814658e-40, about -392.56 dBFS in that bin. Research binary64 packed FFT returns zero; x87 returns 5.537378018118268e-40 (relative error ~6.35e-4); DD returns 5.5408964140814660e-40 (~4.26e-17 relative error). Not a universal spectral resolution floor or a comparison with production RustFFT. All-subnormal input produces nonzero power ~4.72616e-648 in the DC bin, preserved by independent exponent representation.

Three measured repetitions plus warmup, rotating mode order and CPU pin 2, identical research PCM fixture. Corrected Linux RSS reads the process's post-exec VmHWM. The initial cohort with inherited launcher RSS is retained but excluded. Median total seconds (construction, ingestion, finalization):

| Rate / duration | Research f64 | x87 | DD portable | DD scalar FMA | DD AVX2 | DD AVX-512 |
|---|---:|---:|---:|---:|---:|---:|
| 48 kHz / 6s stereo | .0179 | .0866 | .2145 | .1970 | .1361 | .1381 |
| 192 kHz / 6s stereo | .0759 | .3929 | .9810 | .8820 | .5928 | .5818 |
| 768 kHz / 1s stereo | .0629 | .3308 | .9157 | .8634 | .5798 | .5591 |

At 768 kHz, corrected RSS ~8.7 MiB research f64, ~12.7 MiB x87/DD. Ratios of median times for DD vector versus scalar FMA ~1.49x and 1.54x. The longer high-rate and odd-channel performance cohorts did not complete within the execution budget here; they are in the native runner. These are native C timings on this host, not full Rust throughput or Threadripper predictions.

## Remaining qualification

CP8 Rust build, formatting, clippy, FFI integration and throughput not executed here. The CP7 x86 native result remains the trusted baseline. Native ARM NEON and portable DD execution remain required. The CP8 focused runner reuses receipt machinery and immutable source manifests, uses a fixed serial source/build slot and path remapping for ordinary baseline/candidate, optionally repeats the identical-source control, tests public parity, regression and exact-input reference, records raw timing and RSS, and reports unavailable perf honestly. No automatic promotion or formatting rewrite. Long cohort optional. Return failures and exact patches, not just a summary. Further high-precision cross-spectrum, loudness and noise estimators are outside this checkpoint; downstream TonePoet qualification remains outstanding.
