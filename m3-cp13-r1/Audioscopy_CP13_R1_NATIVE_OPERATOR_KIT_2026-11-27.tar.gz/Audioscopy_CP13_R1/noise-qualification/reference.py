#!/usr/bin/env python3
"""Independent exact-input wide noise reduction oracle. Decimal analytic
A and ITU-R468 weights, disjoint band edges, duration-weighted linear pooling.
Test both native synthetic spectra and end-to-end quiet PCM passages."""
import argparse, ctypes as c, decimal as d, json, math, random, struct, subprocess, sys, tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'spectrum-qualification'))
from reference import D, MODES, Bin, Kernel, fft_len, oracle, decimal_power

class NoiseKernel(Kernel):
    def __init__(self,path):
        super().__init__(path);l=self.lib
        l.audioscopy_noise_new.argtypes=[c.c_uint32,c.c_int,c.c_int,c.c_int,c.POINTER(c.c_void_p),c.POINTER(c.c_int)];l.audioscopy_noise_new.restype=c.c_int
        l.audioscopy_noise_add.argtypes=[c.c_void_p,c.POINTER(Bin),c.c_size_t,c.c_uint64];l.audioscopy_noise_add.restype=c.c_int
        l.audioscopy_noise_finish.argtypes=[c.c_void_p,c.POINTER(Bin),c.c_size_t];l.audioscopy_noise_finish.restype=c.c_int
        l.audioscopy_noise_free.argtypes=[c.c_void_p];l.audioscopy_noise_free.restype=None
    def reduce(self,passages,rate,mode,view,weight):
        p=c.c_void_p();actual=c.c_int();l=self.lib
        assert l.audioscopy_noise_new(rate,mode,view,weight,c.byref(p),c.byref(actual))==1
        try:
            for frames,bins in passages:
                array=(Bin*len(bins))(*(Bin(*b) for b in bins));assert l.audioscopy_noise_add(p,array,len(bins),frames)==1
            out=(Bin*6)();assert l.audioscopy_noise_finish(p,out,6)==1
            return actual.value,[(b.hi,b.lo,b.exponent) for b in out]
        finally:l.audioscopy_noise_free(p)
    def pcm(self,passages,rate,ch,mode,view,weight,chunk):
        return self.reduce([(len(p)//ch,self.run(p,rate,ch,mode,chunk)[1]) for p in passages if len(p)//ch>=math.ceil(.05*rate)],rate,mode,view,weight)
    def invalid(self):
        l=self.lib;p=c.c_void_p();a=c.c_int();assert l.audioscopy_noise_new(8000,3,2,0,c.byref(p),c.byref(a))==1
        try:
            bins=(Bin*1025)();bins[5]=Bin(float('nan'),0,0)
            assert l.audioscopy_noise_add(p,bins,1025,1000)==0
            assert l.audioscopy_noise_add(p,bins,1025,1000)==0
            assert l.audioscopy_noise_finish(p,(Bin*6)(),6)==0
        finally:l.audioscopy_noise_free(p)

class Driver:
    def __init__(self,path):self.path=Path(path).resolve()
    def available(self,mode):return str(mode) in subprocess.check_output([str(self.path),'--available'],text=True).split()
    def pcm(self,passages,rate,ch,mode,view,weight,chunk):
        with tempfile.TemporaryDirectory() as t:
            files=[]
            for i,p in enumerate(passages):
                f=Path(t)/f'{i}.pcm';f.write_bytes(struct.pack(f'<{len(p)}d',*p));files.append(f)
            rows=subprocess.check_output([str(self.path),str(mode),str(rate),str(ch),str(view),str(weight),str(chunk),*map(str,files)],text=True).splitlines()
        h=rows.pop(0).split();assert h[0]=='NOISE' and int(h[2])==sum(len(p)//ch for p in passages if len(p)//ch>=math.ceil(.05*rate))
        assert len(rows)==6
        return int(h[1]),[(0.,0.,0) if s=='na' else (struct.unpack('>d',bytes.fromhex(s.split()[0]))[0],struct.unpack('>d',bytes.fromhex(s.split()[1]))[0],int(s.split()[2])) for s in rows]

def weight_power(f,w):
    if not w:return D(1)
    if not f:return D(0)
    s=f*f
    if w==1:
        a=D(12194)**2*s*s/((s+D('20.6')**2)*((s+D('107.7')**2)*(s+D('737.9')**2)).sqrt()*(s+D(12194)**2))
        return a*a*D(10)**D('.2')
    a=1+D('-1.363894795463638e-7')*s+D('2.043828333606125e-15')*s**2+D('-4.737338981378384e-24')*s**3
    b=D('5.559488023498642e-4')*f+D('-2.118150887518656e-11')*f**3+D('1.306612257412824e-19')*f**5
    return (D('1.246332637532143e-4')*f)**2/(a*a+b*b)*D(10)**D('1.822')

def ref(passages,rate,view,weight):
    ny=D(rate)/2;lo=D(0 if view==2 else 20);hi=min(D(20000),ny) if view==0 else ny;df=D(rate)/fft_len(rate)
    intervals=[(lo,hi)]+[(max(lo,D(a)),min(hi,D(b))) for a,b in zip([20,200,2000,10000,20000],[200,2000,10000,20000,'Infinity'])]
    total=[D(0)]*6;frames=sum(fr for fr,_ in passages)
    for fr,bins in passages:
        for k,p in enumerate(bins):
            if not p:continue
            f=k*df;w=weight_power(f,weight)
            for i,(a,b) in enumerate(intervals):
                if b>a and f>=a and (f<b or f==b==ny):total[i]+=p*w*fr
    return [x/frames for x in total]

def compare(name,rate,mode,view,weight,actual,bins,expected,strict=False):
    got=[decimal_power(b) for b in bins];limit=D('4e-16') if mode==2 else D('5e-28') if mode!=5 else D('5e-13')
    errors=[abs(a-b)/max(abs(b),D('1e-10000')) for a,b in zip(got,expected)]
    if not strict:
        norm=max(max(expected),D('1e-10000'));errors=[abs(a-b)/norm for a,b in zip(got,expected)]
    assert max(errors)<limit,(name,mode,view,weight,errors)
    print(json.dumps(dict(fixture=name,mode=MODES[mode],actual=actual,rate=rate,view=view,weight=weight,max_error=str(max(errors)),floor_ref=str(expected[0]),floor_got=str(got[0]))),flush=True)

def main():
    p=argparse.ArgumentParser();p.add_argument('path');p.add_argument('--driver',action='store_true');p.add_argument('--quick',action='store_true');a=p.parse_args();lib=Driver(a.path) if a.driver else NoiseKernel(a.path);modes=[m for m in MODES if lib.available(m)];assert 1 in modes and 3 in modes
    rows=0
    with d.localcontext() as ctx:
        ctx.prec=110
        if not a.driver:
            lib.invalid()
            # Sparse imported bins with a quiet absolute band below f64,
            # tiny contributions beside much larger power in another band,
            # and an exact Nyquist boundary. Compare each nonzero band.
            for rate in (8000,40000,48000,768000):
                n=fft_len(rate);k=[0,1,int(20*n/rate),int(200*n/rate),int(2000*n/rate),int(10000*n/rate),int(20000*n/rate),n//2];k=sorted(set(i for i in k if 0<=i<=n//2))
                passages=[]
                for fr,shift in [(611,-2),(1739,0)]:
                    bins=[(0.,0.,0)]*(n//2+1)
                    for j,i in enumerate(k):bins[i]=(.625,2.**-56,-2200+150*j+shift)
                    passages.append((fr,bins))
                exact=[(f,[decimal_power(b) for b in bins]) for f,bins in passages]
                for view in range(3):
                    for weight in range(3):
                        expected=ref(exact,rate,view,weight)
                        for mode in modes:
                            actual,bins=lib.reduce(passages,rate,mode,view,weight);compare('synthetic',rate,mode,view,weight,actual,bins,expected,True);rows+=1
        rng=random.Random(0x43503130);tiny=float.fromhex('0x0.0000000000001p-1022')
        fixtures=[('subnormal_passages',8000,1,[[tiny*(i%7-3) for i in range(401)],[tiny*(i%11-5) for i in range(719)],[0.5]*70]),('pcm32_passages',12001,2,[[rng.randrange(-2**10,2**10)*2.**-31 for _ in range(2*631)],[rng.randrange(-2**8,2**8)*2.**-31 for _ in range(2*903)],[.25]*30])]
        if a.quick:fixtures=fixtures[:1]
        for name,rate,ch,passages in fixtures:
            exact=[(len(p)//ch,oracle(p,rate,ch,104,False)[0]) for p in passages if len(p)//ch>=math.ceil(.05*rate)]
            for view,weight in [(2,0),(0,1),(1,2)]:
                expected=ref(exact,rate,view,weight)
                for mode in modes:
                    actual,bins=lib.pcm(passages,rate,ch,mode,view,weight,127);other=lib.pcm(passages,rate,ch,mode,view,weight,4093);assert (actual,bins)==other
                    compare(name,rate,mode,view,weight,actual,bins,expected);rows+=1
    print(f'NOISE_REFERENCE_PASS {rows} comparisons',flush=True)
if __name__=='__main__':main()
