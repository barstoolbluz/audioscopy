//! Private same-graph SIMD candidates for loudness arithmetic.
//!
//! x86_64 production dispatch is commissioned after bitwise differential
//! qualification and repeatable release-build net-benefit measurement:
//! scalar for one channel, SSE2 for two and three, AVX for four or more
//! (each falling back to the narrower ISA when unavailable).

use super::k_weighting::{FilterState, KWeightingCoefficients};
use super::LoudnessSimdBackend;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(super) struct Backend(BackendKind);

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum BackendKind {
    Scalar,
    #[cfg(target_arch = "x86_64")]
    Sse2,
    /// Production for four or more channels since the 2026-09-19
    /// re-attestation; SSE2 remains production for two and three.
    #[cfg(target_arch = "x86_64")]
    Avx,
    #[cfg(all(target_arch = "aarch64", feature = "experimental-loudness-neon"))]
    Neon,
}

impl Backend {
    pub(super) const fn scalar() -> Self {
        Self(BackendKind::Scalar)
    }

    /// Select only a backend with completed differential and performance
    /// qualification for this production target and channel count.
    ///
    /// Per the 2026-09-19 re-attestation (see `qualification/`): one-lane
    /// meters stay scalar (nothing to pack; the vector path measured slower),
    /// two and three channels use SSE2 (AVX measured slower on stereo), and
    /// four or more channels use AVX, falling back to SSE2 and then scalar
    /// when the host lacks the ISA.
    pub(super) fn production(channels: usize) -> Self {
        #[cfg(target_arch = "x86_64")]
        {
            if channels >= 4 && std::is_x86_feature_detected!("avx") {
                return Self(BackendKind::Avx);
            }
            if channels >= 2 && std::is_x86_feature_detected!("sse2") {
                return Self(BackendKind::Sse2);
            }
        }
        #[cfg(all(target_arch = "aarch64", feature = "experimental-loudness-neon"))]
        if channels >= 2 {
            return Self::neon_if_available().unwrap_or_else(Self::scalar);
        }
        #[cfg(not(target_arch = "x86_64"))]
        let _ = channels;
        Self::scalar()
    }

    pub(super) const fn is_scalar(self) -> bool {
        matches!(self.0, BackendKind::Scalar)
    }

    pub(super) const fn qualification_backend(self) -> LoudnessSimdBackend {
        match self.0 {
            BackendKind::Scalar => LoudnessSimdBackend::Scalar,
            #[cfg(target_arch = "x86_64")]
            BackendKind::Sse2 => LoudnessSimdBackend::Sse2,
            #[cfg(target_arch = "x86_64")]
            BackendKind::Avx => LoudnessSimdBackend::Avx,
            #[cfg(all(target_arch = "aarch64", feature = "experimental-loudness-neon"))]
            BackendKind::Neon => LoudnessSimdBackend::Neon,
        }
    }

    #[cfg(target_arch = "x86_64")]
    pub(super) fn sse2_if_available() -> Option<Self> {
        std::is_x86_feature_detected!("sse2").then_some(Self(BackendKind::Sse2))
    }

    #[cfg(target_arch = "x86_64")]
    pub(super) fn avx_if_available() -> Option<Self> {
        std::is_x86_feature_detected!("avx").then_some(Self(BackendKind::Avx))
    }

    #[cfg(all(target_arch = "aarch64", feature = "experimental-loudness-neon"))]
    pub(super) fn neon_if_available() -> Option<Self> {
        std::arch::is_aarch64_feature_detected!("neon").then_some(Self(BackendKind::Neon))
    }

    #[cfg(test)]
    pub(super) fn best_available() -> Self {
        #[cfg(target_arch = "x86_64")]
        {
            if let Some(backend) = Self::avx_if_available() {
                return backend;
            }
            if let Some(backend) = Self::sse2_if_available() {
                return backend;
            }
        }
        Self::scalar()
    }
}

/// Filter one interleaved frame across independent channel lanes. The caller
/// owns whole-block validation and treats any non-finite returned real-channel
/// value as a terminal numerical failure; the output slice is the caller-owned
/// tentative destination for this frame.
pub(super) fn filter_frame(
    backend: Backend,
    frame: &[f64],
    filters: &mut [FilterState],
    coefficients: KWeightingCoefficients,
    output: &mut [f64],
) {
    // These are soundness checks for the raw-pointer loads/stores in the x86
    // implementations, not merely debug diagnostics.
    assert_eq!(frame.len(), filters.len());
    assert_eq!(frame.len(), output.len());

    match backend.0 {
        BackendKind::Scalar => filter_frame_scalar(frame, filters, coefficients, output),
        #[cfg(all(target_arch = "aarch64", feature = "experimental-loudness-neon"))]
        BackendKind::Neon => filter_frame_scalar(frame, filters, coefficients, output),
        #[cfg(target_arch = "x86_64")]
        BackendKind::Sse2 => {
            // SAFETY: BackendKind::Sse2 is only constructed after the one-time
            // feature check at backend selection; slice geometry is checked by
            // the safe caller and this function never loads past it.
            unsafe { filter_frame_sse2(frame, filters, coefficients, output) }
        }
        #[cfg(target_arch = "x86_64")]
        BackendKind::Avx => {
            // SAFETY: BackendKind::Avx is only constructed after the one-time
            // feature check at backend selection; all groups contain real
            // channels and scalar/SSE2 tails stay in bounds.
            unsafe { filter_frame_avx(frame, filters, coefficients, output) }
        }
    }
}

fn filter_frame_scalar(
    frame: &[f64],
    filters: &mut [FilterState],
    coefficients: KWeightingCoefficients,
    output: &mut [f64],
) {
    for ((sample, filter), out) in frame.iter().zip(filters.iter_mut()).zip(output.iter_mut()) {
        *out = filter.process(*sample, coefficients);
    }
}

#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "sse2")]
unsafe fn filter_frame_sse2(
    frame: &[f64],
    filters: &mut [FilterState],
    coefficients: KWeightingCoefficients,
    output: &mut [f64],
) {
    use std::arch::x86_64::*;

    let a1 = _mm_set1_pd(coefficients.a[1]);
    let a2 = _mm_set1_pd(coefficients.a[2]);
    let a3 = _mm_set1_pd(coefficients.a[3]);
    let a4 = _mm_set1_pd(coefficients.a[4]);
    let b0 = _mm_set1_pd(coefficients.b[0]);
    let b1 = _mm_set1_pd(coefficients.b[1]);
    let b2 = _mm_set1_pd(coefficients.b[2]);
    let b3 = _mm_set1_pd(coefficients.b[3]);
    let b4 = _mm_set1_pd(coefficients.b[4]);

    let mut channel = 0;
    while channel + 2 <= frame.len() {
        let d0 = _mm_set_pd(filters[channel + 1].delay[0], filters[channel].delay[0]);
        let d1 = _mm_set_pd(filters[channel + 1].delay[1], filters[channel].delay[1]);
        let d2 = _mm_set_pd(filters[channel + 1].delay[2], filters[channel].delay[2]);
        let d3 = _mm_set_pd(filters[channel + 1].delay[3], filters[channel].delay[3]);
        let input = _mm_loadu_pd(frame.as_ptr().add(channel));

        // Preserve the scalar left-associated recurrence with separate packed
        // operations. SSE2 has no fused multiply-add instruction.
        let mut z = _mm_sub_pd(input, _mm_mul_pd(a1, d0));
        z = _mm_sub_pd(z, _mm_mul_pd(a2, d1));
        z = _mm_sub_pd(z, _mm_mul_pd(a3, d2));
        z = _mm_sub_pd(z, _mm_mul_pd(a4, d3));

        let mut out = _mm_mul_pd(b0, z);
        out = _mm_add_pd(out, _mm_mul_pd(b1, d0));
        out = _mm_add_pd(out, _mm_mul_pd(b2, d1));
        out = _mm_add_pd(out, _mm_mul_pd(b3, d2));
        out = _mm_add_pd(out, _mm_mul_pd(b4, d3));

        let mut z_values = [0.0_f64; 2];
        _mm_storeu_pd(z_values.as_mut_ptr(), z);
        _mm_storeu_pd(output.as_mut_ptr().add(channel), out);
        for lane in 0..2 {
            let state = &mut filters[channel + lane];
            state.delay[3] = state.delay[2];
            state.delay[2] = state.delay[1];
            state.delay[1] = state.delay[0];
            state.delay[0] = z_values[lane];
        }
        channel += 2;
    }
    if channel < frame.len() {
        output[channel] = filters[channel].process(frame[channel], coefficients);
    }
}

#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx")]
unsafe fn filter_frame_avx(
    frame: &[f64],
    filters: &mut [FilterState],
    coefficients: KWeightingCoefficients,
    output: &mut [f64],
) {
    use std::arch::x86_64::*;

    let a1 = _mm256_set1_pd(coefficients.a[1]);
    let a2 = _mm256_set1_pd(coefficients.a[2]);
    let a3 = _mm256_set1_pd(coefficients.a[3]);
    let a4 = _mm256_set1_pd(coefficients.a[4]);
    let b0 = _mm256_set1_pd(coefficients.b[0]);
    let b1 = _mm256_set1_pd(coefficients.b[1]);
    let b2 = _mm256_set1_pd(coefficients.b[2]);
    let b3 = _mm256_set1_pd(coefficients.b[3]);
    let b4 = _mm256_set1_pd(coefficients.b[4]);

    let mut channel = 0;
    while channel + 4 <= frame.len() {
        let d0 = _mm256_set_pd(
            filters[channel + 3].delay[0],
            filters[channel + 2].delay[0],
            filters[channel + 1].delay[0],
            filters[channel].delay[0],
        );
        let d1 = _mm256_set_pd(
            filters[channel + 3].delay[1],
            filters[channel + 2].delay[1],
            filters[channel + 1].delay[1],
            filters[channel].delay[1],
        );
        let d2 = _mm256_set_pd(
            filters[channel + 3].delay[2],
            filters[channel + 2].delay[2],
            filters[channel + 1].delay[2],
            filters[channel].delay[2],
        );
        let d3 = _mm256_set_pd(
            filters[channel + 3].delay[3],
            filters[channel + 2].delay[3],
            filters[channel + 1].delay[3],
            filters[channel].delay[3],
        );
        let input = _mm256_loadu_pd(frame.as_ptr().add(channel));

        // AVX alone cannot contract these operations into FMA. Keep every
        // multiply and subtract/add in the scalar source order.
        let mut z = _mm256_sub_pd(input, _mm256_mul_pd(a1, d0));
        z = _mm256_sub_pd(z, _mm256_mul_pd(a2, d1));
        z = _mm256_sub_pd(z, _mm256_mul_pd(a3, d2));
        z = _mm256_sub_pd(z, _mm256_mul_pd(a4, d3));

        let mut out = _mm256_mul_pd(b0, z);
        out = _mm256_add_pd(out, _mm256_mul_pd(b1, d0));
        out = _mm256_add_pd(out, _mm256_mul_pd(b2, d1));
        out = _mm256_add_pd(out, _mm256_mul_pd(b3, d2));
        out = _mm256_add_pd(out, _mm256_mul_pd(b4, d3));

        let mut z_values = [0.0_f64; 4];
        _mm256_storeu_pd(z_values.as_mut_ptr(), z);
        _mm256_storeu_pd(output.as_mut_ptr().add(channel), out);
        for lane in 0..4 {
            let state = &mut filters[channel + lane];
            state.delay[3] = state.delay[2];
            state.delay[2] = state.delay[1];
            state.delay[1] = state.delay[0];
            state.delay[0] = z_values[lane];
        }
        channel += 4;
    }

    if channel + 2 <= frame.len() {
        // SAFETY: AVX-capable x86-64 also has SSE2; the remaining two real
        // channels are in bounds.
        filter_frame_sse2(
            &frame[channel..channel + 2],
            &mut filters[channel..channel + 2],
            coefficients,
            &mut output[channel..channel + 2],
        );
        channel += 2;
    }
    if channel < frame.len() {
        output[channel] = filters[channel].process(frame[channel], coefficients);
    }
}

/// Accumulate per-channel square sums for the supplied ring spans. `spans` are
/// ordered exactly as the scalar profile requires; each tuple is `(start_frame,
/// frame_count)`. Only channels with nonzero loudness weight are evaluated.
pub(super) fn window_channel_sums(
    backend: Backend,
    ring: &[f64],
    channels: usize,
    weights: &[f64],
    spans: &[(usize, usize)],
    sums: &mut [f64],
) {
    assert_eq!(weights.len(), channels);
    assert!(sums.len() >= channels);
    sums[..channels].fill(0.0);

    match backend.0 {
        BackendKind::Scalar => window_channel_sums_scalar(ring, channels, weights, spans, sums),
        #[cfg(all(target_arch = "aarch64", feature = "experimental-loudness-neon"))]
        BackendKind::Neon => window_channel_sums_scalar(ring, channels, weights, spans, sums),
        #[cfg(target_arch = "x86_64")]
        BackendKind::Sse2 => {
            // SAFETY: selection performed the one-time feature check. Only real
            // weighted channels are assembled into lanes and span loads stay
            // within caller-validated ring geometry.
            unsafe { window_channel_sums_sse2(ring, channels, weights, spans, sums) }
        }
        #[cfg(target_arch = "x86_64")]
        BackendKind::Avx => {
            // SAFETY: selection performed the one-time feature check and the
            // same bounds/real-lane invariants apply as in the SSE2 path.
            unsafe { window_channel_sums_avx(ring, channels, weights, spans, sums) }
        }
    }
}

fn window_channel_sums_scalar(
    ring: &[f64],
    channels: usize,
    weights: &[f64],
    spans: &[(usize, usize)],
    sums: &mut [f64],
) {
    for channel in 0..channels {
        if weights[channel] == 0.0 {
            continue;
        }
        let mut sum = 0.0;
        for &(start_frame, frame_count) in spans {
            for frame in start_frame..start_frame + frame_count {
                let sample = ring[frame * channels + channel];
                sum += sample * sample;
            }
        }
        sums[channel] = sum;
    }
}

#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "sse2")]
unsafe fn accumulate_window_pair(
    ring: &[f64],
    channels: usize,
    spans: &[(usize, usize)],
    c0: usize,
    c1: usize,
    sums: &mut [f64],
) {
    use std::arch::x86_64::*;
    let mut acc = _mm_setzero_pd();
    for &(start_frame, frame_count) in spans {
        for frame in start_frame..start_frame + frame_count {
            let base = frame * channels;
            let samples = _mm_set_pd(ring[base + c1], ring[base + c0]);
            acc = _mm_add_pd(acc, _mm_mul_pd(samples, samples));
        }
    }
    let mut values = [0.0_f64; 2];
    _mm_storeu_pd(values.as_mut_ptr(), acc);
    sums[c0] = values[0];
    sums[c1] = values[1];
}

fn accumulate_window_scalar(
    ring: &[f64],
    channels: usize,
    spans: &[(usize, usize)],
    channel: usize,
    sums: &mut [f64],
) {
    let mut sum = 0.0;
    for &(start_frame, frame_count) in spans {
        for frame in start_frame..start_frame + frame_count {
            let sample = ring[frame * channels + channel];
            sum += sample * sample;
        }
    }
    sums[channel] = sum;
}

#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "sse2")]
unsafe fn window_channel_sums_sse2(
    ring: &[f64],
    channels: usize,
    weights: &[f64],
    spans: &[(usize, usize)],
    sums: &mut [f64],
) {
    let mut pending = [0_usize; 2];
    let mut pending_len = 0;
    for (channel, weight) in weights.iter().copied().enumerate() {
        if weight == 0.0 {
            continue;
        }
        pending[pending_len] = channel;
        pending_len += 1;
        if pending_len == 2 {
            accumulate_window_pair(ring, channels, spans, pending[0], pending[1], sums);
            pending_len = 0;
        }
    }
    if pending_len == 1 {
        accumulate_window_scalar(ring, channels, spans, pending[0], sums);
    }
}

#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx")]
unsafe fn window_channel_sums_avx(
    ring: &[f64],
    channels: usize,
    weights: &[f64],
    spans: &[(usize, usize)],
    sums: &mut [f64],
) {
    use std::arch::x86_64::*;

    // Keep the grouping buffer on the stack and only for real weighted
    // channels. No persistent padding or per-window heap allocation is needed.
    let mut pending = [0_usize; 4];
    let mut pending_len = 0;
    for (channel, weight) in weights.iter().copied().enumerate() {
        if weight == 0.0 {
            continue;
        }
        pending[pending_len] = channel;
        pending_len += 1;
        if pending_len == 4 {
            let [c0, c1, c2, c3] = pending;
            let mut acc = _mm256_setzero_pd();
            for &(start_frame, frame_count) in spans {
                for frame in start_frame..start_frame + frame_count {
                    let base = frame * channels;
                    let samples = _mm256_set_pd(
                        ring[base + c3],
                        ring[base + c2],
                        ring[base + c1],
                        ring[base + c0],
                    );
                    acc = _mm256_add_pd(acc, _mm256_mul_pd(samples, samples));
                }
            }
            let mut values = [0.0_f64; 4];
            _mm256_storeu_pd(values.as_mut_ptr(), acc);
            sums[c0] = values[0];
            sums[c1] = values[1];
            sums[c2] = values[2];
            sums[c3] = values[3];
            pending_len = 0;
        }
    }

    if pending_len >= 2 {
        accumulate_window_pair(ring, channels, spans, pending[0], pending[1], sums);
    }
    if pending_len == 1 {
        accumulate_window_scalar(ring, channels, spans, pending[0], sums);
    } else if pending_len == 3 {
        accumulate_window_scalar(ring, channels, spans, pending[2], sums);
    }
}

// Same arithmetic graph as fidelity::State::process, including exact-zero
// excitation and tiny homogeneous-tail clearing. No FMA.
pub(super) fn filter_fidelity_frame(
    backend: Backend,
    frame: &[f64],
    states: &mut [f64],
    coefficients: super::fidelity::Coefficients,
    output: &mut [f64],
) {
    // State-major layout: five planes, each exactly the channel count.
    // These checks guard the packed raw-pointer loads and stores.
    assert_eq!(states.len(), 5 * frame.len());
    assert_eq!(frame.len(), output.len());
    match backend.0 {
        BackendKind::Scalar => fidelity_scalar(frame, states, coefficients, output, 0),
        #[cfg(target_arch = "x86_64")]
        BackendKind::Sse2 => unsafe { fidelity_sse2(frame, states, coefficients, output, 0) },
        #[cfg(target_arch = "x86_64")]
        BackendKind::Avx => unsafe { fidelity_avx(frame, states, coefficients, output, 0) },
        #[cfg(all(target_arch = "aarch64", feature = "experimental-loudness-neon"))]
        BackendKind::Neon => {
            // SAFETY: private dispatch checked NEON; geometry checked above.
            unsafe { neon_experiment::conditioned_neon(frame, states, coefficients, output) }
        }
    }
}

fn fidelity_scalar(
    frame: &[f64],
    states: &mut [f64],
    c: super::fidelity::Coefficients,
    output: &mut [f64],
    start: usize,
) {
    let channels = frame.len();
    for channel in start..channels {
        let mut state = super::fidelity::State {
            delay: std::array::from_fn(|i| states[i * channels + channel]),
        };
        output[channel] = state.process(frame[channel], c);
        for (i, value) in state.delay.into_iter().enumerate() {
            states[i * channels + channel] = value;
        }
    }
}

#[cfg(target_arch = "x86_64")]
use std::arch::x86_64::*;

#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx")]
unsafe fn fidelity_avx_eq(a: __m256d, b: __m256d) -> __m256d {
    _mm256_cmp_pd::<{ _CMP_EQ_OQ }>(a, b)
}

#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx")]
unsafe fn fidelity_avx_lt(a: __m256d, b: __m256d) -> __m256d {
    _mm256_cmp_pd::<{ _CMP_LT_OQ }>(a, b)
}

// The same recurrence for the two existing vector widths. State-major planes
// allow direct loads/stores. A mask is needed only when a lane is unexcited.
// Geometry and ISA are checked by filter_fidelity_frame and Backend.
#[cfg(target_arch = "x86_64")]
macro_rules! fidelity_kernel {
    ($name:ident, $feature:literal, $lanes:literal,
     $set:ident, $load:ident, $store:ident, $add:ident, $sub:ident, $mul:ident,
     $and:ident, $andnot:ident, $eq:ident, $lt:ident, $movemask:ident, $tail:ident) => {
        #[target_feature(enable = $feature)]
        unsafe fn $name(
            frame: &[f64],
            states: &mut [f64],
            c: super::fidelity::Coefficients,
            output: &mut [f64],
            mut channel: usize,
        ) {
            let zero = $set(0.0);
            let sign = $set(-0.0);
            let tiny = $set(super::fidelity::TINY);
            let cc = $set(c.c);
            let cs = $set(c.s);
            let vh = $set(c.vh);
            let ct = $set(c.t);
            let rg = $set(c.rg);
            let k2 = $set(c.k2);
            let bm = $set(c.bp_mix);
            let lm = $set(c.lp_mix);
            let two = $set(2.0);
            let channels = frame.len();
            while channel + $lanes <= channels {
                let state = states.as_mut_ptr().add(channel);
                let x = $load(frame.as_ptr().add(channel));
                let previous = $load(state);
                let y = $load(state.add(channels));
                let q = $load(state.add(2 * channels));
                let a = $load(state.add(3 * channels));
                let b = $load(state.add(4 * channels));
                let dx = $sub(x, previous);
                let mut yn = $add(y, $sub($sub(dx, $mul(cc, y)), $mul(cs, q)));
                let mut qn = $add(q, $mul(cs, y));
                let unexcited = $eq(dx, zero);
                if $movemask(unexcited) != 0 {
                    let clear = $and(
                        unexcited,
                        $and($lt($andnot(sign, yn), tiny), $lt($andnot(sign, qn), tiny)),
                    );
                    yn = $andnot(clear, yn);
                    qn = $andnot(clear, qn);
                }
                let t = $sub($sub(yn, b), $mul(rg, a));
                let inc = $mul(ct, t);
                let bp = $add(a, inc);
                let mut out = $add($add($mul(vh, yn), $mul(bm, bp)), $mul(lm, b));
                let mut an = $add(a, $mul(two, inc));
                let mut bn = $add(b, $mul(k2, bp));
                let unexcited = $eq(yn, zero);
                if $movemask(unexcited) != 0 {
                    let clear = $and(
                        unexcited,
                        $and($lt($andnot(sign, an), tiny), $lt($andnot(sign, bn), tiny)),
                    );
                    an = $andnot(clear, an);
                    bn = $andnot(clear, bn);
                    out = $andnot(clear, out);
                }
                $store(state, x);
                $store(state.add(channels), yn);
                $store(state.add(2 * channels), qn);
                $store(state.add(3 * channels), an);
                $store(state.add(4 * channels), bn);
                $store(output.as_mut_ptr().add(channel), out);
                channel += $lanes;
            }
            if channel < channels {
                $tail(frame, states, c, output, channel);
            }
        }
    };
}

#[cfg(target_arch = "x86_64")]
fidelity_kernel!(
    fidelity_sse2,
    "sse2",
    2,
    _mm_set1_pd,
    _mm_loadu_pd,
    _mm_storeu_pd,
    _mm_add_pd,
    _mm_sub_pd,
    _mm_mul_pd,
    _mm_and_pd,
    _mm_andnot_pd,
    _mm_cmpeq_pd,
    _mm_cmplt_pd,
    _mm_movemask_pd,
    fidelity_scalar
);
#[cfg(target_arch = "x86_64")]
fidelity_kernel!(
    fidelity_avx,
    "avx",
    4,
    _mm256_set1_pd,
    _mm256_loadu_pd,
    _mm256_storeu_pd,
    _mm256_add_pd,
    _mm256_sub_pd,
    _mm256_mul_pd,
    _mm256_and_pd,
    _mm256_andnot_pd,
    fidelity_avx_eq,
    fidelity_avx_lt,
    _mm256_movemask_pd,
    fidelity_sse2
);

#[cfg(all(
    target_arch = "aarch64",
    any(test, feature = "experimental-loudness-neon")
))]
#[path = "neon_experiment.rs"]
mod neon_experiment;
