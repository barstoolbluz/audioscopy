# Against A R4 resumable checkpoint

Immediate input: R3 cumulative archive, SHA-256
`9cc4485f999c9769a07852f425a5ee5ce173c023ba89f9d04390f720f311c2aa`.
Scope: R3-AUD-01 only. Original BRIEF.md unchanged. Read
R4-CORRECTIVE-REPORT.md for results and limitations. Historical R3 checkpoint
is retained at evidence/R3-CHECKPOINT.md.

Production change complete: remove absolute 1e-6 per-anchor residual
ceiling from integer_grid(); retain all other checks and physical clock
validation. Add public API regression cases for quiet and dynamic PCM, plus
independent reference fixtures and measurement documentation.

Offline comparison model suites passed. Fail-before/pass-after evidence is
retained under evidence/. Native compilation, tests and performance remain
outstanding (Rust, Cargo and Nix unavailable here). Native operator kit is
unchanged. Verify the current archive and run the README commands on both
physical hosts. Preserve both evidence archives and checksums. Do not treat
model success as native qualification. Make no further architectural changes
without a demonstrated defect.
