# audioscopy: comparison measurements, input bundle, 2026-11-27

- `BRIEF.md`: the outcome wanted. Start here.
- `audioscopy/`: `main` at commit `f8e92e5`.
- `true-peak/`: `main` at commit `6a2f8f8`.
- `changes-since-cp13-r2/`: the commits on `main` since the CP13-R2 source
  (audioscopy `18098c4`, true-peak `dd61385`), with their messages and diffs.
- `MANIFEST-SHA256.txt`: checksums of every file.

Both crates are GPL-2.0-or-later.
