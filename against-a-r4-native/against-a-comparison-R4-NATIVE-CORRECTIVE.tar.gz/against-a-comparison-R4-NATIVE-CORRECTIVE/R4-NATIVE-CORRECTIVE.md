# Against A R4: native corrective (operator, x86-64)

Date: 2026-11-27

Input: `against-a-comparison-R4-R3AUD01-CUMULATIVE.tar.gz`, SHA-256
`a2ef2555c2f366cb4856f477992273a0dfe85b2b2a0a6291b39aa34325977624`.
The first native x86-64 run of that input failed (evidence SHA-256
`5cd8a10b924f19f36e0be1e6f989643633fa6407f56fc98ad05027ffdd209631`).
This corrective fixes every failure found natively. The exact delta is
`evidence/R4-NATIVE-code-delta.patch`. Both crates remain GPL-2.0-or-later.
No dependency, lock, feature or public API changes.

## 1. Comparison test target did not compile

`audioscopy/tests/comparison.rs` contained `value(r.null_depth_db)<-35.0`.
Rust lexes `<-` as one token, so the `comparison` test target did not
build in any configuration and none of its tests ran. Corrected to `< -35.0`.

## 2. Variation check aliased with periodic material (production defect)

`informative()` in `src/comparison/align.rs` sampled one frame in every
`(frames / 2048)`. When the material's period divides that stride, every
sampled value is equal and varying material is reported as constant.
`deep_null_and_energy_weighted_album` exposed this: 12000 frames give a
stride of 5, and its fixture has period 5. The near-zero-lag path was
skipped, the wide search then met the repeated periods, and null depth was
reported as can't tell. The same function sets `speed_known` on the exact
gain path, which reported speed as can't tell for an exact 0.5 gain.

`informative()` now examines every frame. It is a min/max pass, called at
most twice per pair.

New test `periodic_material_is_not_mistaken_for_constant` (exact gain on the
period-5 fixture: null, speed and drift are values). It fails before the
correction ("insufficient varying material to observe a clock difference")
and passes after. `deep_null_and_energy_weighted_album` also fails before and
passes after.

## 3. true-peak offline qualification depended on files outside the crate

`true-peak/qualification/verify_certified_search.py` required
`<crate>/../../docs/tonepoet_true_peak_reference9_fast90_design.md` to exist.
That file is not part of true-peak, and the script never read it. The
existence check is removed. Three source-text audits then failed on the
current baseline tree:

- Two regexes expected `fn name() {` on one line; rustfmt wraps one of these
  long test names. They now accept whitespace between `(`, `)` and `{`.
- `stale_msrv_workaround_is_retired` required exactly `rust-version = "1.93"`.
  The crate declares 1.95. The check now requires at least 1.93 (still with
  the transmute workaround absent).

No Rust source in true-peak changes. The offline qualification passes.

## 4. Format and lint gates

The new comparison files were not rustfmt-formatted, and Clippy reported
`needless_range_loop` (`src/comparison/align.rs`, `mapping()`) and two
`chunks_exact_to_as_chunks` (`tests/comparison.rs`). The files are now
formatted, and the three lints are fixed without behaviour change. The
`mapping()` per-channel array has 64 entries, matching the 1–64 channel
limit enforced by `validate_format`.

`operator/qualify.sh` now gates, for both crates, `cargo fmt --check` and
`cargo clippy --locked --all-targets -- -D warnings` in default,
no-default-features and all-features configurations.
