# Against A R4: R3-AUD-01 quiet-passage corrective

Date: 2026-11-27

Input: `against-a-comparison-R3-R2AUD01-CUMULATIVE.tar.gz`, SHA-256
`9cc4485f999c9769a07852f425a5ee5ce173c023ba89f9d04390f720f311c2aa`.
All 216 input manifest entries verified. Authority: the original unchanged
BRIEF.md and the user's supplied R3-AUD-01 corrective instructions.
The original audit probe archive was not supplied; the fixtures below were
constructed independently from the audit description and the retained chirp.

## Finding and correction

Confirmed: `integer_grid()` required finite local direct gain-fitted residual
power AND a maximum of 1e-6 (-60 dB). Relative quantization noise rises when
signal amplitude falls. The local absolute ceiling could reject otherwise
uniquely supported grids, and consequently suppress the null and rolling
residual measurements that should quantify that noise.

Remove the constant and its comparison. Keep the finite-value check.
Unchanged: 0.01-frame anchor/endpoint radius, adjacent integer separation
(4x residual with the existing floor), fractional comparison (1.05x),
distributed anchor and overlap requirements, whole-overlap correlation
(0.99999), validated clock priority, and speed_known=false on the fallback.
No additional production computation, new dependencies, public API changes,
or changes to the original 25 measurements or true-peak. The existing
operator script and all locks remain unchanged.

## Independent fail-before/pass-after evidence

Use the existing four-second mono multichirp at 44.1 kHz. Quantize reference to
24-bit PCM and copy to 16-bit PCM, with or without TPDF from separate SplitMix64
streams seeded 13 and 14. Scale quiet fixtures by 0.1 (dithered) or
0.03162277660168379 (nearest). The dynamic fixture uses amplitude 0.1 from
1.85 to 2.15 seconds, with 50 ms linear ramps back to unity. All sample grids
are known by construction. Compute the null independently using one global
least-squares gain and direct residual energy on the original grid.

| Fixture | Oracle null (dB) | R3 model | R4 model |
|---|---:|---|---|
| Normal, TPDF | -78.291262945 | grid 0 | grid 0 |
| Quiet, TPDF | -58.288202178 | rejected | grid 0 |
| Quiet, nearest | -53.055852152 | rejected | grid 0 |
| One quiet passage, TPDF | -77.795496273 | rejected | grid 0 |

The mixed-level middle anchor has residual -59.127856 dB. The best adjacent
integer hypothesis has 2507.47 times that residual power; the ratio of
integer to best fractional residual is 1.000299899. Whole-overlap sampled
correlation is 0.999999991699. All four physical clock decisions are
unresolved in both models. All three new regression fixtures cross the old
absolute ceiling. The complete corrective model suite passes, including all
six retained causal-EQ grid rejection controls, requantization, integer
shift, fractional delay, tiny genuine affine slopes, flutter and rational
gain. The original comparison model suite also passes.

The diagnostic probe and both runs are retained under evidence/. To run the
probe against either extracted source version, set
`PYTHONPATH=audioscopy/qualification` and run the probe from the root, e.g.
`PYTHONPATH=audioscopy/qualification OPENBLAS_NUM_THREADS=1 python -B evidence/R4-quiet-grid-probe.py`.
For fail-before, use the R4 probe with the original R3 qualification directory
on PYTHONPATH. The updated `comparison_corrective_reference.py` also asserts
all four fixture outcomes and that the three regressions cross the old ceiling.

## Native gate

New public Rust API test `quiet_requantized_pcm_keeps_supported_integer_grid`
uses the same constructions and existing direct PCM oracle/helper. It checks
integer support, null/rolling values, polarity, exact-identity result, and
CantTell for speed/drift. The mixed-level case also checks album and null-only
selection semantics. It runs automatically in the existing qualification
matrix. Rust, Cargo and Nix are unavailable in this environment. No native
build, tests, lint results, host qualification or performance claims are made.
The model is not a substitute for native Rust execution. Run both README
commands before declaring qualification complete.

## Scope

One production file changed: `audioscopy/src/comparison/align.rs`. Other
functional deltas: comparison tests, independent comparison model, measurement
definition. The retained source manifests, exact diff and actual logs are
included. Historical reports describe their respective versions, not current
policy. No earlier corrective is reopened.
