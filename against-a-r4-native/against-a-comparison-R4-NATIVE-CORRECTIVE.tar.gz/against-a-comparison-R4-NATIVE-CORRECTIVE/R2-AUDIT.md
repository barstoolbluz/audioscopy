# Against A R2: acceptance audit and focused corrective instruction

Date: 2026-11-27

Candidate: `against-a-comparison-R2-AUD01-03.tar.gz`
SHA-256: `9a78a8d2d524da16799f347f9cc0e1fa85f1dfc2c59391c0517de5b0a6dd7b11`
Authority: supplied `BRIEF.md` and R1 independent audit, D-01 through D-03. The embedded brief is byte-identical to the supplied brief.

## Decision

One localized regression remains. R2's correction of false clock estimates conflates failure to resolve a clock difference with failure to establish usable sample alignment. Routine PCM requantization now suppresses null depth, rolling residual, and polarity/channel results despite very strong evidence of unchanged sample alignment. Preserve the R2 corrections; do not revert the clock validation or rewrite the comparison subsystem.

## Verification and R1 dispositions

- All 206 candidate payload checksums pass. The retained R1 manifest is identical to the original R1 manifest. The original R1 archive SHA-256 matches the declared corrective input.
- All original 181 baseline entries are present; the same five expected files differ (root README, crate README, two documentation files, and `lib.rs` with the additive comparison export). The R1-to-R2 production change is confined to the new comparison module. Existing single-recording code, true-peak, Cargo manifests/locks, Nix locks and feature defaults remain unchanged. This checks supplied provenance, not a separately fetched remote Git history.
- `bash -n operator/qualify.sh` passes.
- Independently reran `comparison_corrective_reference.py`: PASS. The 12 analytic 0.25% flutter fixtures (1–40 Hz at 8 kHz, 20/40 Hz at 48 kHz, multiple phases) produce 0.246409–0.250017% in the model. The seven original affine cases, including 1e-7 and 1e-9 slopes, pass, as do the constant affine controls and the new EQ fixtures.
- D-01: corrective design and tested modulation response are satisfactory, pending native execution. The new local affine fit, branch tracking, digital provenance, and bounded work are appropriate.
- D-02: source correction passes inspection. Exact integer-significand proportionality is used after the rounded multiplication proof fails. It preserves signs/zeros and the old exact rounded-gain path. The exact 7/10 oracle passes, and native tests cover gain-only classification, exact null and the one-LSB mutation. No more work is requested on this defect.
- D-03: the original independent audit probe (not merely the replacement sweep) was recovered and rerun against R2. The original 1 kHz causal-filter false speed of -7.7724 ppm is rejected. The original 2 and 3 kHz filter cases are also rejected. The 1.5 kHz case was already ambiguous in R1. The clock-validation correction must be retained, subject to the regression below.

**Evidence boundary:** the Python reference models are not native Rust execution. I inspected the corresponding Rust paths and reproduced the numerical decision in the candidate's model. Rust, Cargo and Nix are unavailable in this audit environment. Native compilation, actual tests, lint status, performance, and both physical-host qualification runs remain unverified. The candidate correctly disclaims native qualification. No actual native failure or pass is claimed.

## Genuine defects (rules 1–3)

### R2-AUD-01 · P2 · Clock-certification failure suppresses valid sample-aligned comparisons of ordinary PCM masters

**Brief requirements:**

- Null depth: “How completely the recording cancels against A after matching time, gain and speed, in dB”. Its unavailable condition is “Tracks don't pair, or alignment fails”.
- Residual over time: “The difference against A in rolling windows: median, 99th percentile and worst, in dB”. Its unavailable condition is “As Null depth”.
- “A measurement that cannot be determined reports `can't tell` with a one-line reason, never a fabricated value. Not-applicable, not-requested and can't-tell stay distinct.”
- “Results are trustworthy across their full reported range, including very deep nulls and very small speed differences, and their limits are stated.”

**Triggering scenario.** A user compares a 24-bit digital master with a same-rate 16-bit delivery derived directly from it, with or without conventional TPDF dither. No sample is inserted, dropped, shifted or resampled. The files have equal durations. This is a central use case for the comparison library, not an adversarial or extreme input. The supplied informative multichirp fixture makes this deterministic and discriminates against timing ambiguity. Generate four seconds at 44.1 kHz using the existing `wave` fixture. For signed PCM with the normalized range used here:

```
A[i] = round(wave(i / 44100) * 2^23) / 2^23
B[i] = round(A[i] * 2^15) / 2^15
```

Also test `B[i] = round(A[i] * 2^15 + U1[i] - U2[i]) / 2^15`, where independent uniform samples are in [0,1). The evidence uses NumPy generators seeded 13 and 14 for the 24-to-16 dither case. There is no timing difference by construction. These are ordinary PCM values, not numerical underflow or arbitrary synthetic bit patterns.

**Reproduction.** `r2_probe.py` invokes the retained R1 candidate generator and R2's new `observable` validation, with independent direct integer-aligned least-squares null calculations. See `r2_probe.log`. The important results are:

| Input at 44.1 kHz | Independently calculated integer-aligned null | R2 model alignment |
|---|---:|---|
| 24-bit master -> 16-bit nearest rounding | -83.075883 dB | Unavailable |
| 24-bit master -> 16-bit TPDF dither | -78.288632 dB | Unavailable |
| Float master -> 24-bit nearest rounding | -131.223350 dB | Unavailable |

The 24-to-16 undithered case has a fitted midpoint offset of approximately 9.06e-6 frames and slope -5.73e-10. The affine mismatch is 0.0118567 frames, versus an acceptance allowance of 7.58e-6 frames. The local nonlinear fallback also rejects: observed slope spread corresponds to 0.00115978 frames, versus mismatch 0.0136084 frames. The dither case has an offset of -8.79e-5 frames and slope -5.24e-10; its affine mismatch is 0.0216317 frames, versus allowance 6.93e-6 frames. Both are decisively rejected, not borderline threshold cases.

The existing unwarped integer-grid alternative is already a very good fit. Evaluating the same seven anchor windows with a constant zero lag and with the R1 refined affine candidate:

- 24-to-16 rounding: integer loss is only 0.049% higher in the sum of normalized anchor losses; the largest individual anchor increase is 0.375%.
- 24-to-16 TPDF: integer loss is only 0.175% higher in that sum; the largest individual anchor increase is 0.651%.

The tiny fitted fractional adjustments do not meaningfully improve the residual. They fit quantization noise. The corresponding correlation of the float-to-16 rounding control is 0.9999999975. The same rejection reproduces for nearest 16- and 24-bit rounding at 8, 44.1 and 48 kHz, plus 44.1 kHz TPDF. The exact-gain shortcut does not apply: quantization changes individual samples by different amounts.

**Root cause and user-visible failure.** In `audioscopy/src/comparison/align.rs:678–735`, `validated_clock` admits an affine model only if gain-projected shape mismatch in every anchor is less than `max(1e-6, 0.10 * anchor_span * abs(delta))` frames. For a zero or very small slope, a nonidentical but well-aligned pair can rarely meet this near-exact waveform requirement. The nonlinear fallback requires independently resolved nonzero local slope departures; noise-only differences do not supply those. Rejecting an unresolved clock observation is correct in itself. At `align.rs:902–903`, however, the function converts this decision into failure of the entire alignment. `mod.rs:447–453` then marks *all* alignment-dependent results unavailable. This discards the strong integer-grid alignment evidence already obtained by R1. R2 docs (measurements.md:295–315) explicitly describe this all-or-nothing rule. A disclosure does not make the loss of ordinary null measurements appropriate.

It is not necessary to prove that the physical speed difference is identically zero in order to resolve a practically exact integer-frame alignment. The correct result of the sample-domain cancellation on this known aligned example is finite and informative. A tiny apparent physical speed difference is not supported, so reporting one (or fabricating a certified zero) would also be wrong. The model and corresponding production branches establish the regression; native reproduction remains a required verification step.

**Localized corrective implementation.** Retain R2 `validated_clock`, the clean affine and nonlinear paths, exact identity/gain handling, existing coarse consensus, mapping, overlap checks, and the existing direct residual arithmetic. Do not loosen the false-speed gate globally. Separate a usable alignment from a resolved physical clock-rate observation. The private `Model.speed_known` already supports this distinction; use it rather than creating a new public type or a large alignment abstraction.

After a clock validation rejection, consider the existing constant integer-lag hypothesis as a bounded fallback, only where the evidence really supports it. Reuse distributed refined anchors, their integer and fractional objective evaluations, and the existing overlap/mapping checks. A small lag disagreement alone is not enough: require the same unambiguous frame lag over distributed anchors and show that removing the estimated fractional motion does not materially worsen measured cancellation. Compare direct gain-fitted residual energies rather than subtracting nearly equal correlations. The two 44.1 kHz examples demonstrate a strong margin for such a decision. A conservative, documented sub-frame consistency bound plus a residual-power comparison is a reasonable implementation; exact tolerances should be chosen against these controls and the existing false-clock and tiny-slope tests, rather than creating a universal ppm deadband. Require actual sample matching, not equal length alone. Retain genuinely ambiguous or incompatible pairs as unavailable. No general-purpose mastering filter identification is required.

For a supported integer fallback, select the constant integer clock for sample-domain support (`fractional=false`, no interpolation), mark the speed estimate unresolved (`speed_known=false`), and keep the supported null depth, residual and unambiguous polarity/channel results. A one-line speed reason should say that motion is unresolved at the available waveform fidelity. The existing drift branch must not treat such a fallback as a certified zero or as a validated affine trend: return unavailable if its reference trend is unresolved. If the validated clock succeeds, keep the existing result, including genuine sub-ppm rates; do not bypass R2's validation just to give a number. Keep the exact-match shortcut and existing exact integer deep-null certification unchanged. Preserve independent selection and album reductions; one unresolved speed must not poison an otherwise valid pooled null. Document the limited integer-fallback support and distinguish sample-grid alignment from a physical speed estimate. No new dependencies, full-track extra resampling, new public methods or broad refactor are requested.

**Focused verification.**

1. Reproduce the original rejection through native `compare` with `Format` encodings reflecting the 24-bit A and 16-bit B, same rate and channel count. Use both nearest rounding and deterministic TPDF. Use the candidate's wave function and an independent direct zero-lag least-squares energy oracle. Assert that the alignment covers the full intended support, is integer-grid (zero delay for these fixtures), and that null depth is finite and agrees with the oracle, e.g. within 0.1 dB. Assert rolling median/p99/worst are available and match independently computed window results under the existing window definition, with a suitable numerical tolerance. Assert no unsupported nonzero speed or zero drift is fabricated. Check polarity on a known non-inverted mono copy, and `SameAudio::Different`.
2. Include float-to-24-bit rounding as a deep, nonexact null and one ordinary sample rate (44.1 or 48 kHz). Preserve the original much deeper integer-null tests. A same-clock exact gain-only input must keep the original shortcut and exact result.
3. Preserve all R2 analytic flutter fixtures and original clean affine controls including 1e-7 and 1e-9. Keep causal EQ counterexamples from R1 and R2 from producing false speed; retain unavailable alignment where the same sample grid is not supported. Reuse existing unrelated/ambiguous-content tests. A genuine resolvable fractional or affine change must still use the validated clock and cannot be rounded to an integer solely to manufacture a result.
4. Test null-only versus combined selection, a caller-supplied album with the requantized pair and an exact pair, and speed/drift unavailability independently of null. Use the existing native operator and benchmark; do not add unrelated qualification infrastructure or optimization demands. Native full-matrix tests on both target architectures remain the handoff/release gates under the original brief.

## Proportionality check

R2 is not over-built in its overall design. The short-window local affine estimator is proportionate to the requested flutter band, exact rational gain reuses the existing integer proof, and the bounded clock-validation pass addresses a real false-speed defect. The excessive behavior is the all-or-nothing acceptance policy, not the implementation's size or architecture. Relax that coupling only in the case of a well-supported constant integer-grid alignment. Preserve the exact and clean-affine fast paths and the original 25 measurements. No evidence justifies a separate resampler, generalized phase-processing classifier, elaborate uncertainty framework, more dependencies, or unrelated native performance work. Actual performance remains unmeasured here.

The next candidate should be a cumulative, focused correction. Do not reopen D-01 or D-02 absent a demonstrated native failure. This audit is a source/model acceptance decision, not a native qualification result. Retain the previously supplied operator commands and evidence packaging.

Verdict — Fix defects
