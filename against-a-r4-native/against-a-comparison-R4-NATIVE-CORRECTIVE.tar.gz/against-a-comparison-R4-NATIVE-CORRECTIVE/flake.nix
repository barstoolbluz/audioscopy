{
  description = "Pinned native audioscopy comparison qualification environment";
  inputs = {
    nixpkgs.url = "github:NixOS/nixpkgs/nixos-unstable";
    flake-utils.url = "github:numtide/flake-utils";
    rust-overlay = {
      url = "github:oxalica/rust-overlay";
      inputs.nixpkgs.follows = "nixpkgs";
    };
  };
  outputs = { self, nixpkgs, flake-utils, rust-overlay }:
    flake-utils.lib.eachSystem [ "x86_64-linux" "aarch64-darwin" ] (system:
      let
        pkgs = import nixpkgs { inherit system; overlays = [ (import rust-overlay) ]; };
        rust = pkgs.rust-bin.stable."1.99.1".default.override {
          extensions = [ "rust-src" "clippy" "rustfmt" ];
        };
        python = pkgs.python313.withPackages (ps: [ ps.numpy ps.scipy ps.mpmath ]);
      in {
        devShells.default = pkgs.mkShell {
          packages = [ rust python pkgs.stdenv.cc pkgs.bash pkgs.coreutils
            pkgs.gnutar pkgs.gzip pkgs.findutils pkgs.gnugrep pkgs.diffutils pkgs.git ];
        };
      });
}
