#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0-or-later
"""Independent high-precision checks and executable alignment design model.

This file does not import, build, or execute Rust. The exact rational energy
oracle is independent of the binary64 anchored residual; the NumPy timing
model is a separate implementation of the documented search geometry. The
native integration suite is the implementation authority.
"""
from fractions import Fraction
import math
import numpy as np
import mpmath as mp
from numpy.lib.stride_tricks import sliding_window_view

mp.mp.dps = 120
RATE = 8000
HALF = 128
PHASES = 8192


def wave(t):
    t = np.asarray(t)
    env = .74 + .19 * np.sin(2 * np.pi * .71 * t)
    return env * (.18 * np.sin(2 * np.pi * (113.7*t + 3.21*t*t))
                  + .12 * np.cos(2 * np.pi * (379.1*t + 7.13*t*t))
                  + .08 * np.sin(2 * np.pi * (727.3*t + 11.61*t*t + .03))
                  + .04 * np.cos(2 * np.pi * (982.7*t + 2.17*t*t)))


def rational_null(a, b):
    a, b = list(map(Fraction, a)), list(map(Fraction, b))
    aa = sum(x*x for x in a)
    bb = sum(y*y for y in b)
    ab = sum(x*y for x, y in zip(a, b))
    r = sum((x-ab/bb*y)**2 for x, y in zip(a, b))
    p = r/aa
    return float(10*mp.log10(mp.mpf(p.numerator)/p.denominator)) if p else -math.inf


def anchored_null(a, b):
    # A separately written model of the production cancellation arithmetic.
    i = max(range(len(b)), key=lambda i: abs(b[i]))
    a0, b0 = a[i], b[i]
    def residual(x, y):
        p, q = x*b0, y*a0
        return ((p-q)+(math.fma(x, b0, -p)-math.fma(y, a0, -q)))/b0
    r = [residual(x,y) for x,y in zip(a,b)]
    correction = math.fsum(y*z for y,z in zip(b,r))/math.fsum(y*y for y in b)
    norm = math.hypot(*(math.fma(-correction,y,z) for y,z in zip(b,r)))
    return 20*(math.log10(norm)-math.log10(math.hypot(*a))) if norm else -math.inf


def numerical_oracles():
    a = [0.25, -0.5, 0.0, 0.125, 0.0] * 20
    for exp in [-35, -53, -600, -900]:
        b = [x*.5 for x in a]
        b[2] = 2.0**exp
        expected, actual = rational_null(a,b), anchored_null(a,b)
        assert abs(expected-actual) < 1e-8, (expected,actual)
        print(f'null exponent {exp:4}: exact rational {expected:.12f} dB; model {actual:.12f} dB')
    a = [.25,-.125,.75,-.375,.5,-.875] * 16
    b = [x*.731 for x in a]
    b[17] = math.nextafter(b[17], math.inf)
    expected, actual = rational_null(a,b), anchored_null(a,b)
    assert abs(expected-actual) < 1e-8, (expected,actual)
    print(f'non-dyadic fitted gain: exact rational {expected:.12f} dB; model {actual:.12f} dB')
    a=[.125,-.25,.375,.5]
    b=[x*3 for x in a]
    assert rational_null(a,b)==anchored_null(a,b)==-math.inf
    print('exact rational gain 1/3: zero residual')


def weight_table():
    f=np.arange(PHASES+1)[:,None]/PHASES
    x=np.arange(2*HALF)[None,:]-(HALF-1)-f
    w=np.sinc(x)*np.i0(16*np.sqrt(np.maximum(0,1-(x/HALF)**2)))/np.i0(16)
    w/=w.sum(axis=1)[:,None]
    w[0]=0;w[0,HALF-1]=1
    w[-1]=0;w[-1,HALF]=1
    return w


TABLE=weight_table()


def interp(b, i, lag, sinc):
    floor=np.floor(lag).astype(np.int64)
    j=i+floor
    f=lag-floor
    if np.any(j<0) or np.any(j>=len(b)):
        return None
    if not np.any(f):
        return b[j]
    if not sinc:
        if np.any(j+1>=len(b)):return None
        return b[j]+f*(b[j+1]-b[j])
    if np.any(j<HALF-1) or np.any(j+HALF>=len(b)):return None
    phase=f*PHASES
    k=np.minimum(phase.astype(int),PHASES-1)
    mix=phase-k
    w=TABLE[k]+(TABLE[k+1]-TABLE[k])*mix[:,None]
    return np.sum(w*b[j[:,None]+np.arange(2*HALF)[None,:]-(HALF-1)],axis=1)


def loss(a,b,center,lag,delta,half,step,sinc):
    i=np.arange(max(0,center-half),min(len(a),center+half),step)
    x=a[i]
    y=interp(b,i,lag+delta*(i-center),sinc)
    if y is None:return math.inf
    aa,bb=np.dot(x,x),np.dot(y,y)
    if min(aa,bb)<1e-16:return math.inf
    r=x-(np.dot(x,y)/bb)*y
    return np.dot(r,r)/aa


def refine(a,b,center,lag,delta,radius,grid,drift=False):
    half=RATE//(50 if drift else 100)
    step=max(1,RATE//(12000 if drift else 48000))
    evaluate=lambda z,sinc:loss(a,b,center,z,delta,half,step,sinc)
    grid_scores=[(evaluate(round(lag)+j,False),round(lag)+j) for j in range(-radius,radius+1,grid)]
    l,best=min(grid_scores)
    if l>.8:return None
    if drift and any(abs(z-best)>3*grid and v<=l+.005 for v,z in grid_scores):return None
    _,integer=min((evaluate(z,False),z) for z in range(best-grid,best+grid+1))
    il=evaluate(integer,True)
    if delta==0 and il<=1e-29:return float(integer)
    lo,hi=integer-1.,integer+1.
    ratio=.6180339887498949
    l,r=hi-ratio*(hi-lo),lo+ratio*(hi-lo)
    ll,rr=evaluate(l,True),evaluate(r,True)
    for _ in range(24 if drift else 40):
        if ll<rr:
            hi,r,rr=r,l,ll;l=hi-ratio*(hi-lo);ll=evaluate(l,True)
        else:
            lo,l,ll=l,r,rr;r=lo+ratio*(hi-lo);rr=evaluate(r,True)
    candidate=(lo+hi)/2
    cl=evaluate(candidate,True)
    l,z=(il,integer) if il<=cl*(1+1e-7)+1e-29 else (cl,candidate)
    return z if l<=1-.6**2 else None


def coarse(a,b,center,predicted,stride,stretch):
    half=max(8,RATE//20//stride);count=2*half
    start=center-half*stride
    positions=center+(np.arange(count*stride)-half*stride)/(1+stretch)
    if positions[0]<0 or positions[-1]>=len(a)-1:return []
    reference=np.interp(positions,np.arange(len(a)),a).reshape(-1,stride).mean(axis=1)
    reference-=reference.mean()
    v=np.dot(reference,reference)
    nominal=start+predicted
    search_start=max(0,math.floor(nominal)-2*RATE)
    last=min(max(0,math.ceil(nominal)+2*RATE),len(b)-count*stride)
    if last<search_start:return []
    candidates=[]
    for phase in sorted({0,stride//2}):
        ss=search_start+phase
        if ss>last:continue
        shifts=(last-ss)//stride+1
        data=b[ss:ss+(shifts+count-1)*stride].reshape(-1,stride).mean(axis=1)
        windows=sliding_window_view(data,count)
        means=windows.mean(axis=1)
        var=np.sum((windows-means[:,None])**2,axis=1)
        score=np.abs(windows@reference)/np.sqrt(np.maximum(var*v,1e-100))
        for _ in range(12):
            k=np.argmax(score)
            if score[k]<.6:break
            candidates.append((center,float(ss+k*stride-start),float(score[k])))
            score[max(0,k-3):k+4]=0.
    return candidates


def coarse_group(a,b,center,predicted,stride,stretch):
    candidates=coarse(a,b,center,predicted,stride,stretch)
    if abs(stretch)>.0005:candidates+=coarse(a,b,center,predicted,stride,0.)
    candidates.sort(key=lambda p:p[2],reverse=True)
    selected=[]
    for c in candidates:
        if all(abs(c[1]-z[1])>3*stride for z in selected):selected.append(c)
        if len(selected)==12:break
    return selected


def consensus(groups,mid,stride):
    groups=[g for g in groups if g]
    tolerance=max(4*stride,.004*RATE)
    hypotheses=[]
    for gi,g in enumerate(groups):
        for h in groups[gi+1:]:
            for i,l,_ in g:
                for j,m,_ in h:
                    d=(m-l)/(j-i)
                    if abs(d)>.05:continue
                    off=l-d*(i-mid)
                    selected=[];quality=0.
                    for group in groups:
                        target=off+d*(group[0][0]-mid)
                        matches=[(score-.03*((z-target)/tolerance)**2,k,z) for k,z,score in group if abs(z-target)<=tolerance]
                        if matches:
                            score,k,z=max(matches);selected.append((k,z));quality+=score
                    if len(selected)>=3:
                        hypotheses.append((len(selected),quality,off,d,selected))
    assert hypotheses,'no consensus'
    best=max(hypotheses,key=lambda x:x[:2]);count,quality,off,d,anchors=best
    for n,q,o,e,_ in hypotheses:
        if n==count and q>=quality-.01*count and max(abs(o-off+(e-d)*(groups[0][0][0]-mid)),abs(o-off+(e-d)*(groups[-1][0][0]-mid)))>2*tolerance:
            raise AssertionError(('ambiguous consensus',best,(n,q,o,e)))
    return anchors


def affine(anchors,mid):
    x=np.array([i-mid for i,_ in anchors],dtype=float)
    y=np.array([l for _,l in anchors])
    d=np.dot(x-x.mean(),y-y.mean())/np.dot(x-x.mean(),x-x.mean())
    return y.mean()-d*x.mean(),d


def estimate(a,b):
    stride=max(1,RATE//2000);mid=len(a)//2
    centers=[len(a)//8*k for k in range(1,8)]
    near=len(a)==len(b) and abs(np.dot(a,b))/(np.linalg.norm(a)*np.linalg.norm(b))>.99999
    anchors=[(i,0.) for i in centers] if near else consensus([coarse_group(a,b,i,(len(b)/len(a)-1)*i,stride,np.clip(len(b)/len(a)-1,-.05,.05)) for i in centers],mid,stride)
    assert len(anchors)>=3, ('coarse anchors',anchors)
    slopes=[(l2-l1)/(i2-i1) for j,(i1,l1) in enumerate(anchors) for i2,l2 in anchors[j+1:]]
    d0=float(np.median(slopes));off0=float(np.median([l-d0*(i-mid) for i,l in anchors]))
    anchors=[(i,l) for i,l in anchors if abs(l-(off0+d0*(i-mid)))<=max(.015*RATE,4*stride)]
    radius,grid=(2,1) if near else (2*stride+2,max(1,RATE//48000))
    refined=[(i,z) for i,l in anchors if (z:=refine(a,b,i,l,d0,radius,grid)) is not None]
    assert len(refined)>=3 and refined[-1][0]-refined[0][0]>=len(a)//3, ('refined',refined)
    off,d=affine(refined,mid)
    if abs(d-d0)*RATE/100>1e-5:
        second=[(i,z) for i,l in refined if (z:=refine(a,b,i,l,d,2,1)) is not None]
        if len(second)>=3 and second[-1][0]-second[0][0]>=len(a)//3:
            refined=second;off,d=affine(refined,mid)
    integer=round(off)
    if all(abs(off+d*(i-mid)-integer)<.5 for i,l in refined):
        if all(loss(a,b,i,integer,0,RATE//100,max(1,RATE//48000),False)<=
               loss(a,b,i,off+d*(i-mid),d,RATE//100,max(1,RATE//48000),True)*(1+1e-7)+1e-29 for i,l in refined):
            off,d=float(integer),0.
    assert abs(d)<=.05
    assert max(abs(l-off-d*(i-mid)) for i,l in refined)<=.003*RATE
    return off,d,refined


def timing_oracles():
    a=wave(np.arange(32000)/RATE)
    for delta,delay in [(-.003,19.25),(.002,-8.4),(1e-7,0.),(1e-9,0.),(0.,19.),(-.04,0.),(.04,0.),(.001,3500.)]:
        n=round(len(a)*(1+delta)+delay)
        b=wave((np.arange(n)-delay)/(1+delta)/RATE)
        off,d,anchors=estimate(a,b)
        measured=-100*d/(1+d);expected=-100*delta/(1+delta)
        assert abs(measured-expected)<(2e-8 if abs(delta)<1e-6 else .002), (measured,expected,anchors)
        if delta==0:assert (off,d)==(19.,0.)
        i=np.arange(2*HALF,len(a)-2*HALF)
        lag=off+d*(i-len(a)//2)
        j=i+np.floor(lag).astype(int)
        valid=(j>=HALF)&(j<len(b)-HALF)
        i=i[valid];lag=lag[valid]
        y=interp(b,i,lag,True)
        assert y is not None and len(i)>.8*len(a)
        x=a[i];r=x-np.dot(x,y)/np.dot(y,y)*y
        null=20*np.log10(np.linalg.norm(r)/np.linalg.norm(x)) if np.any(r) else -np.inf
        assert null<-35.,(null,delta,delay)
        print(f'clock delta={delta:.3g}, offset={delay:.3f}: expected={expected:.12g}% model={measured:.12g}% null={null:.3f} dB')
    b=wave((np.arange(len(a))+3*np.sin(2*np.pi*np.arange(len(a))/RATE))/RATE)
    off,d,_=estimate(a,b)
    previous=None;peak=0.
    for i in range(RATE//50+HALF+RATE//200+HALF,len(a)-RATE//50-HALF-RATE//200-HALF,RATE//20):
        z=refine(a,b,i,off+d*(i-len(a)//2),d,max(2,RATE*3//1000),max(1,RATE//4000),True)
        assert z is not None,('drift unobservable',i)
        if previous is not None:
            old_i,old_z=previous;local=(z-old_z)/(i-old_i)
            peak=max(peak,abs(100*(d-local)/(1+local)))
        previous=i,z
    assert .12<peak<.35,peak
    print(f'1 Hz drift: analytic peak {100*3*2*np.pi/RATE:.9f}%; model {peak:.9f}%')


def interpolation_characterization():
    i=np.arange(2*HALF,3000)
    for fraction_of_nyquist in [.1,.25,.5,.8,.9,.95,.99]:
        omega=np.pi*fraction_of_nyquist
        x=np.sin(omega*np.arange(3200)+.23)
        errors=[]
        for f in [.0001,.125,.333,.5,.875]:
            y=interp(x,i,np.full(len(i),f),True)
            target=np.sin(omega*(i+f)+.23)
            errors.append(20*np.log10(np.linalg.norm(y-target)/np.linalg.norm(target)))
        if fraction_of_nyquist<=.95:assert max(errors)<-125.0,errors
        print(f'interpolation fractional delay, f/Nyquist={fraction_of_nyquist:.2f}: worst tested residual {max(errors):.3f} dB')


if __name__=='__main__':
    numerical_oracles()
    timing_oracles()
    interpolation_characterization()
    print('PASS: independent rational and NumPy design-model checks (NOT Rust qualification)')
