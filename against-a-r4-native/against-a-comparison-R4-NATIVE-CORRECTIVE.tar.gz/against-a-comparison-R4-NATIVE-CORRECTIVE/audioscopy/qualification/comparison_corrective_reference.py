#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0-or-later
"""D-01..03, R2-AUD-01 and R3-AUD-01 design-model checks, NOT native Rust execution.

The continuous-time clock and exact rational PCM are independent analytic
oracles. Use R1's independent candidate generator, then model the corrective
local affine observations and phase-observability decision separately. The
actual API tests in tests/comparison.rs are the native implementation gate.
"""
from fractions import Fraction
import math
import numpy as np
from scipy.signal import butter, sosfilt
import comparison_reference as r1

FLOOR = 1e-6
FRACTION = .10
DRIFT_FRACTION = .20
MAX_STRETCH = .05


def half_window(rate):
    return max(8, rate//500)


def points(a, b, c, lag, delta, half, rate):
    # Derivative of the piecewise-linear phase table, not an ideal analytic
    # derivative of the fixture. Use the same finite interpolation support.
    i = np.arange(c-half, c+half, max(1, rate//16000))
    if len(i)<8 or i[0]<0 or i[-1]>=len(a):
        return None
    l = lag + delta*(i-c)
    integer = np.floor(l).astype(np.int64)
    j = i + integer
    f = l-integer
    if np.any(j<r1.HALF-1) or np.any(j+r1.HALF>=len(b)):
        return None
    p = f*r1.PHASES
    k = np.minimum(p.astype(np.int64), r1.PHASES-1)
    dw = r1.TABLE[k+1]-r1.TABLE[k]
    w = r1.TABLE[k]+dw*(p-k)[:,None]
    samples = b[j[:,None]+np.arange(2*r1.HALF)[None,:]-(r1.HALF-1)]
    y = np.sum(w*samples, axis=1)
    y[f==0] = b[j[f==0]]
    v = np.sum(dw*samples, axis=1)*r1.PHASES
    return a[i], y, v, (i-c)/half


def phase_error(p):
    x,y,v,_ = p
    errors=[]
    for x,y,v in [(x,y,v),(np.diff(x),np.diff(y),np.diff(v))]:
        aa,bb = np.dot(x,x),np.dot(y,y)
        if min(aa,bb)<=1e-16:
            return math.inf
        gain = np.dot(x,y)/bb
        deriv = gain*(v-np.dot(y,v)/bb*y)
        vv=np.dot(deriv,deriv)
        if vv<=aa*1e-12:
            return math.inf
        residual=x-gain*y
        errors.append(math.sqrt(np.dot(residual,residual)/vv))
    return max(errors)


def update(p):
    x,y,v,u = p
    aa,bb = np.dot(x,x),np.dot(y,y)
    if min(aa,bb)<=1e-16:
        return None
    g=np.dot(x,y)/bb
    residual=x-g*y
    p=g*(v-np.dot(y,v)/bb*y)
    q=g*(v*u-np.dot(y,v*u)/bb*y)
    pp,qq,pq=np.dot(p,p),np.dot(q,q),np.dot(p,q)
    det=pp*qq-pq*pq
    if pp<=aa*1e-12 or qq<=pp*.01 or det<=.01*pp*qq:
        return None
    pr,qr=np.dot(p,residual),np.dot(q,residual)
    return (pr*qq-qr*pq)/det,(qr*pp-pr*pq)/det


def local_fit(a,b,c,lag,delta,rate,radius):
    half=half_window(rate)
    seed=lag
    for iteration in range(7):
        p=points(a,b,c,lag,delta,half,rate)
        if p is None:
            return None
        z=update(p)
        if z is None:
            return None
        dl,du=z
        change=max(abs(dl),abs(du))
        if change<=1e-7 or iteration==6:
            if change>1e-4:
                return None
            error=phase_error(p)
            return (lag,delta,error) if math.isfinite(error) else None
        lag+=dl
        delta+=du/half
        if not (math.isfinite(lag) and math.isfinite(delta)) or abs(delta)>MAX_STRETCH or abs(lag-seed)>radius:
            return None
    return None


def observable(a,b,off,d,anchors,rate):
    mid=len(a)//2
    span=anchors[-1][0]-anchors[0][0]
    allowance=max(FLOOR,FRACTION*span*abs(d))
    errors=[]
    for c,_ in anchors:
        p=points(a,b,c,off+d*(c-mid),d,max(16,rate//100),rate)
        errors.append(phase_error(p) if p is not None else math.inf)
    if max(errors)<=allowance:
        return (off,d), f'affine mismatch {max(errors):.6g} frames; allowance {allowance:.6g}'
    observations=[]
    lags=[]
    groups=0
    for c,l in anchors:
        count=0
        for ms in [-37,-13,0,17,31]:
            offset=int(ms*rate/1000)
            center=c+offset
            if center<0:
                continue
            z=local_fit(a,b,center,l+d*offset,d,rate,max(2.,rate/4000.))
            if z is None or abs(z[0]-(off+d*(center-mid)))>rate*.003:
                return None, f'local shape/branch not observable; affine mismatch {max(errors):.6g}, allowance {allowance:.6g}'
            observations.append(z)
            lags.append((center,z[0]))
            count+=1
        if count>=3:
            groups+=1
    v=np.asarray(observations)
    half=half_window(rate)
    lo,hi=np.min(v[:,1]),np.max(v[:,1])
    error=np.max(v[:,2])
    excursion=half*(hi-lo)
    ambiguity=max(error,FLOOR)/half
    accepted=groups>=3 and lo<d-ambiguity and hi>d+ambiguity and error<=FRACTION*excursion and excursion>FLOOR
    trend=r1.affine(sorted(lags),mid)
    trend_off,trend_delta=trend
    accepted=accepted and abs(trend_delta)<=MAX_STRETCH and lo<trend_delta-ambiguity and hi>trend_delta+ambiguity and all(abs(l-(trend_off+trend_delta*(c-mid)))<=rate*.003 for c,l in lags)
    return trend if accepted else None, f'local motion {excursion:.6g} frames, mismatch {error:.6g}, affine mismatch {max(errors):.6g}, allowance {allowance:.6g}'


def drift(a,b,off,d,rate):
    mid=len(a)//2
    i=np.arange(len(a))
    j=i+np.floor(off+d*(i-mid)).astype(np.int64)
    fractional=d!=0 or off!=round(off)
    margin=r1.HALF if fractional else 0
    support=i[(j>=margin)&(j<len(b)-margin)]
    if len(support)==0:
        return None
    half=half_window(rate); hop=half
    margin=max(16,rate//50)+r1.HALF+rate//100
    start=support[0]+margin; end=support[-1]+1-margin
    if end<=start or (end-start)//hop<4:
        return None
    c=int(start)
    lag=r1.refine(a,b,c,off+d*(c-mid),d,max(2,rate*3//1000),max(1,rate//4000),True)
    if lag is None:
        return None
    delta=d
    last=None
    peak=peak_delta=error=0.
    for c in range(start,end,hop):
        z=local_fit(a,b,c,lag,delta,rate,max(.5,rate/50000.))
        if z is None:
            return None
        lag,delta,e=z
        if abs(lag-(off+d*(c-mid)))>rate*.0029 or (last is not None and abs(lag-last)>MAX_STRETCH*hop):
            return None
        last=lag
        peak_delta=max(peak_delta,abs(d-delta))
        peak=max(peak,abs(100*(d-delta)/(1+delta)))
        error=max(error,e)
        lag+=delta*hop
    if error>max(FLOOR,DRIFT_FRACTION*half*peak_delta):
        return None
    return peak


def estimate(a,b,rate):
    r1.RATE=rate
    off,d,anchors=r1.estimate(a,b)
    trend,detail=observable(a,b,off,d,anchors,rate)
    if trend is not None:
        off,d=trend
    return off,d,trend is not None,detail


def rational_gain_oracle():
    a=[2560,23040,-2560,-23040,0]
    b=[1792,16128,-1792,-16128,0]
    assert all(Fraction(x,32768)*Fraction(7,10)==Fraction(y,32768) for x,y in zip(a,b))
    lo=.7; hi=math.nextafter(lo,math.inf)
    assert (23040/32768)*lo<16128/32768
    assert (2560/32768)*hi>1792/32768
    assert not all(Fraction(x,32768)*Fraction(7,10)==Fraction(y,32768) for x,y in zip(a,[1793,*b[1:]]))
    print('D-02 exact PCM ratio 7/10; adjacent rounded products exclude any binary64 multiplication gain; one-LSB mutation differs')


def sweep(t):
    # Discriminating changing-frequency, multicomponent same-clock control.
    # These coefficients are retained here and in the native integration test.
    return (.4*np.sin(2*np.pi*(150*t+80*t*t))
            +.15*np.cos(2*np.pi*(280*t+95*t*t))
            +.07*np.sin(2*np.pi*(400*t+120*t*t)))


def timing_oracles():
    for rate, frequencies, phases in [(8000,[1,5,10,20,40],[0.,.91]),(48000,[20,40],[.37])]:
        t=np.arange(rate*4)/rate
        a=r1.wave(t)
        for f in frequencies:
            for phase in phases:
                b=r1.wave(t+.0025/(2*np.pi*f)*np.sin(2*np.pi*f*t+phase))
                off,d,ok,detail=estimate(a,b,rate)
                assert ok,(rate,f,phase,detail)
                peak=drift(a,b,off,d,rate)
                assert peak is not None and abs(peak-.25)<=.025,(rate,f,phase,peak,detail)
                print(f'D-01 rate {rate}, modulation {f} Hz phase {phase}: analytic .25%; model {peak:.9f}%; {detail}',flush=True)
        # Genuine constant affine speed, no flutter.
        delta=.002; delay=3.25
        b=r1.wave((np.arange(round(len(a)*(1+delta)+delay))-delay)/(rate*(1+delta)))
        off,d,ok,detail=estimate(a,b,rate)
        assert ok and abs(d-delta)<2e-5,(rate,d,detail)
        peak=drift(a,b,off,d,rate)
        assert peak is not None and peak<.0005,(rate,peak,detail)
        print(f'constant affine control rate {rate}, drift {peak:.9f}%; {detail}',flush=True)
    rate=8000;t=np.arange(rate*4)/rate;a=r1.wave(t)
    # The original affine cases are still required, not merely the new tiny
    # slope and modulation cases. In particular retain the large trim offset.
    for delta,delay in [(-.003,19.25),(.002,-8.4),(1e-7,0.),(1e-9,0.),(-.04,0.),(.04,0.),(.001,3500.)]:
        b=r1.wave((np.arange(round(len(a)*(1+delta)+delay))-delay)/(rate*(1+delta)))
        off,d,ok,detail=estimate(a,b,rate)
        assert ok and abs(d-delta)<(2e-10 if abs(delta)<1e-6 else 2e-5),(delta,d,detail)
        print(f'D-03 genuine affine slope {delta:g}, delay {delay:g}: observed {d:.12g}; {detail}',flush=True)
    for rate,waveforms in [(8000,[r1.wave,sweep]),(48000,[sweep])]:
        t=np.arange(rate*4)/rate
        for waveform in waveforms:
            a=waveform(t)
            for cutoff in [1000,3000]:
                b=sosfilt(butter(2,cutoff,fs=rate,output='sos'),a)
                off,d,ok,detail=estimate(a,b,rate)
                assert not ok,(rate,waveform.__name__,cutoff,d,detail)
                print(f'D-03 rate {rate} {waveform.__name__} same-clock LP {cutoff} Hz: candidate {-100*d/(1+d):.12g}% rejected; {detail}',flush=True)
        # A real clock plus EQ may be resolvable or explicitly ambiguous.
        delta=.002;a=sweep(t)
        b=sosfilt(butter(2,1000,fs=rate,output='sos'),sweep(np.arange(round(len(a)*(1+delta)))/(rate*(1+delta))))
        off,d,ok,detail=estimate(a,b,rate)
        assert not ok or abs(d-delta)<2e-5,(rate,d,detail)
        print(f'D-03 rate {rate} EQ + genuine slope {delta}: {d if ok else "ambiguous"}; {detail}',flush=True)


# R2-AUD-01: independent model of the narrowly admitted integer grid after
# (and only after) physical clock validation fails. r1.loss evaluates the
# direct gain-fitted residual, not a difference of nearly equal energies.
def integer_grid(a,b,off,d,anchors,rate):
    integer=round(off); mid=len(a)//2
    if max(abs(off+d*(i-mid)-integer) for i in [0,len(a)-1])>.01:
        return None, 'affine endpoint outside integer radius'
    if max(abs(l-integer) for _,l in anchors)>.01:
        return None, 'refined anchor outside integer radius'
    ratios=[]
    for c,l in anchors:
        def loss(lag,delta,sinc):
            return r1.loss(a,b,c,lag,delta,max(16,rate//100),max(1,rate//48000),sinc)
        il=loss(integer,0.,False)
        if not math.isfinite(il):
            return None, 'integer residual is not finite'
        neighbors=[loss(integer+k,0.,False) for k in [-1,1]]
        if any(not math.isfinite(x) or x<=4*max(il,1e-29) for x in neighbors):
            return None, 'neighboring integer grid is not distinguished'
        fl=[loss(off+d*(c-mid),d,True),loss(l,d,True)]
        if any(not math.isfinite(x) for x in fl) or il>1.05*min(fl):
            return None, 'fractional residual materially better'
        ratios.append(il/min(fl) if min(fl)>0 else 1.)
    start=max(0,-integer);end=min(len(a),len(b)-integer)
    if end-start<.8*max(len(a),len(b)):
        return None, 'insufficient integer overlap'
    step=max(1,math.ceil((end-start)/65536))
    x=a[start:end:step];y=b[start+integer:end+integer:step]
    corr=abs(np.dot(x,y))/(np.linalg.norm(x)*np.linalg.norm(y))
    if corr<.99999:
        return None, 'insufficient whole-overlap waveform evidence'
    return integer, f'max local power ratio {max(ratios):.8f}, whole-overlap correlation {corr:.12f}'


def splitmix_uniform(seed,n):
    mask=(1<<64)-1
    values=np.empty(n)
    for i in range(n):
        seed=(seed+0x9e3779b97f4a7c15)&mask
        z=seed
        z=((z^(z>>30))*0xbf58476d1ce4e5b9)&mask
        z=((z^(z>>27))*0x94d049bb133111eb)&mask
        z^=z>>31
        values[i]=(z>>11)/2**53
    return values


def pcm_oracle(a,b,rate):
    # Independent direct least-squares oracle, using the known input grid,
    # not fitted lags. One fitted gain, then all rolling window energies.
    residual=a-(np.dot(a,b)/np.dot(b,b))*b
    def depth(x,y):return 10*math.log10(np.dot(y,y)/np.dot(x,x))
    windows=sorted(depth(a[i:i+rate],residual[i:i+rate])
                   for i in range(0,len(a)-rate+1,rate//2))
    return depth(a,residual),windows


def integer_grid_oracles():
    for rate in [8000,44100,48000]:
        r1.RATE=rate
        original=r1.wave(np.arange(4*rate)/rate)
        a=np.round(original*2**23)/2**23
        rng1=np.random.default_rng(13);rng2=np.random.default_rng(14)
        cases=[('24->16 nearest',a,np.round(a*2**15)/2**15),
               ('24->16 TPDF numpy',a,np.round(a*2**15+rng1.random(len(a))-rng2.random(len(a)))/2**15),
               ('float->24 nearest',original,a)]
        if rate==44100:
            # The native fixture uses portable SplitMix64 instead of NumPy's
            # PCG64; test the same independent dither construction as well.
            u1=splitmix_uniform(13,len(a));u2=splitmix_uniform(14,len(a))
            cases.append(('24->16 TPDF native fixture',a,np.round(a*2**15+u1-u2)/2**15))
        for label,x,y in cases:
            off,d,anchors=r1.estimate(x,y)
            clock,why=observable(x,y,off,d,anchors,rate)
            assert clock is None,(rate,label,clock,why)
            integer,detail=integer_grid(x,y,off,d,anchors,rate)
            assert integer==0,(rate,label,detail)
            depth,windows=pcm_oracle(x,y,rate)
            print(f'R2-AUD-01 rate {rate} {label}: R2 clock rejected; grid {integer}, {detail}; '
                  f'oracle null {depth:.9f} dB, median {windows[(len(windows)-1)//2]:.9f}, '
                  f'p99/worst {windows[-1]:.9f}, pooled exact+test {depth-10*math.log10(2):.9f}',flush=True)
    # A nonzero integer lag is also usable when the clock is unresolved.
    rate=8000;r1.RATE=rate
    a=np.round(r1.wave(np.arange(4*rate)/rate)*2**23)/2**23
    b=np.r_[np.zeros(19),np.round(a*2**15)/2**15]
    off,d,anchors=r1.estimate(a,b)
    clock,why=observable(a,b,off,d,anchors,rate)
    assert clock is None,why
    grid,detail=integer_grid(a,b,off,d,anchors,rate)
    assert grid==19,detail
    depth,_=pcm_oracle(a,b[19:],rate)
    print(f'R2-AUD-01 shifted requantized control: grid {grid}; {detail}; oracle null {depth:.9f} dB',flush=True)
    # Retain the existing phase-processing rejection and genuine affine
    # path, including tiny slopes. Validation runs before grid admission.
    for rate,waveforms in [(8000,[r1.wave,sweep]),(48000,[sweep])]:
        r1.RATE=rate;t=np.arange(rate*4)/rate
        for waveform in waveforms:
            a=waveform(t)
            for cutoff in [1000,3000]:
                b=sosfilt(butter(2,cutoff,fs=rate,output='sos'),a)
                off,d,anchors=r1.estimate(a,b)
                clock,why=observable(a,b,off,d,anchors,rate)
                assert clock is None,(rate,waveform.__name__,cutoff,why)
                grid,detail=integer_grid(a,b,off,d,anchors,rate)
                assert grid is None,(rate,waveform.__name__,cutoff,detail)
                print(f'R2-AUD-01 {rate} {waveform.__name__} EQ {cutoff}: clock and grid rejected; {detail}',flush=True)
    r1.RATE=8000;rate=8000;t=np.arange(4*rate)/rate;a=r1.wave(t)
    for delta,delay in [(1e-9,0.),(1e-7,0.),(0.,.003),(.002,3.25)]:
        b=r1.wave((np.arange(round(len(a)*(1+delta)+delay))-delay)/(rate*(1+delta)))
        off,d,anchors=r1.estimate(a,b)
        clock,why=observable(a,b,off,d,anchors,rate)
        assert clock is not None and abs(clock[1]-delta)<(2e-10 if abs(delta)<1e-6 else 2e-5),(delta,delay,why)
        assert abs(clock[0]-(delay+delta*(len(a)//2)))<.001,(clock,delta,delay)
        print(f'R2-AUD-01 genuine affine delta {delta:g}, delay {delay:g}: validated, no grid fallback; {why}',flush=True)
    print('PASS: R2-AUD-01 independent PCM/grid and clock controls (NOT native Rust qualification)',flush=True)


def quiet_grid_oracles():
    # R3-AUD-01: independent known-grid oracle on exactly the same PCM
    # constructions as the new native test. The middle anchor (2 s) is
    # entirely in the quiet plateau in the mixed-level case.
    rate=44100;r1.RATE=rate
    t=np.arange(4*rate)/rate
    base=r1.wave(t)
    envelope=.1+.9*np.clip((np.abs(t-2)-.15)/.05,0,1)
    u=splitmix_uniform(13,len(t))-splitmix_uniform(14,len(t))
    for label,scale,dither in [('normal TPDF',1,True),('quiet TPDF',.1,True),
                               ('quiet nearest',.03162277660168379,False),
                               ('one quiet passage TPDF',envelope,True)]:
        a=np.round(base*scale*2**23)/2**23
        b=np.round(a*2**15+(u if dither else 0))/2**15
        off,d,anchors=r1.estimate(a,b)
        clock,why=observable(a,b,off,d,anchors,rate)
        assert clock is None,(label,why)
        grid,detail=integer_grid(a,b,off,d,anchors,rate)
        assert grid==0,(label,detail)
        depth,windows=pcm_oracle(a,b,rate)
        losses=[]
        for c,l in anchors:
            il=r1.loss(a,b,c,0.,0.,rate//100,1,False)
            losses.append(il)
        # Each new regression really crosses the removed R3 ceiling.
        assert (max(losses)>1e-6)==(label!='normal TPDF'),(label,losses)
        print(f'R3-AUD-01 {label}: grid {grid}; {detail}; '
              f'oracle null {depth:.9f} dB, max anchor residual {10*math.log10(max(losses)):.9f} dB, '
              f'median {windows[(len(windows)-1)//2]:.9f}, worst {windows[-1]:.9f}; clock unresolved',flush=True)
    print('PASS: R3-AUD-01 independent quiet PCM grid checks (NOT native Rust qualification)',flush=True)


if __name__=='__main__':
    rational_gain_oracle()
    timing_oracles()
    print('PASS: D-01..03 analytic/reference model checks (NOT native Rust qualification)')
    integer_grid_oracles()
    quiet_grid_oracles()
