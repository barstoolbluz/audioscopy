// SPDX-License-Identifier: GPL-2.0-or-later
//! Wall-clock evidence for selective comparisons, not a speed acceptance gate.
use audioscopy::comparison::{
    compare, Measurement as M, Measurements, Pair, Recording, ReferenceSource,
};
use audioscopy::{Encoding, Format};
use std::time::Instant;

fn signal(t: f64) -> f64 {
    use std::f64::consts::TAU;
    (0.74 + 0.19 * (TAU * 0.71 * t).sin())
        * (0.18 * (TAU * (113.7 * t + 3.21 * t * t)).sin()
            + 0.12 * (TAU * (379.1 * t + 7.13 * t * t)).cos()
            + 0.08 * (TAU * (727.3 * t + 11.61 * t * t + 0.03)).sin())
}
fn main() {
    let args: Vec<_> = std::env::args().collect();
    let rate: u32 = args
        .get(1)
        .map_or(48000, |v| v.parse().expect("sample rate"));
    let seconds: usize = args.get(2).map_or(6, |v| v.parse().expect("seconds"));
    assert!((8000..=768000).contains(&rate) && (2..=60).contains(&seconds));
    let n = rate as usize * seconds;
    let f = Format {
        sample_rate: rate,
        channels: 1,
        encoding: Encoding::Float,
        loudness_roles: None,
    };
    let a: Vec<_> = (0..n).map(|i| signal(i as f64 / f64::from(rate))).collect();
    let b: Vec<_> = (0..n)
        .map(|i| 0.8 * signal((i as f64 - 19.25) / (1.0001 * f64::from(rate))))
        .collect();
    let pair = Pair {
        reference: Recording {
            format: &f,
            samples: &a,
        },
        recording: Recording {
            format: &f,
            samples: &b,
        },
        reference_source: ReferenceSource::Digital,
    };
    println!("rate={rate} frames={n} seconds={seconds}, mono; input generation excluded; first alignment includes phase-table initialization");
    for m in [
        M::SameAudio,
        M::TonalBalance,
        M::Speed,
        M::NullDepth,
        M::TimingDrift,
        M::ResidualOverTime,
    ] {
        let start = Instant::now();
        let r = std::hint::black_box(compare(pair, Measurements::new(&[m])).expect("comparison"));
        let elapsed = start.elapsed().as_secs_f64();
        println!(
            "{m:?}: {elapsed:.6} s, {:.3} x realtime; alignment={:?}",
            seconds as f64 / elapsed,
            r.alignment
        );
        match m {
            M::Speed => println!("speed={:?}", r.speed),
            M::NullDepth => println!("null={:?}", r.null_depth_db),
            M::TimingDrift => println!("drift={:?}", r.timing_drift_percent),
            M::SameAudio => println!("identity={:?}", r.same_audio),
            M::ResidualOverTime => println!("residual={:?}", r.residual_over_time),
            M::TonalBalance => match r.tonal_balance {
                audioscopy::Outcome::Value(t) => println!(
                    "tonal normalization={:?}, largest={:?}, bins={}",
                    t.normalization,
                    t.largest,
                    t.curve.len()
                ),
                other => println!("tonal={other:?}"),
            },
            _ => unreachable!(),
        }
    }
    let start = Instant::now();
    let r = std::hint::black_box(compare(pair, Measurements::all()).expect("all comparisons"));
    println!(
        "all: {:.6} s, alignment={:?}",
        start.elapsed().as_secs_f64(),
        r.alignment
    );
}
