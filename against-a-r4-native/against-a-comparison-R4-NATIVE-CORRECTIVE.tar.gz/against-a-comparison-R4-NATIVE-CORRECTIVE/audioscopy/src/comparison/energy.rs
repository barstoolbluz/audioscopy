// SPDX-License-Identifier: GPL-2.0-or-later
//! Residual energy without subtracting nearly equal signal energies.
use super::{align, cant, Pair, ResidualSummary};
use crate::{Error, Outcome};

#[derive(Clone, Copy, Default)]
struct Sum {
    value: f64,
    correction: f64,
}
impl Sum {
    fn add(&mut self, x: f64) {
        // Neumaier compensation works for both signed and unsigned sums.
        let next = self.value + x;
        self.correction += if self.value.abs() >= x.abs() {
            (self.value - next) + x
        } else {
            (x - next) + self.value
        };
        self.value = next;
    }
    fn get(self) -> f64 {
        self.value + self.correction
    }
}

// Scaled Euclidean norm. Squaring the unscaled residual can underflow even
// for a perfectly ordinary binary64 input. Keep the largest magnitude and
// the sum of scaled squares separately; never construct the linear power.
#[derive(Clone, Copy, Default)]
struct Norm {
    scale: f64,
    sum: Sum,
}
impl Norm {
    fn add(&mut self, x: f64) {
        let x = x.abs();
        if x == 0.0 {
            return;
        }
        if x > self.scale {
            let ratio = self.scale / x;
            self.sum = Sum {
                value: self.sum.get() * ratio * ratio,
                correction: 0.0,
            };
            self.scale = x;
        }
        let ratio = x / self.scale;
        self.sum.add(ratio * ratio);
    }
    fn merge(&mut self, other: Self) {
        if other.scale == 0.0 {
            return;
        }
        if self.scale < other.scale {
            let old = *self;
            *self = other;
            self.merge(old);
        } else {
            let r = other.scale / self.scale;
            self.sum.add(other.sum.get() * r * r);
        }
    }
    fn db(self) -> f64 {
        if self.scale == 0.0 {
            f64::NEG_INFINITY
        } else {
            20.0 * self.scale.log10() + 10.0 * self.sum.get().log10()
        }
    }
}

#[derive(Clone, Copy, Default)]
struct Window {
    reference: Norm,
    residual: Norm,
}
impl Window {
    fn add(&mut self, a: f64, residual: f64) {
        self.reference.add(a);
        self.residual.add(residual);
    }
    fn merge(&mut self, other: Self) {
        self.reference.merge(other.reference);
        self.residual.merge(other.residual);
    }
    fn depth(self) -> Option<f64> {
        if self.reference.scale == 0.0 && self.residual.scale == 0.0 {
            None
        } else {
            Some(self.residual.db() - self.reference.db())
        }
    }
}

// Track-level sufficient statistics, in logarithmic energy units. A track's
// conditioning scale is removed before merging; a very deep quiet track
// does not get accidentally weighted equally to a loud one.
#[derive(Clone, Copy)]
pub(super) struct NullEnergy {
    reference_db: f64,
    residual_db: f64,
    resolved: bool,
}
impl NullEnergy {
    pub(super) fn empty() -> Self {
        Self {
            reference_db: f64::NEG_INFINITY,
            residual_db: f64::NEG_INFINITY,
            resolved: true,
        }
    }
    pub(super) fn depth(self) -> f64 {
        self.residual_db - self.reference_db
    }
    pub(super) fn outcome(self) -> Outcome<f64> {
        if self.resolved {
            Outcome::Value(self.depth())
        } else {
            cant("nonzero residual is below the resolved arithmetic range")
        }
    }
    pub(super) fn merge(&mut self, other: Self) {
        self.reference_db = log_add(self.reference_db, other.reference_db);
        self.residual_db = log_add(self.residual_db, other.residual_db);
        self.resolved &= other.resolved;
    }
}
fn log_add(a: f64, b: f64) -> f64 {
    let hi = a.max(b);
    let lo = a.min(b);
    if hi == f64::NEG_INFINITY {
        hi
    } else {
        hi + (10.0 / std::f64::consts::LN_10) * 10.0_f64.powf((lo - hi) / 10.0).ln_1p()
    }
}

struct Rolling {
    rate: usize,
    // Nonoverlapping half-second energy buckets with rational boundaries.
    // A window is a pair of adjacent buckets; retain only their statistics.
    bucket_index: u64,
    next_end: u64,
    current: Window,
    previous: Option<Window>,
    values: Vec<f64>,
    frames: u64,
    last_reported_end: u64,
}
impl Rolling {
    fn new(rate: usize, frames: usize) -> Result<Self, Error> {
        let count = (frames as u64).saturating_mul(2).div_ceil(rate as u64);
        if count > 4_000_000 {
            return Err(Error::ResourceLimit);
        }
        Ok(Self {
            rate,
            bucket_index: 1,
            next_end: rate as u64 / 2,
            current: Window::default(),
            previous: None,
            values: Vec::new(),
            frames: 0,
            last_reported_end: 0,
        })
    }
    fn add(&mut self, a: f64, r: f64) {
        self.current.add(a, r);
    }
    fn end_frame(&mut self) {
        self.frames += 1;
        if self.frames == self.next_end {
            self.close_bucket(false);
            self.bucket_index += 1;
            self.next_end = self.bucket_index * self.rate as u64 / 2;
        }
    }
    fn close_bucket(&mut self, final_partial: bool) {
        let current = std::mem::take(&mut self.current);
        if let Some(mut previous) = self.previous {
            previous.merge(current);
            if let Some(d) = previous.depth() {
                self.values.push(d);
            }
            self.last_reported_end = self.frames;
        } else if final_partial {
            if let Some(d) = current.depth() {
                self.values.push(d);
            }
            self.last_reported_end = self.frames;
        }
        self.previous = Some(current);
    }
    fn finish(mut self) -> Outcome<ResidualSummary> {
        if self.frames > self.last_reported_end {
            if self.frames == (self.bucket_index - 1) * self.rate as u64 / 2 {
                // Exactly one complete half-bucket and no full window.
                if self.last_reported_end == 0 {
                    if let Some(d) = self.previous.and_then(Window::depth) {
                        self.values.push(d);
                    }
                }
            } else {
                self.close_bucket(true);
            }
        }
        if self.values.is_empty() {
            return cant("no informative rolling residual windows");
        }
        self.values.sort_by(f64::total_cmp);
        let n = self.values.len();
        Outcome::Value(ResidualSummary {
            median_db: self.values[(n - 1) / 2],
            percentile_99_db: self.values[(99 * n).div_ceil(100) - 1],
            worst_db: self.values[n - 1],
            windows: n,
        })
    }
}

fn scale_from_peak(peak: f64) -> f64 {
    let exp = (peak.to_bits() >> 52) & 0x7ff;
    f64::from_bits(exp.max(1) << 52)
}

// Difference from the exact rational gain through an anchor sample. The two
// products carry their rounding errors via FMA. Near cancellation the high
// subtraction is exact (Sterbenz); the low difference restores the terms
// that would be lost by first rounding anchor_a/anchor_b to f64.
fn anchor_residual(a: f64, b: f64, anchor_a: f64, anchor_b: f64) -> f64 {
    let p = a * anchor_b;
    let q = b * anchor_a;
    let pe = a.mul_add(anchor_b, -p);
    let qe = b.mul_add(anchor_a, -q);
    ((p - q) + (pe - qe)) / anchor_b
}

// Integer-aligned zero certification uses exact binary64 significands. An
// arbitrary gain need not itself be representable (e.g. 1/3). Cross products
// of the odd significands fit in u128, without exponent-range restrictions.
fn binary_parts(x: f64) -> (u64, i32, bool) {
    let bits = x.to_bits();
    let raw = ((bits >> 52) & 0x7ff) as i32;
    let mant = (bits & ((1_u64 << 52) - 1)) | if raw == 0 { 0 } else { 1_u64 << 52 };
    if mant == 0 {
        return (0, 0, false);
    }
    let shift = mant.trailing_zeros();
    (
        mant >> shift,
        raw.max(1) - 1023 - 52 + shift as i32,
        bits >> 63 != 0,
    )
}
pub(super) fn proportional(a: f64, b: f64, a0: f64, b0: f64) -> bool {
    if a == 0.0 || b == 0.0 {
        return a == 0.0 && b == 0.0;
    }
    let (ma, ea, sa) = binary_parts(a);
    let (mb, eb, sb) = binary_parts(b);
    let (mc, ec, sc) = binary_parts(a0);
    let (md, ed, sd) = binary_parts(b0);
    ea + ed == eb + ec
        && (sa ^ sd) == (sb ^ sc)
        && u128::from(ma) * u128::from(md) == u128::from(mb) * u128::from(mc)
}

pub(super) fn residual(
    pair: Pair<'_>,
    model: &align::Model,
    windows: bool,
) -> Result<Option<(NullEnergy, Outcome<ResidualSummary>)>, Error> {
    let a = pair.reference;
    let b = pair.recording;
    // Condition using the actual compared support, not discarded endpoints.
    // The reference and B use separate exact powers of two.
    let mut peak_a = 0.0_f64;
    let mut peak_b = 0.0_f64;
    let mut anchor = (0.0_f64, 0.0_f64);
    for i in model.start..model.end {
        for c in 0..a.format.channels {
            let x = a.sample(i, c);
            let y = model.sample(b, i, c);
            peak_a = peak_a.max(x.abs());
            if y.abs() > peak_b {
                peak_b = y.abs();
                anchor = (x, y);
            }
        }
    }
    if peak_a == 0.0 || peak_b == 0.0 {
        return Ok(None);
    }
    let a_scale = scale_from_peak(peak_a);
    let b_scale = scale_from_peak(peak_b);
    let a0 = anchor.0 / a_scale;
    let b0 = anchor.1 / b_scale;
    let mut bb = Sum::default();
    let mut br = Sum::default();
    for i in model.start..model.end {
        for c in 0..a.format.channels {
            let x = a.sample(i, c) / a_scale;
            let y = model.sample(b, i, c) / b_scale;
            bb.add(y * y);
            br.add(y * anchor_residual(x, y, a0, b0));
        }
    }
    let delta = br.get() / bb.get();
    if !delta.is_finite() {
        return Err(Error::Failed);
    }
    let mut total = Window::default();
    let mut rolling = if windows {
        Some(Rolling::new(
            a.format.sample_rate as usize,
            model.end - model.start,
        )?)
    } else {
        None
    };
    let integer = model.sampler.is_none();
    // Only attempt the exact proportionality proof when a zero is plausible.
    // A nonzero value of anchor_a is necessary for a nontrivial exact gain.
    let mut exact = integer && anchor.0 != 0.0;
    for i in model.start..model.end {
        for c in 0..a.format.channels {
            let raw_a = a.sample(i, c);
            let raw_b = model.sample(b, i, c);
            let x = raw_a / a_scale;
            let y = raw_b / b_scale;
            let r = (-delta).mul_add(y, anchor_residual(x, y, a0, b0));
            if exact {
                exact = proportional(raw_a, raw_b, anchor.0, anchor.1);
            }
            total.add(x, r);
            if let Some(w) = &mut rolling {
                w.add(x, r);
            }
        }
        if let Some(w) = &mut rolling {
            w.end_frame();
        }
    }
    let scale_db = 20.0 * a_scale.log10();
    let reference_db = total.reference.db() + scale_db;
    let residual_db = if exact {
        f64::NEG_INFINITY
    } else {
        total.residual.db() + scale_db
    };
    // A computed zero cannot assert exact integer-aligned proportionality
    // unless the significand proof passed. Fractional comparisons describe
    // the specified evaluator, not an unknowable continuous waveform.
    let resolved = exact || residual_db != f64::NEG_INFINITY || !integer;
    let stats = NullEnergy {
        reference_db,
        residual_db,
        resolved,
    };
    let summary = match rolling {
        None => Outcome::NotRequested,
        Some(_) if !resolved => cant("nonzero residual is below the resolved arithmetic range"),
        Some(w) if exact => match w.finish() {
            Outcome::Value(v) => Outcome::Value(ResidualSummary {
                median_db: f64::NEG_INFINITY,
                percentile_99_db: f64::NEG_INFINITY,
                worst_db: f64::NEG_INFINITY,
                windows: v.windows,
            }),
            other => other,
        },
        Some(w) => w.finish(),
    };
    Ok(Some((stats, summary)))
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn exact_ratio_and_subnormal_norm() {
        assert!(proportional(1.0, 3.0, 2.0, 6.0));
        assert!(!proportional(1.0, 3.0, 2.0, 6.0 + f64::EPSILON * 4.0));
        assert!(proportional(-1.0, 3.0, -2.0, 6.0));
        assert!(!proportional(1.0, 3.0, -2.0, 6.0));
        let mut norm = Norm::default();
        norm.add(f64::from_bits(1));
        norm.add(f64::from_bits(1));
        assert!(norm.db().is_finite());
        assert!(
            (norm.db() - (20.0 * f64::from_bits(1).log10() + 10.0 * 2.0_f64.log10())).abs() < 1e-10
        );
    }
    #[test]
    fn rational_window_boundaries() {
        for n in [1, 4000, 4001, 8000, 8001, 12000, 12001] {
            let mut w = Rolling::new(8000, n).unwrap();
            for _ in 0..n {
                w.add(1.0, 0.5);
                w.end_frame();
            }
            let Outcome::Value(s) = w.finish() else {
                panic!("missing window");
            };
            assert!((s.worst_db - 20.0 * 0.5_f64.log10()).abs() < 1e-12);
            let expected = if n <= 8000 {
                1
            } else {
                (n - 8000_usize).div_ceil(4000) + 1
            };
            assert_eq!(s.windows, expected);
        }
    }
}
