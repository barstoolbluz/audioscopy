// SPDX-License-Identifier: GPL-2.0-or-later
//! Conservative, bounded clock alignment. Fit delays rather than absolute
//! timestamps so a small slope is not lost by subtracting two large times.
use super::{cant, exact_gain, AlignmentSupport, Pair, PolarityAndChannels, Recording, Speed};
use crate::{Error, Outcome};
use std::f64::consts::{LN_2, PI};

const HALF: usize = 128;
const PHASES: usize = 8192;
const COARSE_CANDIDATES: usize = 12;
const MIN_CORRELATION: f64 = 0.60;
const MAX_STRETCH: f64 = 0.05;

// Exact power-of-two conditioning, including subnormal inputs. The exponent
// is clamped at -1022 so the divisor itself is always a normal f64.
pub(super) fn scale(pcm: &[f64]) -> f64 {
    let peak = pcm.iter().fold(0.0_f64, |p, &x| p.max(x.abs()));
    let exponent = (peak.to_bits() >> 52) & 0x7ff;
    f64::from_bits(exponent.max(1) << 52)
}

/// Local bandlimited interpolation for an alignment measurement, not a PCM
/// resampler API. Tabulation makes the cost independent of transcendental
/// throughput; integer positions bypass the table exactly.
type Phase = [f64; 2 * HALF];
static PHASE_TABLE: std::sync::OnceLock<Vec<Phase>> = std::sync::OnceLock::new();

pub(super) struct Interpolator {
    weights: &'static [Phase],
}

// I0's positive power series converges rapidly over this fixed [0,16]
// argument range. It is used only while constructing the immutable table.
fn i0(x: f64) -> f64 {
    let t = x * x * 0.25;
    let mut term = 1.0;
    let mut sum = 1.0;
    for k in 1..=48 {
        term *= t / f64::from(k * k);
        sum += term;
        if term <= f64::EPSILON * sum {
            break;
        }
    }
    sum
}

impl Interpolator {
    pub(super) fn new() -> Self {
        let weights = PHASE_TABLE.get_or_init(|| {
            // A 256-tap, beta-16 Kaiser-windowed fractional-delay evaluator.
            // Store only half the phases; reversal supplies the other half.
            let mut weights = Vec::with_capacity(PHASES / 2 + 1);
            let denominator = i0(16.0);
            for phase in 0..=PHASES / 2 {
                let mut w = [0.0; 2 * HALF];
                if phase == 0 {
                    w[HALF - 1] = 1.0;
                } else {
                    let f = phase as f64 / PHASES as f64;
                    let sine = (PI * f).sin();
                    for (j, v) in w.iter_mut().enumerate() {
                        let k = j as isize - (HALF - 1) as isize;
                        let x = k as f64 - f;
                        let window = i0(16.0 * (1.0 - (x / HALF as f64).powi(2)).max(0.0).sqrt())
                            / denominator;
                        let numerator = if k % 2 == 0 { -sine } else { sine };
                        *v = numerator / (PI * x) * window;
                    }
                    let sum: f64 = w.iter().sum();
                    for v in &mut w {
                        *v /= sum;
                    }
                }
                weights.push(w);
            }
            weights
        });
        Self { weights }
    }

    // Keep the integer frame separate from the fractional delay. In long
    // recordings, adding a fractional delay to an absolute f64 frame loses
    // significant low bits long before a tiny speed change is observable.
    pub(super) fn at(&self, b: Recording<'_>, i: usize, channel: usize, lag: f64) -> Option<f64> {
        let (j, f) = position(i, lag)?;
        if j >= b.frames() {
            return None;
        }
        if f == 0.0 {
            return Some(b.sample(j, channel));
        }
        if j < HALF - 1 || j.checked_add(HALF)? >= b.frames() {
            return None;
        }
        let mirrored = f > 0.5;
        let phase = (if mirrored { 1.0 - f } else { f }) * PHASES as f64;
        let k = (phase as usize).min(PHASES / 2 - 1);
        let mix = phase - k as f64;
        let start = j - (HALF - 1);
        let mut sum = 0.0;
        for (tap, (&a, &z)) in self.weights[k].iter().zip(&self.weights[k + 1]).enumerate() {
            let w = a + (z - a) * mix;
            let tap = if mirrored { 2 * HALF - 1 - tap } else { tap };
            sum += w * b.sample(start + tap, channel);
        }
        Some(sum)
    }
    // The derivative of the tabulated piecewise-linear fractional-delay
    // evaluator, in sample units per frame. Share the tap traversal with
    // the value; this is a local fit Jacobian, not an additional resampler.
    fn value_and_derivative(
        &self,
        b: Recording<'_>,
        i: usize,
        channel: usize,
        lag: f64,
    ) -> Option<(f64, f64)> {
        let (j, f) = position(i, lag)?;
        if j < HALF - 1 || j.checked_add(HALF)? >= b.frames() {
            return None;
        }
        let mirrored = f > 0.5;
        let phase = (if mirrored { 1.0 - f } else { f }) * PHASES as f64;
        let k = (phase as usize).min(PHASES / 2 - 1);
        let mix = phase - k as f64;
        let start = j - (HALF - 1);
        let mut value = 0.0;
        let mut derivative = 0.0;
        for (tap, (&a, &z)) in self.weights[k].iter().zip(&self.weights[k + 1]).enumerate() {
            let tap = if mirrored { 2 * HALF - 1 - tap } else { tap };
            let x = b.sample(start + tap, channel);
            let dw = z - a;
            value += (a + dw * mix) * x;
            derivative += dw * x;
        }
        if f == 0.0 {
            value = b.sample(j, channel);
        }
        derivative *= if mirrored {
            -(PHASES as f64)
        } else {
            PHASES as f64
        };
        Some((value, derivative))
    }
}

fn position(i: usize, lag: f64) -> Option<(usize, f64)> {
    if !lag.is_finite() || lag.abs() > (1_u64 << 49) as f64 {
        return None;
    }
    let floor = lag.floor();
    let j = i.checked_add_signed(floor as isize)?;
    Some((j, lag - floor))
}

fn linear(b: Recording<'_>, i: usize, c: usize, lag: f64) -> Option<f64> {
    let (j, f) = position(i, lag)?;
    if j >= b.frames() {
        return None;
    }
    let x = b.sample(j, c);
    if f == 0.0 {
        return Some(x);
    }
    if j + 1 >= b.frames() {
        return None;
    }
    Some((b.sample(j + 1, c) - x).mul_add(f, x))
}

#[derive(Clone, Copy)]
struct Anchor {
    center: usize,
    lag: f64,
    reference_channel: usize,
    recording_channel: usize,
}
#[derive(Clone, Copy)]
struct Clock {
    midpoint: usize,
    delay: f64,
    delta: f64,
    scatter: f64,
}
impl Clock {
    fn lag(self, i: usize) -> f64 {
        self.delta
            .mul_add(i as f64 - self.midpoint as f64, self.delay)
    }
    fn speed(self) -> Speed {
        Speed {
            percent: -100.0 * self.delta / (1.0 + self.delta),
            cents: -1200.0 * self.delta.ln_1p() / LN_2,
            fit_scatter_percent: self.scatter,
        }
    }
}

pub(super) struct Model {
    clock: Clock,
    pub(super) start: usize,
    pub(super) end: usize,
    pub(super) swapped: bool,
    inverted: bool,
    polarity_known: bool,
    speed_known: bool,
    exact: bool,
    pub(super) sampler: Option<Interpolator>,
}
impl Model {
    pub(super) fn support(&self) -> AlignmentSupport {
        AlignmentSupport {
            midpoint_delay_frames: self.clock.delay,
            first_reference_frame: self.start as u64,
            compared_frames: (self.end - self.start) as u64,
            fractional: self.sampler.is_some(),
        }
    }
    pub(super) fn speed(&self) -> Outcome<Speed> {
        if self.speed_known {
            Outcome::Value(self.clock.speed())
        } else if self.exact {
            cant("insufficient varying material to observe a clock difference")
        } else {
            cant("clock motion is unresolved at the available waveform fidelity")
        }
    }
    pub(super) fn polarity(&self) -> Outcome<PolarityAndChannels> {
        if !self.polarity_known {
            return cant("global polarity or channel order is ambiguous");
        }
        Outcome::Value(match (self.swapped, self.inverted) {
            (false, false) => PolarityAndChannels::Same,
            (false, true) => PolarityAndChannels::Inverted,
            (true, false) => PolarityAndChannels::Swapped,
            (true, true) => PolarityAndChannels::SwappedAndInverted,
        })
    }
    pub(super) fn sample(&self, b: Recording<'_>, i: usize, c: usize) -> f64 {
        let c = if self.swapped { 1 - c } else { c };
        let lag = self.clock.lag(i);
        match &self.sampler {
            Some(s) => s.at(b, i, c, lag).expect("validated fractional support"),
            None => {
                let (j, _) = position(i, lag).expect("validated integer support");
                b.sample(j, c)
            }
        }
    }
}

fn variance(values: &[f64]) -> f64 {
    let mean = values.iter().sum::<f64>() / values.len().max(1) as f64;
    values.iter().map(|v| (v - mean) * (v - mean)).sum()
}

// Every frame is examined. A strided scan aliases with periodic material
// whose period divides the stride and misreports it as constant.
fn informative(a: Recording<'_>, start: usize, end: usize, conditioning: f64) -> bool {
    (0..a.format.channels).any(|c| {
        let mut min = f64::INFINITY;
        let mut max = f64::NEG_INFINITY;
        for i in start..end {
            let x = a.sample(i, c) / conditioning;
            min = min.min(x);
            max = max.max(x);
        }
        max - min > 1e-9
    })
}

// The exact equality/gain path is both a useful common-case optimization and
// protection from an interpolation estimator rounding an exact null upwards.
// For nonidentical material all clock evidence comes from local matching.
fn exact_model(pair: Pair<'_>, a_scale: f64) -> Option<Model> {
    let a = pair.reference;
    let b = pair.recording;
    if a.frames() != b.frames() {
        return None;
    }
    let mut choice = None;
    'mapping: for swapped in [false, true] {
        if swapped && a.format.channels != 2 {
            continue;
        }
        for sign in [1.0, -1.0] {
            if exact_gain(pair, swapped, sign).is_some() {
                choice = Some((swapped, sign < 0.0));
                break 'mapping;
            }
        }
    }
    let (swapped, inverted) = choice?;
    let clock = Clock {
        midpoint: a.frames() / 2,
        delay: 0.0,
        delta: 0.0,
        scatter: 0.0,
    };
    let varying = informative(a, 0, a.frames(), a_scale);
    let mut model = Model {
        clock,
        start: 0,
        end: a.frames(),
        swapped,
        inverted,
        polarity_known: false,
        speed_known: varying && a.frames() >= (a.format.sample_rate / 5) as usize,
        exact: true,
        sampler: None,
    };
    // Establish stereo distinguishability independently of the first exact map.
    let (mapping, known, _) = mapping(pair, &model, a_scale, scale(b.samples));
    model.polarity_known = known && mapping == (swapped, inverted);
    Some(model)
}

fn block_mean(a: Recording<'_>, start: usize, stride: usize, c: usize, scale: f64) -> f64 {
    (start..start + stride)
        .map(|i| a.sample(i, c) / scale)
        .sum::<f64>()
        / stride as f64
}

#[derive(Clone, Copy)]
struct Candidate {
    anchor: Anchor,
    score: f64,
}

// Retain competing coarse peaks rather than committing to a local maximum.
// A duration-derived stretch is a search hint, not the measured speed.
fn coarse(
    pair: Pair<'_>,
    center: usize,
    predicted: f64,
    stride: usize,
    a_scale: f64,
    b_scale: f64,
    stretch: f64,
) -> Option<Vec<Candidate>> {
    let a = pair.reference;
    let b = pair.recording;
    let rate = a.format.sample_rate as usize;
    let half_blocks = (rate / 20 / stride).max(8);
    let count = 2 * half_blocks;
    let start = center.checked_sub(half_blocks * stride)?;
    if start + count * stride > a.frames() {
        return None;
    }
    let mut reference = Vec::new();
    let mut reference_channel = 0;
    let mut best_variance = 0.0;
    for c in 0..a.format.channels {
        let mut v = Vec::with_capacity(count);
        for k in 0..count {
            let mut sum = 0.0;
            for j in 0..stride {
                let i = start + k * stride + j;
                let relative = i as f64 - center as f64;
                let lag = -relative * stretch / (1.0 + stretch);
                sum += linear(a, i, c, lag)? / a_scale;
            }
            v.push(sum / stride as f64);
        }
        let var = variance(&v);
        if var > best_variance {
            best_variance = var;
            reference = v;
            reference_channel = c;
        }
    }
    if best_variance < 1e-16 {
        return None;
    }
    let mean = reference.iter().sum::<f64>() / count as f64;
    for x in &mut reference {
        *x -= mean;
    }
    let nominal = start as f64 + predicted;
    let radius = 2 * rate;
    let search_start = (nominal.floor() as i64 - radius as i64).max(0) as usize;
    let search_end = (nominal.ceil() as i64 + radius as i64).max(0) as usize;
    let last = search_end.min(b.frames().checked_sub(count * stride)?);
    if last < search_start {
        return None;
    }
    let mut candidates = Vec::new();
    // Two coarse grid phases reduce sub-block delay quantization without
    // searching every native sample across a four-second interval.
    for phase in [0, stride / 2] {
        if phase == 0 && !candidates.is_empty() {
            continue;
        }
        let search_start = search_start + phase;
        if last < search_start {
            continue;
        }
        let shifts = (last - search_start) / stride + 1;
        let mut scores = vec![(0.0_f64, reference_channel); shifts];
        let channels = if a.format.channels == 2 {
            vec![0, 1]
        } else {
            vec![reference_channel]
        };
        for c in channels {
            let data: Vec<f64> = (0..shifts + count - 1)
                .map(|k| block_mean(b, search_start + k * stride, stride, c, b_scale))
                .collect();
            let mut sums = Vec::with_capacity(data.len() + 1);
            let mut squares = Vec::with_capacity(data.len() + 1);
            sums.push(0.0);
            squares.push(0.0);
            for &x in &data {
                sums.push(sums[sums.len() - 1] + x);
                squares.push(squares[squares.len() - 1] + x * x);
            }
            for (k, score) in scores.iter_mut().enumerate() {
                let s = sums[k + count] - sums[k];
                let e = squares[k + count] - squares[k];
                let mut var = e - s * s / count as f64;
                if var <= 1e-8 * e.abs() {
                    var = variance(&data[k..k + count]);
                }
                if var <= 1e-16 {
                    continue;
                }
                let dot: f64 = reference
                    .iter()
                    .zip(&data[k..k + count])
                    .map(|(x, y)| x * y)
                    .sum();
                let corr = (dot.abs() / (best_variance * var).sqrt()).min(1.0);
                if corr > score.0 {
                    *score = (corr, c);
                }
            }
        }
        for _ in 0..COARSE_CANDIDATES {
            let (k, &(score, c)) = scores
                .iter()
                .enumerate()
                .max_by(|a, b| a.1 .0.total_cmp(&b.1 .0))?;
            if score < MIN_CORRELATION {
                break;
            }
            candidates.push(Candidate {
                anchor: Anchor {
                    center,
                    lag: (search_start + k * stride) as f64 - start as f64,
                    reference_channel,
                    recording_channel: c,
                },
                score,
            });
            let end = (k + 4).min(scores.len());
            for score in &mut scores[k.saturating_sub(3)..end] {
                score.0 = 0.0;
            }
        }
    }
    Some(candidates)
}

fn coarse_group(
    pair: Pair<'_>,
    center: usize,
    ratio: f64,
    stride: usize,
    a_scale: f64,
    b_scale: f64,
) -> Vec<Candidate> {
    let predicted = (ratio - 1.0) * center as f64;
    let stretch = (ratio - 1.0).clamp(-MAX_STRETCH, MAX_STRETCH);
    let mut candidates =
        coarse(pair, center, predicted, stride, a_scale, b_scale, stretch).unwrap_or_default();
    if stretch.abs() > 0.0005 {
        // Trim/padding can make the duration-derived clock wrong. Retain
        // unwarped search evidence too, rather than treating duration as speed.
        candidates.extend(
            coarse(pair, center, predicted, stride, a_scale, b_scale, 0.0).unwrap_or_default(),
        );
    }
    candidates.sort_by(|a, b| b.score.total_cmp(&a.score));
    let mut selected: Vec<Candidate> = Vec::with_capacity(COARSE_CANDIDATES);
    for candidate in candidates {
        if selected
            .iter()
            .all(|a| (a.anchor.lag - candidate.anchor.lag).abs() > 3.0 * stride as f64)
        {
            selected.push(candidate);
        }
        if selected.len() == COARSE_CANDIDATES {
            break;
        }
    }
    selected
}

// Enumerate clocks through separated coarse peaks, then score support from
// the other independent anchors. At most 7 groups of 12 candidates: bounded
// work and storage. Repeated-period alternatives with comparable evidence
// are rejected globally, not mistaken for an unambiguous speed change.
fn consensus(
    groups: &[Vec<Candidate>],
    midpoint: usize,
    rate: usize,
    stride: usize,
) -> Result<Vec<Anchor>, &'static str> {
    let groups: Vec<_> = groups.iter().filter(|g| !g.is_empty()).collect();
    if groups.len() < 3 {
        return Err("fewer than three informative coarse timing anchors");
    }
    let tolerance = (4.0 * stride as f64).max(0.004 * rate as f64);
    let mut best: Option<(usize, f64, Clock, Vec<Anchor>)> = None;
    let mut alternatives = Vec::new();
    for (i, group) in groups.iter().enumerate() {
        for other in &groups[i + 1..] {
            for a in group.iter() {
                for b in other.iter() {
                    let delta =
                        (b.anchor.lag - a.anchor.lag) / (b.anchor.center - a.anchor.center) as f64;
                    if delta.abs() > MAX_STRETCH {
                        continue;
                    }
                    let clock = Clock {
                        midpoint,
                        delta,
                        delay: a.anchor.lag - delta * (a.anchor.center as f64 - midpoint as f64),
                        scatter: 0.0,
                    };
                    let mut selected = Vec::with_capacity(7);
                    let mut quality = 0.0;
                    for g in &groups {
                        let target = clock.lag(g[0].anchor.center);
                        let candidate = g
                            .iter()
                            .filter_map(|c| {
                                let distance = (c.anchor.lag - target).abs();
                                (distance <= tolerance).then(|| {
                                    (c.score - 0.03 * (distance / tolerance).powi(2), c.anchor)
                                })
                            })
                            .max_by(|a, b| a.0.total_cmp(&b.0));
                        if let Some((score, anchor)) = candidate {
                            quality += score;
                            selected.push(anchor);
                        }
                    }
                    let count = selected.len();
                    if count < 3 {
                        continue;
                    }
                    alternatives.push((count, quality, clock));
                    if best
                        .as_ref()
                        .is_none_or(|(n, q, _, _)| count > *n || (count == *n && quality > *q))
                    {
                        best = Some((count, quality, clock, selected));
                    }
                }
            }
        }
    }
    let (count, quality, clock, selected) =
        best.ok_or("coarse timing anchors have no common clock")?;
    let first = groups[0][0].anchor.center;
    let last = groups[groups.len() - 1][0].anchor.center;
    if alternatives.iter().any(|&(n, q, c)| {
        n == count
            && q >= quality - 0.01 * count as f64
            && (c.lag(first) - clock.lag(first))
                .abs()
                .max((c.lag(last) - clock.lag(last)).abs())
                > 2.0 * tolerance
    }) {
        return Err("competing timing alignments have comparable evidence");
    }
    Ok(selected)
}

fn median(v: &mut [f64]) -> f64 {
    v.sort_by(f64::total_cmp);
    (v[(v.len() - 1) / 2] + v[v.len() / 2]) * 0.5
}

// A Theil-Sen seed limits the influence of a single incorrect coarse peak.
fn robust_seed(anchors: &[Anchor], midpoint: usize) -> Clock {
    let mut slopes = Vec::new();
    for (j, a) in anchors.iter().enumerate() {
        for b in &anchors[j + 1..] {
            slopes.push((b.lag - a.lag) / (b.center - a.center) as f64);
        }
    }
    let delta = median(&mut slopes);
    let mut offsets: Vec<f64> = anchors
        .iter()
        .map(|a| a.lag - delta * (a.center as f64 - midpoint as f64))
        .collect();
    Clock {
        midpoint,
        delay: median(&mut offsets),
        delta,
        scatter: 0.0,
    }
}

fn fit(anchors: &[Anchor], midpoint: usize) -> Clock {
    let n = anchors.len() as f64;
    let mx = anchors
        .iter()
        .map(|a| a.center as f64 - midpoint as f64)
        .sum::<f64>()
        / n;
    let my = anchors.iter().map(|a| a.lag).sum::<f64>() / n;
    let mut xy = 0.0;
    let mut xx = 0.0;
    for a in anchors {
        let x = a.center as f64 - midpoint as f64 - mx;
        xy += x * (a.lag - my);
        xx += x * x;
    }
    let delta = xy / xx;
    let delay = my - delta * mx;
    let mut clock = Clock {
        midpoint,
        delay,
        delta,
        scatter: 0.0,
    };
    let max_error = anchors
        .iter()
        .map(|a| (a.lag - clock.lag(a.center)).abs())
        .fold(0.0, f64::max);
    let span = (anchors[anchors.len() - 1].center - anchors[0].center) as f64;
    // A 1e-6 frame numerical observation allowance is not a confidence interval.
    clock.scatter = 200.0 * (max_error + 1e-6) / span / (1.0 + delta).powi(2);
    clock
}

struct Local<'a> {
    pair: Pair<'a>,
    anchor: Anchor,
    delta: f64,
    a_scale: f64,
    b_scale: f64,
    half: usize,
    step: usize,
}
impl Local<'_> {
    // Normalized least-squares error. Near a perfect match, evaluate the
    // residual directly; subtracting squared correlation from one loses the
    // very information required to estimate a tiny sub-sample delay.
    fn loss(&self, lag: f64, sampler: Option<&Interpolator>) -> f64 {
        self.loss_impl(lag, sampler, false)
    }
    fn direct_loss(&self, lag: f64, sampler: Option<&Interpolator>) -> f64 {
        self.loss_impl(lag, sampler, true)
    }
    fn loss_impl(&self, lag: f64, sampler: Option<&Interpolator>, direct: bool) -> f64 {
        let a = self.pair.reference;
        let b = self.pair.recording;
        let center = self.anchor.center;
        let start = center.saturating_sub(self.half);
        let end = center.saturating_add(self.half).min(a.frames());
        let at = |i: usize| {
            let delay = self.delta.mul_add(i as f64 - center as f64, lag);
            match sampler {
                Some(s) => s.at(b, i, self.anchor.recording_channel, delay),
                None => linear(b, i, self.anchor.recording_channel, delay),
            }
            .map(|x| x / self.b_scale)
        };
        let mut aa = 0.0;
        let mut bb = 0.0;
        let mut ab = 0.0;
        for i in (start..end).step_by(self.step) {
            let x = a.sample(i, self.anchor.reference_channel) / self.a_scale;
            let Some(y) = at(i) else {
                return f64::INFINITY;
            };
            aa += x * x;
            bb += y * y;
            ab += x * y;
        }
        if aa <= 1e-16 || bb <= 1e-16 {
            return f64::INFINITY;
        }
        let g = ab / bb;
        if !direct {
            let loss = 1.0 - ab * g / aa;
            if loss > 1e-7 {
                return loss;
            }
        }
        let mut error = 0.0;
        for i in (start..end).step_by(self.step) {
            let x = a.sample(i, self.anchor.reference_channel) / self.a_scale;
            let Some(y) = at(i) else {
                return f64::INFINITY;
            };
            let r = (-g).mul_add(y, x);
            error += r * r;
        }
        error / aa
    }
    fn refine(
        &self,
        radius: usize,
        grid: usize,
        sampler: &Interpolator,
        ambiguity: bool,
    ) -> Option<Anchor> {
        let center = self.anchor.lag.round() as i64;
        let radius = radius as i64;
        let grid = grid.max(1);
        let mut scores = Vec::new();
        for j in (-radius..=radius).step_by(grid) {
            let lag = (center + j) as f64;
            scores.push((self.loss(lag, None), lag));
        }
        let &(coarse, best) = scores.iter().min_by(|a, b| a.0.total_cmp(&b.0))?;
        if !coarse.is_finite() || coarse > 0.8 {
            return None;
        }
        if ambiguity
            && scores.iter().any(|&(loss, lag)| {
                (lag - best).abs() > 3.0 * grid as f64 && loss <= coarse + 0.005
            })
        {
            return None;
        }
        let mut best = (f64::INFINITY, best);
        // Refine an integer candidate first, retaining the exact grid point as
        // a competitor. Do not force a fractional delay onto a deep null.
        let seed = scores.iter().min_by(|a, b| a.0.total_cmp(&b.0))?.1.round() as i64;
        for j in seed - grid as i64..=seed + grid as i64 {
            let lag = j as f64;
            let loss = self.loss(lag, None);
            if loss < best.0 {
                best = (loss, lag);
            }
        }
        let integer = best.1;
        let integer_loss = self.loss(integer, Some(sampler));
        if self.delta == 0.0 && integer_loss <= 1e-29 {
            return Some(Anchor {
                lag: integer,
                ..self.anchor
            });
        }
        let mut lo = integer - 1.0;
        let mut hi = integer + 1.0;
        // Golden-section search reuses one objective evaluation per step.
        // Refine global clocks to sub-microframe resolution. The initial
        // drift branch search uses fewer iterations; the subsequent short
        // windows use the local affine Jacobian.
        let ratio = 0.618_033_988_749_894_9;
        let mut left = hi - ratio * (hi - lo);
        let mut right = lo + ratio * (hi - lo);
        let mut left_loss = self.loss(left, Some(sampler));
        let mut right_loss = self.loss(right, Some(sampler));
        let iterations = if ambiguity { 24 } else { 40 };
        for _ in 0..iterations {
            if left_loss < right_loss {
                hi = right;
                right = left;
                right_loss = left_loss;
                left = hi - ratio * (hi - lo);
                left_loss = self.loss(left, Some(sampler));
            } else {
                lo = left;
                left = right;
                left_loss = right_loss;
                right = lo + ratio * (hi - lo);
                right_loss = self.loss(right, Some(sampler));
            }
        }
        let candidate = (lo + hi) * 0.5;
        let candidate_loss = self.loss(candidate, Some(sampler));
        let (loss, lag) = if integer_loss <= candidate_loss * (1.0 + 1e-7) + 1e-29 {
            (integer_loss, integer)
        } else {
            (candidate_loss, candidate)
        };
        if !loss.is_finite() || loss > 1.0 - MIN_CORRELATION * MIN_CORRELATION {
            return None;
        }
        Some(Anchor { lag, ..self.anchor })
    }
}

// Local phase observability and drift share a small sample-domain fit. The
// existing long-window affine estimator remains the candidate generator.
// Timing is inferred from waveform motion after eliminating scalar gain;
// a first-difference projection supplies a second, upper-frequency-weighted
// observation of the same clock. Neither is a confidence interval.
const TIMING_FRAME_FLOOR: f64 = 1e-6;
const PHASE_FRACTION: f64 = 0.10;
const DRIFT_PHASE_FRACTION: f64 = 0.20;

#[derive(Clone, Copy)]
struct TimingPoint {
    x: f64,
    y: f64,
    v: f64,
    u: f64,
}
#[derive(Clone, Copy)]
struct TimingFit {
    lag: f64,
    delta: f64,
    phase_error: f64,
}

fn timing_half(rate: usize) -> usize {
    (rate / 500).max(8)
}
fn timing_step(rate: usize) -> usize {
    (rate / 16000).max(1)
}

impl Local<'_> {
    fn timing_points(
        &self,
        lag: f64,
        delta: f64,
        sampler: &Interpolator,
        points: &mut Vec<TimingPoint>,
    ) -> Option<()> {
        points.clear();
        let center = self.anchor.center;
        let start = center.checked_sub(self.half)?;
        let end = center.checked_add(self.half)?;
        if end > self.pair.reference.frames() {
            return None;
        }
        for i in (start..end).step_by(self.step) {
            let offset = i as f64 - center as f64;
            let delay = delta.mul_add(offset, lag);
            let (y, v) = sampler.value_and_derivative(
                self.pair.recording,
                i,
                self.anchor.recording_channel,
                delay,
            )?;
            let point = TimingPoint {
                x: self.pair.reference.sample(i, self.anchor.reference_channel) / self.a_scale,
                y: y / self.b_scale,
                v: v / self.b_scale,
                u: offset / self.half as f64,
            };
            if !point.y.is_finite() || !point.v.is_finite() {
                return None;
            }
            points.push(point);
        }
        (points.len() >= 8).then_some(())
    }

    // Simultaneously refine lag and local slope. Project both timing columns
    // away from the gain column before solving the 2x2 normal equations.
    // Centered, window-normalized coordinates avoid a poorly scaled solve.
    fn timing_fit(
        &self,
        sampler: &Interpolator,
        points: &mut Vec<TimingPoint>,
        radius: f64,
    ) -> Option<TimingFit> {
        let mut lag = self.anchor.lag;
        let mut delta = self.delta;
        for iteration in 0..=6 {
            self.timing_points(lag, delta, sampler, points)?;
            let (dl, du) = timing_update(points)?;
            if dl.abs().max(du.abs()) <= 1e-7 || iteration == 6 {
                // Do not report a fit that has not settled onto a local branch.
                if dl.abs().max(du.abs()) > 1e-4 {
                    return None;
                }
                return Some(TimingFit {
                    lag,
                    delta,
                    phase_error: phase_error(points)?,
                });
            }
            lag += dl;
            delta += du / self.half as f64;
            if !lag.is_finite()
                || !delta.is_finite()
                || delta.abs() > MAX_STRETCH
                || (lag - self.anchor.lag).abs() > radius
            {
                return None;
            }
        }
        None
    }
}

fn timing_update(points: &[TimingPoint]) -> Option<(f64, f64)> {
    let (mut aa, mut bb, mut ab, mut yv, mut yvu) = (0.0, 0.0, 0.0, 0.0, 0.0);
    for &TimingPoint { x, y, v, u } in points {
        aa += x * x;
        bb += y * y;
        ab += x * y;
        yv += y * v;
        yvu += y * v * u;
    }
    if aa <= 1e-16 || bb <= 1e-16 {
        return None;
    }
    let g = ab / bb;
    let (mut pp, mut qq, mut pq, mut pr, mut qr) = (0.0, 0.0, 0.0, 0.0, 0.0);
    for &TimingPoint { x, y, v, u } in points {
        let p = g * (v - y * yv / bb);
        let q = g * (v * u - y * yvu / bb);
        let r = (-g).mul_add(y, x);
        pp += p * p;
        qq += q * q;
        pq += p * q;
        pr += p * r;
        qr += q * r;
    }
    let det = pp * qq - pq * pq;
    // A short window must contain timing information distributed across
    // its support, not just a transient at one edge or a gain-like derivative.
    if pp <= aa * 1e-12 || qq <= pp * 0.01 || det <= 0.01 * pp * qq {
        return None;
    }
    let dl = (pr * qq - qr * pq) / det;
    let du = (qr * pp - pr * pq) / det;
    (dl.is_finite() && du.is_finite()).then_some((dl, du))
}

// Express waveform discrepancy in frames of timing motion rather than
// correlation or anchor-line scatter. A first difference changes the
// spectral weighting, and each projection has its own nuisance gain. The
// residual norm divided by the gain-orthogonal derivative norm bounds the
// magnitude of a linearized lag correction in that projection (Cauchy-
// Schwarz). It is a conservative mismatch scale, not a bound on every
// possible mastering filter or on the true physical clock error.
fn phase_error(points: &[TimingPoint]) -> Option<f64> {
    let projection = |difference: bool| -> Option<f64> {
        let sample = |i: usize| {
            let p = points[i];
            if difference {
                let q = points[i - 1];
                (p.x - q.x, p.y - q.y, p.v - q.v)
            } else {
                (p.x, p.y, p.v)
            }
        };
        let start = usize::from(difference);
        let (mut aa, mut bb, mut ab, mut yv) = (0.0, 0.0, 0.0, 0.0);
        for i in start..points.len() {
            let (x, y, v) = sample(i);
            aa += x * x;
            bb += y * y;
            ab += x * y;
            yv += y * v;
        }
        if aa <= 1e-16 || bb <= 1e-16 {
            return None;
        }
        let g = ab / bb;
        let (mut rr, mut vv) = (0.0, 0.0);
        for i in start..points.len() {
            let (x, y, v) = sample(i);
            let r = (-g).mul_add(y, x);
            let v = g * (v - y * yv / bb);
            rr += r * r;
            vv += v * v;
        }
        if vv <= aa * 1e-12 {
            return None;
        }
        let error = (rr / vv).sqrt();
        error.is_finite().then_some(error)
    };
    Some(projection(false)?.max(projection(true)?))
}

// Fixed-phase EQ on changing content can produce a highly linear sequence
// of apparent delays. Do not treat that line as a qualified clock unless
// the waveform motion dominates mismatch in both projections. Clean affine
// clocks, including genuinely tiny slopes, need only this bounded pass.
// For non-affine playback, require separately supported short-time motion
// on both sides of the candidate slope, rather than accepting a fit to EQ.
fn validated_clock(
    pair: Pair<'_>,
    clock: Clock,
    anchors: &[Anchor],
    sampler: &Interpolator,
    a_scale: f64,
    b_scale: f64,
) -> Option<Clock> {
    let rate = pair.reference.format.sample_rate as usize;
    let span = (anchors[anchors.len() - 1].center - anchors[0].center) as f64;
    let allowance = TIMING_FRAME_FLOOR.max(PHASE_FRACTION * span * clock.delta.abs());
    let mut points = Vec::new();
    let affine = anchors.iter().all(|&anchor| {
        let local = Local {
            pair,
            anchor,
            delta: clock.delta,
            a_scale,
            b_scale,
            half: (rate / 100).max(16),
            step: timing_step(rate),
        };
        local
            .timing_points(clock.lag(anchor.center), clock.delta, sampler, &mut points)
            .is_some()
            && phase_error(&points).is_some_and(|error| error <= allowance)
    });
    if affine {
        return Some(clock);
    }

    // Sample offset neighborhoods at the already-established separated
    // anchors. Offsets are deliberately not a uniform grid that aliases
    // 20 or 40 Hz flutter. This is bounded validation, not a drift scan.
    let half = timing_half(rate);
    let mut minimum = f64::INFINITY;
    let mut maximum = f64::NEG_INFINITY;
    let mut error = 0.0_f64;
    let mut groups = 0;
    let mut observations = Vec::with_capacity(5 * anchors.len());
    for &anchor in anchors {
        let mut count = 0;
        for milliseconds in [-37_i64, -13, 0, 17, 31] {
            let offset = milliseconds * rate as i64 / 1000;
            let Some(center) = anchor.center.checked_add_signed(offset as isize) else {
                continue;
            };
            let local = Local {
                pair,
                anchor: Anchor {
                    center,
                    lag: clock.delta.mul_add(offset as f64, anchor.lag),
                    ..anchor
                },
                delta: clock.delta,
                a_scale,
                b_scale,
                half,
                step: timing_step(rate),
            };
            let observation =
                local.timing_fit(sampler, &mut points, (rate as f64 / 4000.0).max(2.0))?;
            if (observation.lag - clock.lag(center)).abs() > rate as f64 * 0.003 {
                return None;
            }
            observations.push(Anchor {
                center,
                lag: observation.lag,
                ..anchor
            });
            minimum = minimum.min(observation.delta);
            maximum = maximum.max(observation.delta);
            error = error.max(observation.phase_error);
            count += 1;
        }
        if count >= 3 {
            groups += 1;
        }
    }
    let excursion = half as f64 * (maximum - minimum);
    let ambiguity = error.max(TIMING_FRAME_FLOOR) / half as f64;
    if groups < 3
        || minimum >= clock.delta - ambiguity
        || maximum <= clock.delta + ambiguity
        || error > PHASE_FRACTION * excursion
        || excursion <= TIMING_FRAME_FLOOR
    {
        return None;
    }
    // The long-window anchors can alias modulation. Use all the independently
    // observed local lags for the finite-record affine trend and its scatter,
    // rather than reporting the aliased anchor line as a precise fixed speed.
    observations.sort_by_key(|a| a.center);
    let trend = fit(&observations, clock.midpoint);
    if !trend.delta.is_finite()
        || trend.delta.abs() > MAX_STRETCH
        || minimum >= trend.delta - ambiguity
        || maximum <= trend.delta + ambiguity
        || observations
            .iter()
            .any(|a| (a.lag - trend.lag(a.center)).abs() > rate as f64 * 0.003)
    {
        return None;
    }
    Some(trend)
}

// A failed physical-clock observation need not invalidate a sample grid.
// Admit only a close, separated integer hypothesis whose directly measured
// cancellation is practically as good as the fractional candidates. This
// is an alignment test, not a speed deadband or a claim of zero motion.
const INTEGER_GRID_RADIUS: f64 = 0.01;
const INTEGER_GRID_RELATIVE_LOSS: f64 = 1.05;
const INTEGER_GRID_MIN_CORRELATION: f64 = 0.99999;

fn integer_grid(
    pair: Pair<'_>,
    clock: Clock,
    anchors: &[Anchor],
    sampler: &Interpolator,
    a_scale: f64,
    b_scale: f64,
) -> Option<Clock> {
    let integer = clock.delay.round();
    let last = pair.reference.frames() - 1;
    // The affine candidate and every independent refined lag must agree
    // on one integer, including the extrapolation to the record endpoints.
    if [0, last]
        .iter()
        .any(|&i| (clock.lag(i) - integer).abs() > INTEGER_GRID_RADIUS)
        || anchors
            .iter()
            .any(|a| (a.lag - integer).abs() > INTEGER_GRID_RADIUS)
    {
        return None;
    }
    let rate = pair.reference.format.sample_rate as usize;
    for &anchor in anchors {
        let local = Local {
            pair,
            anchor,
            delta: 0.0,
            a_scale,
            b_scale,
            half: (rate / 100).max(16),
            step: (rate / 48000).max(1),
        };
        let loss = local.direct_loss(integer, None);
        // Residual magnitude is the measurement, not a local admission limit.
        if !loss.is_finite() {
            return None;
        }
        // Test the adjacent grid points as well: a nearly constant or
        // locally ambiguous waveform cannot establish a unique grid lag.
        for neighbor in [integer - 1.0, integer + 1.0] {
            let alternative = local.direct_loss(neighbor, None);
            if !alternative.is_finite() || alternative <= 4.0 * loss.max(1e-29) {
                return None;
            }
        }
        let fractional = Local {
            delta: clock.delta,
            ..local
        };
        let affine_loss = fractional.direct_loss(clock.lag(anchor.center), Some(sampler));
        let refined_loss = fractional.direct_loss(anchor.lag, Some(sampler));
        if !affine_loss.is_finite()
            || !refined_loss.is_finite()
            || loss > INTEGER_GRID_RELATIVE_LOSS * affine_loss.min(refined_loss)
        {
            return None;
        }
    }
    Some(Clock {
        midpoint: clock.midpoint,
        delay: integer,
        delta: 0.0,
        scatter: 0.0,
    })
}

// At most 65,536 real frames, all channels, to determine a global mapping.
// An ambiguous stereo mapping is still usable for a null; the mapping itself
// is not asserted. The selected mapping is the one with greatest |correlation|.
fn mapping(pair: Pair<'_>, model: &Model, a_scale: f64, b_scale: f64) -> ((bool, bool), bool, f64) {
    let a = pair.reference;
    let b = pair.recording;
    let stride = (model.end - model.start).div_ceil(65536).max(1);
    let mut scores = [0.0_f64; 2];
    let mut consistent = [true; 2];
    let stereo = a.format.channels == 2;
    for (map, score) in scores
        .iter_mut()
        .enumerate()
        .take(if stereo { 2 } else { 1 })
    {
        let mut aa = 0.0;
        let mut bb = 0.0;
        let mut ab = 0.0;
        let mut per_channel = [[0.0_f64; 3]; 64];
        for i in (model.start..model.end).step_by(stride) {
            for (c, sums) in per_channel.iter_mut().enumerate().take(a.format.channels) {
                let x = a.sample(i, c) / a_scale;
                let bc = if map == 1 { 1 - c } else { c };
                let lag = model.clock.lag(i);
                let y = match &model.sampler {
                    Some(s) => s.at(b, i, bc, lag).expect("valid support"),
                    None => linear(b, i, bc, lag).expect("valid support"),
                } / b_scale;
                aa += x * x;
                bb += y * y;
                ab += x * y;
                sums[0] += x * x;
                sums[1] += y * y;
                sums[2] += x * y;
            }
        }
        if aa > 0.0 && bb > 0.0 {
            *score = (ab / (aa * bb).sqrt()).clamp(-1.0, 1.0);
        }
        // Do not let a dominant channel conceal inversion or a missing
        // signal on the other channel. Ignore only jointly negligible energy.
        for &[x, y, dot] in &per_channel[..a.format.channels] {
            if x <= aa * 1e-12 && y <= bb * 1e-12 {
                continue;
            }
            if x == 0.0
                || y == 0.0
                || dot.abs() < 0.75 * (x * y).sqrt()
                || dot.is_sign_negative() != score.is_sign_negative()
            {
                consistent[map] = false;
            }
        }
    }
    let swapped = stereo && scores[1].abs() > scores[0].abs();
    let selected = scores[usize::from(swapped)];
    let known = a.format.channels <= 2
        && selected.abs() >= 0.75
        && consistent[usize::from(swapped)]
        && (!stereo || (scores[0].abs() - scores[1].abs()).abs() > 0.02);
    ((swapped, selected < 0.0), known, selected.abs())
}

fn valid_support(pair: Pair<'_>, clock: Clock, fractional: bool) -> Option<(usize, usize)> {
    let a = pair.reference;
    let b = pair.recording;
    let margin = if fractional { HALF } else { 0 };
    let first_valid = |i: usize| position(i, clock.lag(i)).is_some_and(|(j, _)| j >= margin);
    let last_valid = |i: usize| {
        position(i, clock.lag(i)).is_none_or(|(j, _)| j < b.frames().saturating_sub(margin))
    };
    // Monotone time map; binary search avoids scanning a long unpaired prefix.
    let lower_bound = |pred: &dyn Fn(usize) -> bool| {
        let mut lo = 0;
        let mut hi = a.frames();
        while lo < hi {
            let mid = lo + (hi - lo) / 2;
            if pred(mid) {
                hi = mid;
            } else {
                lo = mid + 1;
            }
        }
        lo
    };
    let start = lower_bound(&first_valid);
    let end = lower_bound(&|i| !last_valid(i));
    if end <= start {
        return None;
    }
    let support = (end - start) as f64;
    if support < 0.8 * a.frames() as f64 || support * (1.0 + clock.delta) < 0.8 * b.frames() as f64
    {
        return None;
    }
    Some((start, end))
}

fn strongest_channel(a: Recording<'_>, center: usize, half: usize, conditioning: f64) -> usize {
    let step = (a.format.sample_rate as usize / 2000).max(1);
    let start = center.saturating_sub(half);
    let end = (center + half).min(a.frames());
    let mut best = 0;
    let mut best_var = -1.0;
    for c in 0..a.format.channels {
        let mut n = 0.0;
        let mut mean = 0.0;
        let mut variance = 0.0;
        for i in (start..end).step_by(step) {
            let x = a.sample(i, c) / conditioning;
            n += 1.0;
            let delta = x - mean;
            mean += delta / n;
            variance += delta * (x - mean);
        }
        if variance > best_var {
            best_var = variance;
            best = c;
        }
    }
    best
}

pub(super) fn estimate(pair: Pair<'_>) -> Result<Model, &'static str> {
    let a = pair.reference;
    let b = pair.recording;
    if a.format.channels != b.format.channels {
        return Err("channel counts differ; no sample-domain alignment");
    }
    let a_scale = scale(a.samples);
    let b_scale = scale(b.samples);
    if let Some(model) = exact_model(pair, a_scale) {
        return Ok(model);
    }
    let rate = a.format.sample_rate as usize;
    if a.frames().min(b.frames()) < rate / 2 {
        return Err("less than half a second of nonidentical material");
    }
    let ratio = b.frames() as f64 / a.frames() as f64;
    if !(0.8..=1.25).contains(&ratio) {
        return Err("paired durations differ beyond alignment search limits");
    }
    let stride = (rate / 2000).max(1);
    let midpoint = a.frames() / 2;
    let mut anchors = Vec::new();
    let mut near_zero = false;
    if a.frames() == b.frames() && informative(a, 0, a.frames(), a_scale) {
        let zero = Model {
            clock: Clock {
                midpoint,
                delay: 0.0,
                delta: 0.0,
                scatter: 0.0,
            },
            start: 0,
            end: a.frames(),
            swapped: false,
            inverted: false,
            polarity_known: false,
            speed_known: true,
            exact: false,
            sampler: None,
        };
        let (map, _, corr) = mapping(pair, &zero, a_scale, b_scale);
        if corr > 0.99999 {
            // A close zero-lag hypothesis is useful even for narrowband
            // material whose wide search would contain repeated periods.
            // Refine seven independent local anchors; never infer a speed
            // from equal duration alone.
            near_zero = true;
            for k in 1..=7 {
                let center = a.frames() / 8 * k;
                let half = (rate / 100).max(16);
                let c = strongest_channel(a, center, half, a_scale);
                anchors.push(Anchor {
                    center,
                    lag: 0.0,
                    reference_channel: c,
                    recording_channel: if map.0 { 1 - c } else { c },
                });
            }
        }
    }
    if !near_zero {
        let groups: Vec<_> = (1..=7)
            .map(|k| coarse_group(pair, a.frames() / 8 * k, ratio, stride, a_scale, b_scale))
            .collect();
        anchors = consensus(&groups, midpoint, rate, stride)?;
    }
    if anchors.len() < 3 {
        return Err("fewer than three unambiguous timing anchors");
    }
    let seed = robust_seed(&anchors, midpoint);
    if seed.delta.abs() > MAX_STRETCH {
        return Err("relative speed exceeds alignment search limits");
    }
    anchors.retain(|a| {
        (a.lag - seed.lag(a.center)).abs() <= (rate as f64 * 0.015).max(4.0 * stride as f64)
    });
    if anchors.len() < 3 {
        return Err("coarse timing anchors do not agree");
    }
    let sampler = Interpolator::new();
    let mut refined = Vec::new();
    for anchor in anchors {
        let local = Local {
            pair,
            anchor,
            delta: seed.delta,
            a_scale,
            b_scale,
            half: (rate / 100).max(16),
            step: (rate / 48000).max(1),
        };
        let (radius, grid) = if near_zero {
            (2, 1)
        } else {
            (2 * stride + 2, (rate / 48000).max(1))
        };
        if let Some(a) = local.refine(radius, grid, &sampler, false) {
            refined.push(a);
        }
    }
    if refined.len() < 3 || refined[refined.len() - 1].center - refined[0].center < a.frames() / 3 {
        return Err("insufficient separated, reliable native timing anchors");
    }
    let initial = fit(&refined, midpoint);
    // Re-evaluate the local waveform with the native slope instead of the
    // coarsely quantized clock. Preserve exact integer anchors when valid.
    if (initial.delta - seed.delta).abs() * rate as f64 / 100.0 > 1e-5 {
        let mut second = Vec::new();
        for anchor in refined.iter().copied() {
            let local = Local {
                pair,
                anchor,
                delta: initial.delta,
                a_scale,
                b_scale,
                half: (rate / 100).max(16),
                step: (rate / 48000).max(1),
            };
            if let Some(a) = local.refine(2, 1, &sampler, false) {
                second.push(a);
            }
        }
        if second.len() >= 3 && second[second.len() - 1].center - second[0].center >= a.frames() / 3
        {
            refined = second;
        }
    }
    let mut clock = fit(&refined, midpoint);
    // A native integer-aligned match must not be degraded by a slope seed
    // quantized on the coarse grid. Compare the rounded, zero-stretch model
    // directly with the fractional fit on every retained anchor. This is
    // a residual test, not a blanket rounding rule for small speed changes.
    let integer = clock.delay.round();
    if refined
        .iter()
        .all(|a| (clock.lag(a.center) - integer).abs() < 0.5)
    {
        let no_worse = refined.iter().all(|&anchor| {
            let local = Local {
                pair,
                anchor,
                delta: 0.0,
                a_scale,
                b_scale,
                half: (rate / 100).max(16),
                step: (rate / 48000).max(1),
            };
            let integer_loss = local.loss(integer, None);
            let fractional = Local {
                delta: clock.delta,
                ..local
            };
            let fractional_loss = fractional.loss(clock.lag(anchor.center), Some(&sampler));
            integer_loss.is_finite() && integer_loss <= fractional_loss * (1.0 + 1e-7) + 1e-29
        });
        if no_worse {
            clock.delta = 0.0;
            clock.delay = integer;
        }
    }
    if !clock.delta.is_finite() || clock.delta.abs() > MAX_STRETCH {
        return Err("native clock fit exceeds speed limits");
    }
    if refined
        .iter()
        .any(|a| (a.lag - clock.lag(a.center)).abs() > 0.003 * rate as f64)
    {
        return Err("timing anchors disagree with one affine clock");
    }
    let (clock, speed_known) =
        match validated_clock(pair, clock, &refined, &sampler, a_scale, b_scale) {
            Some(validated) => (validated, true),
            None => (
                integer_grid(pair, clock, &refined, &sampler, a_scale, b_scale).ok_or(
                    "clock motion is not distinguishable from waveform or filter-phase differences",
                )?,
                false,
            ),
        };
    let fractional = clock.delta != 0.0 || clock.delay.fract() != 0.0;
    let (start, end) = valid_support(pair, clock, fractional)
        .ok_or("aligned overlap covers less than 80 percent of a recording")?;
    let mut model = Model {
        clock,
        start,
        end,
        swapped: false,
        inverted: false,
        polarity_known: false,
        speed_known,
        exact: false,
        sampler: fractional.then_some(sampler),
    };
    let (map, known, correlation) = mapping(pair, &model, a_scale, b_scale);
    let minimum = if speed_known {
        MIN_CORRELATION
    } else {
        INTEGER_GRID_MIN_CORRELATION
    };
    if correlation < minimum {
        return Err("aligned recordings have insufficient common waveform evidence");
    }
    model.swapped = map.0;
    model.inverted = map.1;
    model.polarity_known = known;
    Ok(model)
}

pub(super) fn drift(pair: Pair<'_>, model: &Model) -> Result<Outcome<f64>, Error> {
    if model.exact {
        return Ok(if model.speed_known {
            Outcome::Value(0.0)
        } else {
            cant("no varying material for a drift measurement")
        });
    }
    if !model.speed_known {
        return Ok(cant(
            "clock trend is unresolved at the available waveform fidelity",
        ));
    }
    let a = pair.reference;
    let b = pair.recording;
    let rate = a.format.sample_rate as usize;
    // 4 ms local affine observations at 2 ms spacing. The slope is fitted
    // within each window, not differentiated on a slow, aliased lag grid.
    let half = timing_half(rate);
    let hop = half;
    let initial_half = (rate / 50).max(16);
    let margin = initial_half + HALF + rate / 100;
    let Some(end) = model.end.checked_sub(margin) else {
        return Ok(cant("not enough aligned material for local timing"));
    };
    let start = model.start + margin;
    if end <= start || (end - start) / hop < 4 {
        return Ok(cant("not enough aligned material for local timing"));
    }
    if (end - start) / hop > 4_000_000 {
        return Err(Error::ResourceLimit);
    }
    let fallback;
    let sampler = match &model.sampler {
        Some(s) => s,
        None => {
            fallback = Interpolator::new();
            &fallback
        }
    };
    let a_scale = scale(a.samples);
    let b_scale = scale(b.samples);
    let c = strongest_channel(a, start, initial_half, a_scale);
    let initial = Local {
        pair,
        anchor: Anchor {
            center: start,
            lag: model.clock.lag(start),
            reference_channel: c,
            recording_channel: if model.swapped { 1 - c } else { c },
        },
        delta: model.clock.delta,
        a_scale,
        b_scale,
        half: initial_half,
        step: (rate / 12000).max(1),
    };
    // One broad search establishes an unambiguous initial branch. Thereafter
    // predict from the preceding local slope; do not repeatedly search all
    // possible periodic alternatives in every 4 ms window.
    let Some(seed) = initial.refine(
        (rate * 3 / 1000).max(2),
        (rate / 4000).max(1),
        sampler,
        true,
    ) else {
        return Ok(cant("initial local timing is unobservable or ambiguous"));
    };
    let mut lag = seed.lag;
    let mut delta = model.clock.delta;
    let mut previous_lag = None;
    let mut points = Vec::new();
    let mut peak = 0.0_f64;
    let mut peak_delta = 0.0_f64;
    let mut error = 0.0_f64;
    for center in (start..end).step_by(hop) {
        // Keep the selected channel fixed over the scan. A change of
        // channel-specific phase must not be mistaken for a timing jump.
        let local = Local {
            pair,
            anchor: Anchor {
                center,
                lag,
                reference_channel: c,
                recording_channel: if model.swapped { 1 - c } else { c },
            },
            delta,
            a_scale,
            b_scale,
            half,
            step: timing_step(rate),
        };
        // Restrict the fit to the predicted local branch; a loss of lock is
        // unavailable, not an invitation to hop to a different waveform cycle.
        let radius = (rate as f64 / 50000.0).max(0.5);
        let Some(current) = local.timing_fit(sampler, &mut points, radius) else {
            return Ok(cant(
                "local timing is unobservable or the short-window fit lost lock",
            ));
        };
        if (current.lag - model.clock.lag(center)).abs() > rate as f64 * 0.0029 {
            return Ok(cant("local timing exceeds the drift search range"));
        }
        if previous_lag
            .is_some_and(|last: f64| (current.lag - last).abs() > MAX_STRETCH * hop as f64)
        {
            return Ok(cant("local timing discontinuity exceeds the speed range"));
        }
        previous_lag = Some(current.lag);
        let departure = model.clock.delta - current.delta;
        peak_delta = peak_delta.max(departure.abs());
        peak = peak.max((100.0 * departure / (1.0 + current.delta)).abs());
        error = error.max(current.phase_error);
        lag = current.delta.mul_add(hop as f64, current.lag);
        delta = current.delta;
    }
    // If waveform/phase mismatch dominates measured local motion, a small
    // peak is not evidence of a stable clock. Exact/clean constant clocks
    // remain usable at the numerical observation floor.
    if error > TIMING_FRAME_FLOOR.max(DRIFT_PHASE_FRACTION * half as f64 * peak_delta) {
        return Ok(cant(
            "waveform or phase mismatch obscures the local speed variation",
        ));
    }
    Ok(Outcome::Value(peak))
}
