// SPDX-License-Identifier: GPL-2.0-or-later
//! Shared integrated loudness and the existing complementary-window spectrum.
use super::{align, cant, Pair, Recording, TonalBalance, TonalBin, TonalNormalization};
use crate::spectrum::SpectralEngine;
use crate::{ChannelRole, Error, Outcome};
use true_peak::loudness::{
    AlbumLoudnessBuilder, LoudnessMeasurement, LoudnessMeter, LoudnessMetricDemand,
    LoudnessProfile, DEFAULT_LOUDNESS_STORAGE_LIMIT_BYTES,
};

fn loudness(recording: Recording<'_>) -> Result<Option<LoudnessMeasurement>, Error> {
    let format = recording.format;
    let roles = match &format.loudness_roles {
        Some(roles) => roles.clone(),
        None => match format.channels {
            1 => vec![ChannelRole::Mono],
            2 => vec![ChannelRole::Left, ChannelRole::Right],
            _ => return Ok(None),
        },
    };
    let mut meter = LoudnessMeter::with_roles_and_metric_demand(
        format.sample_rate,
        &roles,
        LoudnessProfile::NativeEbu2023,
        LoudnessMetricDemand::IntegratedOnly,
    )?;
    // A bounded push avoids large temporary allocations in upstream metering.
    for pcm in recording.samples.chunks(16384 * format.channels) {
        meter.push_interleaved(pcm)?;
    }
    Ok(Some(meter.finalize()?))
}

pub(super) struct LoudnessPair {
    reference: Option<LoudnessMeasurement>,
    recording: Option<LoudnessMeasurement>,
}
impl LoudnessPair {
    pub(super) fn delta(&self) -> Option<f64> {
        Some(
            self.recording.as_ref()?.summary.integrated.finite_lufs()?
                - self.reference.as_ref()?.summary.integrated.finite_lufs()?,
        )
    }
}
pub(super) fn loudness_pair(pair: Pair<'_>) -> Result<LoudnessPair, Error> {
    Ok(LoudnessPair {
        reference: loudness(pair.reference)?,
        recording: loudness(pair.recording)?,
    })
}

pub(super) struct AlbumLoudness {
    a: AlbumLoudnessBuilder,
    b: AlbumLoudnessBuilder,
    complete: bool,
}
impl AlbumLoudness {
    pub(super) fn new() -> Self {
        let builder = || {
            AlbumLoudnessBuilder::with_metric_demand(
                DEFAULT_LOUDNESS_STORAGE_LIMIT_BYTES,
                LoudnessMetricDemand::IntegratedOnly,
            )
        };
        Self {
            a: builder(),
            b: builder(),
            complete: true,
        }
    }
    pub(super) fn push(&mut self, pair: LoudnessPair) -> Result<(), Error> {
        match (pair.reference, pair.recording) {
            (Some(a), Some(b)) if self.complete => {
                // Peak is immaterial to integrated loudness and is not exposed
                // by this interface. No extra full-record peak scan is needed.
                self.a.push_track(a.statistics, 0.0)?;
                self.b.push_track(b.statistics, 0.0)?;
            }
            _ => self.complete = false,
        }
        Ok(())
    }
    pub(super) fn finish(self) -> Result<Option<f64>, Error> {
        if !self.complete {
            return Ok(None);
        }
        let a = self.a.finalize()?.integrated.finite_lufs();
        let b = self.b.finalize()?.integrated.finite_lufs();
        Ok(a.zip(b).map(|(a, b)| b - a))
    }
}

struct LogSpectrum {
    rate: u32,
    n: usize,
    frames: u64,
    bins: Vec<f64>,
}
fn log_add(a: f64, b: f64) -> f64 {
    let hi = a.max(b);
    let lo = a.min(b);
    if hi == f64::NEG_INFINITY {
        hi
    } else {
        hi + (10.0 / std::f64::consts::LN_10) * 10.0_f64.powf((lo - hi) / 10.0).ln_1p()
    }
}
impl LogSpectrum {
    fn new(recording: Recording<'_>) -> Self {
        let rate = recording.format.sample_rate;
        let channels = recording.format.channels;
        let mut engine =
            SpectralEngine::new(rate, channels, true, false, false, false, false, false);
        // Power-of-two conditioning preserves small binary64 recordings whose
        // unconditioned bin squares would underflow. No full PCM copy.
        let scale = align::scale(recording.samples);
        if scale == 1.0 {
            engine.push(recording.samples);
        } else {
            let mut block = Vec::with_capacity(4096 * channels);
            for pcm in recording.samples.chunks(4096 * channels) {
                block.clear();
                block.extend(pcm.iter().map(|x| x / scale));
                engine.push(&block);
            }
        }
        engine.flush();
        let s = engine.spectrum;
        let adjustment = 20.0 * scale.log10();
        Self {
            rate,
            n: s.n,
            frames: s.frames,
            bins: s
                .sums
                .into_iter()
                .map(|p| 10.0 * p.log10() + adjustment)
                .collect(),
        }
    }
    fn merge(&mut self, other: Self) -> Result<(), Error> {
        debug_assert_eq!((self.rate, self.n), (other.rate, other.n));
        self.frames = self
            .frames
            .checked_add(other.frames)
            .ok_or(Error::ResourceLimit)?;
        for (a, b) in self.bins.iter_mut().zip(other.bins) {
            *a = log_add(*a, b);
        }
        Ok(())
    }
    fn total(&self) -> f64 {
        self.bins.iter().copied().fold(f64::NEG_INFINITY, log_add)
            - 10.0 * (self.frames as f64).log10()
    }
}

pub(super) struct PairTonal {
    a: LogSpectrum,
    b: LogSpectrum,
}
impl PairTonal {
    pub(super) fn new(pair: Pair<'_>) -> Self {
        Self {
            a: LogSpectrum::new(pair.reference),
            b: LogSpectrum::new(pair.recording),
        }
    }
    pub(super) fn track(&self, loudness_delta: Option<f64>) -> TonalBalance {
        difference(&self.a, &self.b, loudness_delta)
    }
}
pub(super) struct AlbumTonal {
    pooled: Option<PairTonal>,
}
impl AlbumTonal {
    pub(super) fn new() -> Self {
        Self { pooled: None }
    }
    pub(super) fn push(&mut self, track: PairTonal) -> Result<(), Error> {
        if let Some(p) = &mut self.pooled {
            p.a.merge(track.a)?;
            p.b.merge(track.b)?;
        } else {
            self.pooled = Some(track);
        }
        Ok(())
    }
    pub(super) fn finish(self, loudness_delta: Option<f64>) -> TonalBalance {
        self.pooled.expect("nonempty album").track(loudness_delta)
    }
}

fn difference(a: &LogSpectrum, b: &LogSpectrum, loudness_delta: Option<f64>) -> TonalBalance {
    debug_assert_eq!((a.rate, a.n), (b.rate, b.n));
    let total_a = a.total();
    let total_b = b.total();
    let (normalization, gain) = if let Some(delta) = loudness_delta {
        (TonalNormalization::IntegratedLoudness, Some(-delta))
    } else if total_a.is_finite() && total_b.is_finite() {
        (TonalNormalization::BroadbandRms, Some(total_a - total_b))
    } else {
        (TonalNormalization::Unavailable, None)
    };
    let a_duration_db = 10.0 * (a.frames as f64).log10();
    let b_duration_db = 10.0 * (b.frames as f64).log10();
    let a_peak = a.bins.iter().copied().fold(f64::NEG_INFINITY, f64::max) - a_duration_db;
    let b_peak = b.bins.iter().copied().fold(f64::NEG_INFINITY, f64::max) - b_duration_db;
    let mut largest: Option<(f64, usize)> = None;
    let mut curve = Vec::with_capacity(a.bins.len());
    for (i, (&pa, &pb)) in a.bins.iter().zip(&b.bins).enumerate() {
        let x = pa - a_duration_db;
        let y = pb - b_duration_db;
        let difference_db = match gain {
            None => cant("no common nonzero loudness support"),
            Some(_) if x == f64::NEG_INFINITY && y == f64::NEG_INFINITY => {
                cant("both spectra have zero energy in this bin")
            }
            Some(g) => {
                let difference = y - x + g;
                // Report the entire unsmoothed curve, but choose the headline
                // only from bins occupied in at least one spectrum. This
                // avoids selecting a meaningless floating FFT leakage bin.
                if (x >= a_peak - 80.0 || y >= b_peak - 80.0)
                    && largest.is_none_or(|(m, _)| difference.abs() > m)
                {
                    largest = Some((difference.abs(), i));
                }
                Outcome::Value(difference)
            }
        };
        curve.push(TonalBin {
            frequency_hz: i as f64 * f64::from(a.rate) / a.n as f64,
            difference_db,
        });
    }
    TonalBalance {
        gain_db: gain.map_or_else(
            || cant("no common nonzero loudness support"),
            Outcome::Value,
        ),
        normalization,
        largest: largest.map_or_else(
            || cant("no material spectral difference can be determined"),
            |(_, i)| Outcome::Value(curve[i].clone()),
        ),
        curve,
    }
}
