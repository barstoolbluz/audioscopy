// SPDX-License-Identifier: GPL-2.0-or-later
//! Selective comparisons of caller-paired, decoded recordings.
//!
//! This interface is separate from the streaming single-recording analyzer.
//! It borrows PCM for the duration of a call and never retains it in a report.
mod align;
mod energy;
mod tonal;

use crate::{Error, Format, Outcome, Settings};
use std::cmp::Ordering;

/// One comparison measurement. Existing single-recording selections are unchanged.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
#[repr(u8)]
pub enum Measurement {
    /// Residual-to-reference energy after alignment and a common scalar gain.
    NullDepth,
    /// Loudness-matched spectral power difference.
    TonalBalance,
    /// Relative playback speed and pitch-equivalent cents.
    Speed,
    /// Global polarity and stereo channel order.
    PolarityAndChannels,
    /// Exact decoded sample identity, with or without a positive gain.
    SameAudio,
    /// Album-relative change in integrated track loudness.
    TrackLevels,
    /// Peak local speed departure from the affine clock fit.
    TimingDrift,
    /// Statistics of aligned rolling residual-to-reference energy.
    ResidualOverTime,
}

impl Measurement {
    /// All eight comparison measurements, in specification order.
    pub const ALL: [Self; 8] = [
        Self::NullDepth,
        Self::TonalBalance,
        Self::Speed,
        Self::PolarityAndChannels,
        Self::SameAudio,
        Self::TrackLevels,
        Self::TimingDrift,
        Self::ResidualOverTime,
    ];
}

/// An independent comparison selection; the default is empty.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct Measurements(u8);

impl Measurements {
    /// Request all comparison measurements.
    pub const fn all() -> Self {
        Self(u8::MAX)
    }
    /// Select individual measurements. Duplicate entries are harmless.
    pub fn new(items: &[Measurement]) -> Self {
        Self(items.iter().fold(0, |mask, item| mask | (1 << *item as u8)))
    }
    /// Whether a measurement was requested.
    pub const fn contains(self, item: Measurement) -> bool {
        self.0 & (1 << item as u8) != 0
    }
    /// Persistable selection mask.
    pub const fn bits(self) -> u8 {
        self.0
    }
    /// Recover a selection mask. All eight bits are defined.
    pub const fn from_bits(bits: u8) -> Self {
        Self(bits)
    }
    fn any(self, items: &[Measurement]) -> bool {
        items.iter().any(|&m| self.contains(m))
    }
}

/// One decoded recording. Samples are interleaved in the format's channel order.
#[derive(Clone, Copy, Debug)]
pub struct Recording<'a> {
    /// Original decoded format.
    pub format: &'a Format,
    /// Normalized finite binary64 PCM, using the ordinary analyzer's conventions.
    pub samples: &'a [f64],
}

impl Recording<'_> {
    fn frames(self) -> usize {
        self.samples.len() / self.format.channels
    }
    fn sample(self, frame: usize, channel: usize) -> f64 {
        self.samples[frame * self.format.channels + channel]
    }
    fn validate(self) -> Result<(), Error> {
        crate::stream::validate_format(self.format, Settings::default())?;
        crate::stream::validate_samples(self.format, self.samples)?;
        if self.frames() == 0 {
            return Err(Error::Empty);
        }
        if self.frames() as u64 > crate::stream::MAX_FRAMES {
            return Err(Error::ResourceLimit);
        }
        Ok(())
    }
}

/// Provenance of reference A, asserted by the caller rather than inferred from PCM.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ReferenceSource {
    /// Digital timebase appropriate for relative drift measurement.
    Digital,
    /// Analog timebase or unknown provenance; no drift claim is made.
    AnalogOrUnknown,
}

/// Caller-selected track pair. A is the reference, B the recording under test.
#[derive(Clone, Copy, Debug)]
pub struct Pair<'a> {
    /// Reference recording A.
    pub reference: Recording<'a>,
    /// Recording B.
    pub recording: Recording<'a>,
    /// Provenance of A for timing drift.
    pub reference_source: ReferenceSource,
}

impl Pair<'_> {
    fn validate(self) -> Result<(), Error> {
        if self.reference.format.sample_rate != self.recording.format.sample_rate {
            return Err(Error::Configuration(
                "comparison sample rates differ; caller must convert",
            ));
        }
        self.reference.validate()?;
        self.recording.validate()?;
        Ok(())
    }
}

/// Original decoded duration comparison, independent of selected measurements.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Duration {
    /// Sample rate in Hz.
    pub sample_rate: u32,
    /// Frames in A.
    pub reference_frames: u64,
    /// Frames in B.
    pub recording_frames: u64,
}
impl Duration {
    /// True only for exactly equal decoded durations (not merely aligned overlap).
    pub const fn agrees(self) -> bool {
        self.reference_frames == self.recording_frames
    }
}

/// Speed of B relative to A. Positive means faster playback / shorter duration.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Speed {
    /// Relative playback speed in percent (zero means equal speed).
    pub percent: f64,
    /// Pitch-equivalent cents (not a pitch measurement).
    pub cents: f64,
    /// Empirical fit scatter expressed in percentage points, not a confidence interval.
    pub fit_scatter_percent: f64,
}

/// Global polarity and stereo channel mapping of B relative to A.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum PolarityAndChannels {
    /// Same channel order and polarity.
    Same,
    /// All channels inverted.
    Inverted,
    /// Left and right exchanged.
    Swapped,
    /// Left and right exchanged and all channels inverted.
    SwappedAndInverted,
    /// Album only: distinguishable track results disagree.
    Mixed,
}

/// Exact decoded sample comparison, without alignment, trimming or tolerance.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum SameAudio {
    /// Identical binary64 bit patterns in order (including signed zeros).
    Same,
    /// Exact positive proportionality or exact rounded binary64 multiplication.
    SameAfterGain {
        /// Linear amplitude gain from A to B, rounded to binary64 for an exact rational ratio.
        gain: f64,
    },
    /// Neither exact test passed.
    Different,
}

/// Album same-audio count. Gain-only matches are included separately.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct SameAudioCount {
    /// Bit-identical pairs.
    pub same: usize,
    /// Additional exact positive gain-only pairs.
    pub same_after_gain: usize,
    /// Number of supplied pairs.
    pub total: usize,
}

/// Rolling null-depth summary in dB relative to A's energy in each window.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct ResidualSummary {
    /// Median (lower empirical quantile).
    pub median_db: f64,
    /// 99th percentile (nearest rank).
    pub percentile_99_db: f64,
    /// Largest residual ratio.
    pub worst_db: f64,
    /// Number of informative windows.
    pub windows: usize,
}

/// One spectral difference bin. Positive means more energy in B after matching.
#[derive(Clone, Debug, PartialEq)]
pub struct TonalBin {
    /// Frequency in Hz.
    pub frequency_hz: f64,
    /// Signed difference in dB; unobservable bins carry an explicit reason.
    pub difference_db: Outcome<f64>,
}

/// Loudness normalization used by the tonal comparison.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum TonalNormalization {
    /// Integrated native BS.1770 loudness.
    IntegratedLoudness,
    /// Channel-mean broadband energy fallback when integrated loudness is unavailable.
    BroadbandRms,
    /// One or both recordings have no usable power; no loudness match exists.
    Unavailable,
}

/// A numerical full-resolution spectral difference curve and its strongest material bin.
#[derive(Clone, Debug, PartialEq)]
pub struct TonalBalance {
    /// Gain added to B in dB to match A, or explicit unavailability.
    pub gain_db: Outcome<f64>,
    /// Normalization actually used.
    pub normalization: TonalNormalization,
    /// Largest absolute difference over materially occupied bins, with its sign.
    pub largest: Outcome<TonalBin>,
    /// Complete curve including unobservable bins, DC and Nyquist.
    pub curve: Vec<TonalBin>,
}

/// Support actually compared by the alignment-dependent residual measurements.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct AlignmentSupport {
    /// Affine delay at the reference midpoint, B frames minus A frames.
    pub midpoint_delay_frames: f64,
    /// First reference frame included in the overlap.
    pub first_reference_frame: u64,
    /// Number of reference frames included.
    pub compared_frames: u64,
    /// Whether the fractional-delay evaluator was needed.
    pub fractional: bool,
}

/// All selected single-pair results. Unselected fields are `NotRequested`.
#[derive(Clone, Debug, PartialEq)]
pub struct TrackComparison {
    /// Original durations, even when no measurements are selected.
    pub duration: Duration,
    /// Null depth in dB (more negative is a deeper null).
    pub null_depth_db: Outcome<f64>,
    /// Tonal comparison.
    pub tonal_balance: Outcome<TonalBalance>,
    /// Relative speed.
    pub speed: Outcome<Speed>,
    /// Global polarity and stereo channel order.
    pub polarity_and_channels: Outcome<PolarityAndChannels>,
    /// Exact identity.
    pub same_audio: Outcome<SameAudio>,
    /// Album-only measurement, never computed for a single track.
    pub track_levels_db: Outcome<f64>,
    /// Peak local speed deviation in percent, relative to the fitted speed.
    pub timing_drift_percent: Outcome<f64>,
    /// Rolling residual statistics.
    pub residual_over_time: Outcome<ResidualSummary>,
    /// Alignment support, only when an alignment-dependent metric was attempted.
    pub alignment: Outcome<AlignmentSupport>,
}

/// Album values for the supplied ordered set of pairs. No track pairing is inferred.
#[derive(Clone, Debug, PartialEq)]
pub struct AlbumComparison {
    /// Original duration agreement for each pair, in caller order.
    pub durations: Vec<Duration>,
    /// Energy-pooled null depth.
    pub null_depth_db: Outcome<f64>,
    /// Energy-pooled spectra with album loudness normalization.
    pub tonal_balance: Outcome<TonalBalance>,
    /// Median track playback speed.
    pub speed: Outcome<Speed>,
    /// Common polarity/channel result, or mixed.
    pub polarity_and_channels: Outcome<PolarityAndChannels>,
    /// Exact-identity counts.
    pub same_audio: Outcome<SameAudioCount>,
    /// Largest absolute per-track loudness change after subtracting album offset.
    pub track_levels_db: Outcome<f64>,
    /// Worst peak drift across tracks.
    pub timing_drift_percent: Outcome<f64>,
    /// The complete summary of the track with the largest worst-window ratio.
    pub residual_over_time: Outcome<ResidualSummary>,
}

fn cant<T>(reason: &str) -> Outcome<T> {
    Outcome::CantTell(reason.to_owned())
}
fn requested<T>(
    selection: Measurements,
    m: Measurement,
    f: impl FnOnce() -> Outcome<T>,
) -> Outcome<T> {
    if selection.contains(m) {
        f()
    } else {
        Outcome::NotRequested
    }
}
fn duration(pair: Pair<'_>) -> Duration {
    Duration {
        sample_rate: pair.reference.format.sample_rate,
        reference_frames: pair.reference.frames() as u64,
        recording_frames: pair.recording.frames() as u64,
    }
}

// Exact gain accepts a positive binary64 rounded-product proof or an exact
// rational proportionality proof.
// Rounded multiplication is monotone in a positive gain's bit pattern.
// The common path tests a small bracket near a well-conditioned ratio;
// interval intersection handles subnormal products and ambiguous rounding.
fn exact_gain(pair: Pair<'_>, swap: bool, sign: f64) -> Option<f64> {
    let a = pair.reference;
    let b = pair.recording;
    if a.frames() != b.frames() || a.format.channels != b.format.channels {
        return None;
    }
    let channels = a.format.channels;
    let (i, &x) = a
        .samples
        .iter()
        .enumerate()
        .max_by(|(_, x), (_, y)| x.abs().total_cmp(&y.abs()))?;
    if x == 0.0 {
        return None;
    }
    let at = |i: usize| {
        b.samples[i / channels * channels + if swap { 1 - i % channels } else { i % channels }]
    };
    // Zero output throughout is not an audible gain-only equivalence.
    if at(i) == 0.0 {
        return None;
    }
    let g = sign * at(i) / x;
    if g.is_finite() && g > 0.0 {
        let bits = g.to_bits();
        for offset in [0_i64, -1, 1, -2, 2] {
            let Some(bits) = bits.checked_add_signed(offset) else {
                continue;
            };
            let g = f64::from_bits(bits);
            if g <= 0.0 || !g.is_finite() {
                continue;
            }
            let product = |x: f64| x * (sign * g);
            if (0..a.samples.len())
                .step_by((a.samples.len() / 127).max(1))
                .any(|i| product(a.samples[i]).to_bits() != at(i).to_bits())
            {
                continue;
            }
            if a.samples
                .iter()
                .enumerate()
                .all(|(i, &x)| product(x).to_bits() == at(i).to_bits())
            {
                return Some(g);
            }
        }
    }
    let rounded = || {
        let mut lo = 1_u64;
        let mut hi = f64::MAX.to_bits();
        // Examine the largest reference sample first; its rounding interval is
        // generally the narrowest. Then intersect all remaining constraints.
        for i in std::iter::once(i).chain(0..a.samples.len()) {
            let x = sign * a.samples[i];
            let y = at(i);
            if x.is_sign_negative() != y.is_sign_negative() {
                return None;
            }
            let x = x.abs();
            let y = y.abs();
            if x == 0.0 {
                if y != 0.0 {
                    return None;
                } else {
                    continue;
                }
            }
            let product = |bits: u64| x * f64::from_bits(bits);
            if product(lo) > y || product(hi) < y {
                return None;
            }
            if product(lo) < y {
                let mut left = lo;
                let mut right = hi;
                while left < right {
                    let mid = left + (right - left) / 2;
                    if product(mid) < y {
                        left = mid + 1;
                    } else {
                        right = mid;
                    }
                }
                lo = left;
            }
            if product(lo) != y {
                return None;
            }
            if product(hi) > y {
                let mut left = lo;
                let mut right = hi;
                while left < right {
                    let mid = left + (right - left).div_ceil(2);
                    if product(mid) > y {
                        right = mid - 1;
                    } else {
                        left = mid;
                    }
                }
                hi = left;
            }
        }
        Some(f64::from_bits(lo))
    };
    rounded().or_else(|| {
        // A rational gain need not be representable as one binary64 value.
        // Keep signed-zero compatibility, and report the rounded ratio only
        // after proving exact proportionality on the original samples.
        if !g.is_finite() || g <= 0.0 {
            return None;
        }
        let a0 = sign * a.samples[i];
        let b0 = at(i);
        a.samples
            .iter()
            .enumerate()
            .all(|(j, &x)| {
                let x = sign * x;
                let y = at(j);
                x.is_sign_negative() == y.is_sign_negative() && energy::proportional(x, y, a0, b0)
            })
            .then_some(g)
    })
}

fn same_audio(pair: Pair<'_>) -> SameAudio {
    let a = pair.reference;
    let b = pair.recording;
    if a.format.channels != b.format.channels || a.samples.len() != b.samples.len() {
        return SameAudio::Different;
    }
    if a.samples
        .iter()
        .zip(b.samples)
        .all(|(x, y)| x.to_bits() == y.to_bits())
    {
        return SameAudio::Same;
    }
    exact_gain(pair, false, 1.0).map_or(SameAudio::Different, |gain| SameAudio::SameAfterGain {
        gain,
    })
}

struct PairWork {
    report: TrackComparison,
    energy: Option<energy::NullEnergy>,
    tonal: Option<tonal::PairTonal>,
    loudness: Option<tonal::LoudnessPair>,
}

fn analyze(pair: Pair<'_>, selection: Measurements, album: bool) -> Result<PairWork, Error> {
    use Measurement as M;
    let mut report = TrackComparison {
        duration: duration(pair),
        null_depth_db: Outcome::NotRequested,
        tonal_balance: Outcome::NotRequested,
        speed: Outcome::NotRequested,
        polarity_and_channels: Outcome::NotRequested,
        same_audio: Outcome::NotRequested,
        track_levels_db: requested(selection, M::TrackLevels, || Outcome::NotApplicable),
        timing_drift_percent: Outcome::NotRequested,
        residual_over_time: Outcome::NotRequested,
        alignment: Outcome::NotRequested,
    };
    report.same_audio = requested(selection, M::SameAudio, || Outcome::Value(same_audio(pair)));
    let need_tonal = selection.contains(M::TonalBalance);
    let need_levels = album && selection.contains(M::TrackLevels);
    let (tonal, loudness) = if need_tonal || need_levels {
        let loudness = tonal::loudness_pair(pair)?;
        let delta = loudness.delta();
        let spectra = if need_tonal {
            Some(tonal::PairTonal::new(pair))
        } else {
            None
        };
        if !album {
            if let Some(spectra) = &spectra {
                report.tonal_balance = Outcome::Value(spectra.track(delta));
            }
        }
        (spectra, Some(loudness))
    } else {
        (None, None)
    };
    let drift =
        selection.contains(M::TimingDrift) && pair.reference_source == ReferenceSource::Digital;
    if selection.contains(M::TimingDrift) && !drift {
        report.timing_drift_percent = cant("reference A is not declared digital");
    }
    let mut energy = None;
    if drift
        || selection.any(&[
            M::NullDepth,
            M::Speed,
            M::PolarityAndChannels,
            M::ResidualOverTime,
        ])
    {
        match align::estimate(pair) {
            Ok(model) => {
                report.alignment = Outcome::Value(model.support());
                report.speed = requested(selection, M::Speed, || model.speed());
                report.polarity_and_channels =
                    requested(selection, M::PolarityAndChannels, || model.polarity());
                if drift {
                    report.timing_drift_percent = align::drift(pair, &model)?;
                }
                if selection.any(&[M::NullDepth, M::ResidualOverTime]) {
                    let result =
                        energy::residual(pair, &model, selection.contains(M::ResidualOverTime))?;
                    match result {
                        Some((stats, windows)) => {
                            report.null_depth_db =
                                requested(selection, M::NullDepth, || stats.outcome());
                            report.residual_over_time =
                                requested(selection, M::ResidualOverTime, || windows);
                            energy = Some(stats);
                        }
                        None => {
                            report.null_depth_db = requested(selection, M::NullDepth, || {
                                cant("no usable reference energy in overlap")
                            });
                            report.residual_over_time =
                                requested(selection, M::ResidualOverTime, || {
                                    cant("no usable reference energy in overlap")
                                });
                        }
                    }
                }
            }
            Err(reason) => {
                report.alignment = cant(reason);
                report.speed = requested(selection, M::Speed, || cant(reason));
                report.polarity_and_channels =
                    requested(selection, M::PolarityAndChannels, || cant(reason));
                report.null_depth_db = requested(selection, M::NullDepth, || cant(reason));
                report.residual_over_time =
                    requested(selection, M::ResidualOverTime, || cant(reason));
                if drift {
                    report.timing_drift_percent = cant(reason);
                }
            }
        }
    }
    Ok(PairWork {
        report,
        energy,
        tonal,
        loudness,
    })
}

/// Measure a single caller-supplied pair. The two sample rates must agree.
/// Input validation is performed even for an empty selection.
pub fn compare(pair: Pair<'_>, selection: Measurements) -> Result<TrackComparison, Error> {
    pair.validate()?;
    Ok(analyze(pair, selection, false)?.report)
}

fn all_values<T: Clone>(
    tracks: &[TrackComparison],
    get: impl Fn(&TrackComparison) -> &Outcome<T>,
) -> Outcome<Vec<T>> {
    let mut values = Vec::with_capacity(tracks.len());
    for track in tracks {
        match get(track) {
            Outcome::Value(value) => values.push(value.clone()),
            Outcome::CantTell(reason) => return Outcome::CantTell(reason.clone()),
            _ => return cant("one or more paired tracks have no applicable value"),
        }
    }
    Outcome::Value(values)
}
fn reduce<T: Clone, U>(
    tracks: &[TrackComparison],
    get: impl Fn(&TrackComparison) -> &Outcome<T>,
    f: impl FnOnce(Vec<T>) -> U,
) -> Outcome<U> {
    match all_values(tracks, get) {
        Outcome::Value(v) => Outcome::Value(f(v)),
        Outcome::CantTell(s) => Outcome::CantTell(s),
        _ => unreachable!(),
    }
}

/// Measure an album from explicitly supplied, complete track pairs. All pairs
/// share a sample rate. The caller owns album membership and missing-track policy.
/// No PCM is copied or concatenated. An unavailable track is never silently
/// dropped from a reducer that requires all tracks.
pub fn compare_album(
    pairs: &[Pair<'_>],
    selection: Measurements,
) -> Result<AlbumComparison, Error> {
    use Measurement as M;
    let first = pairs.first().ok_or(Error::Empty)?;
    for &pair in pairs {
        pair.validate()?;
        if pair.reference.format.sample_rate != first.reference.format.sample_rate {
            return Err(Error::Configuration(
                "album comparison requires one shared sample rate",
            ));
        }
    }
    let mut tracks = Vec::with_capacity(pairs.len());
    let mut pooled_energy = energy::NullEnergy::empty();
    let mut tonal = selection
        .contains(M::TonalBalance)
        .then(tonal::AlbumTonal::new);
    let mut deltas = Vec::new();
    let mut loudness = selection
        .any(&[M::TonalBalance, M::TrackLevels])
        .then(tonal::AlbumLoudness::new);
    for &pair in pairs {
        let work = analyze(pair, selection, true)?;
        if let Some(value) = work.energy {
            pooled_energy.merge(value);
        }
        if let (Some(album), Some(track)) = (&mut tonal, work.tonal) {
            album.push(track)?;
        }
        if let (Some(album), Some(track)) = (&mut loudness, work.loudness) {
            if selection.contains(M::TrackLevels) {
                if let Some(delta) = track.delta() {
                    deltas.push(delta);
                }
            }
            album.push(track)?;
        }
        tracks.push(work.report);
    }
    let album_delta = match loudness {
        Some(album) => album.finish()?,
        None => None,
    };
    let tonal_balance = match tonal {
        Some(album) => Outcome::Value(album.finish(album_delta)),
        None => Outcome::NotRequested,
    };
    let speed = requested(selection, M::Speed, || {
        reduce(
            &tracks,
            |t| &t.speed,
            |mut values| {
                values.sort_by(|a, b| a.percent.total_cmp(&b.percent));
                let n = values.len();
                let a = values[(n - 1) / 2];
                let b = values[n / 2];
                let percent = (a.percent + b.percent) * 0.5;
                Speed {
                    percent,
                    cents: 1200.0 * (percent / 100.0).ln_1p() / std::f64::consts::LN_2,
                    fit_scatter_percent: a.fit_scatter_percent.max(b.fit_scatter_percent),
                }
            },
        )
    });
    Ok(AlbumComparison {
        durations: tracks.iter().map(|t| t.duration).collect(),
        null_depth_db: requested(selection, M::NullDepth, || {
            reduce(&tracks, |t| &t.null_depth_db, |_| pooled_energy.depth())
        }),
        tonal_balance,
        speed,
        polarity_and_channels: requested(selection, M::PolarityAndChannels, || {
            reduce(
                &tracks,
                |t| &t.polarity_and_channels,
                |v| {
                    if v.iter().all(|x| *x == v[0]) {
                        v[0]
                    } else {
                        PolarityAndChannels::Mixed
                    }
                },
            )
        }),
        same_audio: requested(selection, M::SameAudio, || {
            reduce(
                &tracks,
                |t| &t.same_audio,
                |v| SameAudioCount {
                    same: v.iter().filter(|x| matches!(x, SameAudio::Same)).count(),
                    same_after_gain: v
                        .iter()
                        .filter(|x| matches!(x, SameAudio::SameAfterGain { .. }))
                        .count(),
                    total: v.len(),
                },
            )
        }),
        track_levels_db: requested(selection, M::TrackLevels, || {
            if deltas.len() != tracks.len() {
                return cant("integrated loudness unavailable for a paired track");
            }
            let Some(offset) = album_delta else {
                return cant("album integrated loudness unavailable");
            };
            Outcome::Value(
                deltas
                    .iter()
                    .map(|d| (d - offset).abs())
                    .fold(0.0, f64::max),
            )
        }),
        timing_drift_percent: requested(selection, M::TimingDrift, || {
            reduce(
                &tracks,
                |t| &t.timing_drift_percent,
                |v| v.into_iter().fold(0.0, f64::max),
            )
        }),
        residual_over_time: requested(selection, M::ResidualOverTime, || {
            reduce(
                &tracks,
                |t| &t.residual_over_time,
                |v| {
                    v.into_iter()
                        .max_by(|a, b| {
                            a.worst_db
                                .partial_cmp(&b.worst_db)
                                .unwrap_or(Ordering::Equal)
                        })
                        .expect("nonempty album")
                },
            )
        }),
    })
}
