# Measurement definitions

This document records how Audioscopy defines and computes each measurement:
the thresholds, estimator choices and known limitations. The README gives an
overview; this document is the reference for anyone interpreting or comparing
results.

Several heuristic measurements need operational thresholds. The definitions
below are Audioscopy's explicit choices, configurable where stated.

## Input

The input is interleaved binary64 (`f64`) PCM.

- **Integer PCM.** Normalize each signed `b`-bit code by `2^(b-1)`, so full
  scale is `-1.0` through `1.0 - 2^(1-b)`, and declare `Encoding::Integer(b)`.
  The analyzer requires exact normalized codes. Do not scale by `i16::MAX`,
  round float samples or dither in the decoder before measurement.
- **Float PCM** is accepted as delivered, including finite overs up to an
  absolute magnitude of 16. NaN and infinite samples are rejected.
- Supported rates are 8–768 kHz, channels 1–64, integer depths 1–32.
- Loudness measurements with more than two channels require explicit
  loudness roles. Stereo measurements apply only to exactly two channels.

## Selection and shared computation

`Measurements::new` selects individual measurements and `Measurements::all`
selects all 25. `Measurements::default` is empty; default selections belong to
the application.

Requesting a subset avoids the other measurements' DSP and storage. Shared
prerequisites, such as the spectra used by several noise measurements, are
computed once per required stream.

Loudness uses one of three native meters from `true-peak`, chosen by the
selection:

| Selected | Meter |
|---|---|
| Loudness range only | Range-only meter. No integrated loudness observations are accumulated. |
| Short-term maximum and/or loudness over time only | Short-term meter. No range or integrated work is started. |
| Loudness range and a short-term measurement | One shared meter. A single K-weighting filter path feeds both the range and the short-term observations. |

All three use the conditioned binary64 K-weighting realization (see
[K-weighting](#k-weighting)).

## Streaming and errors

Chunk boundaries do not reset analysis; any whole-frame chunk length gives the
same result. Malformed pushes are validated before any state changes. A
terminal processing error requires a new analyzer. `finish` consumes the
analyzer and rejects a stream of zero frames.

## Quiet passages

Quiet-passage detection drives the noise floor, dynamic range, effective bits,
noise spectrum, hum and idle tones, and noise by band.

- Rational 50 ms blocks qualify when the maximum per-channel RMS is at or below
  `quiet_threshold_dbfs` (default -60 dBFS).
- Transition-block refinement separates clear loud material using extreme
  excursions or short 1 ms local RMS evidence. Aggregate per-channel RMS
  qualifies the actual prefix or suffix, including quiet waveforms with
  above-threshold crests.
- A consistent adjacent quiet block supplies bounded energy context for partial
  cycles: half its minimum channel headroom per edge, peak within 3 dB of its
  above-threshold crest, and no extreme excursion.
- If a mixed-block edge fails its aggregate test, up to two 1 ms local slices
  may be trimmed at the separator-facing end. The retained edge must satisfy
  the same adjacent quiet context. Trimming is never used to admit an entire
  final partial block.
- Clear abrupt transitions retain sample-level boundaries. Tonal transitions
  remain estimates. Ambiguous low-contrast changes use the coarse detector and
  instantaneous edges.
- Only contiguous real frames count toward `shortest_gap_seconds` (default
  1 s). No padding or reduction of the minimum is used.

## Spectrum

- Windows are 50%-overlap sine-of-Hann (Vorbis) windows of size
  `next_power_of_two(ceil(sample_rate / 6))`. For hop `H = N/2`,
  `w[i]^2 + w[i+H]^2 = 1`.
- The first window starts `H` frames before the stream. Outside the actual
  stream or passage, all samples are zero. Each real frame is counted once in
  the denominator.
- A fixed one-sided FFT normalization preserves mean square without rescaling
  frequency bins by block energy. Spectral leakage and bin resolution still
  limit band and line estimates.
- Bins use half-open frequency bands, with Nyquist included in the final band.
  Every frame contributes to the retained power spectrum.
- A-weighting and ITU-R 468 apply their frequency response as a power
  multiplier. ITU-R 468 is RMS-weighted, not quasi-peak.

### Bandwidth

- Bandwidth augments the complete-window extent with separately tapered
  real-support first and last half-hop views and shorter endpoint views.
- Complete-window bins must meet a -80 dB floor relative to the full
  recording's maximum accumulated power bin, even if the interior contains only
  dither.
- Local peaks must meet the -80 dB threshold relative to both their own view's
  maximum and the full recording's maximum accumulated power bin.
- Endpoint power uses the same fixed one-sided FFT normalization as the
  retained spectrum. Neither level nor duration is independently normalized.
- The highest eligible peak beyond the interior extent's physical-resolution
  guard can extend bandwidth. Endpoint inference bins never enter the retained
  power spectrum.
- Files without any material interior bin use actual-support tapered evidence,
  subject to the same materiality test.

Source-rate, codec and stereo inference still prefer fully observed windows,
and can underrepresent content that appears only near the endpoints.

## Dynamics

- **Limiting** uses sample peaks in rational 50 ms blocks, including a final
  partial block, within 1 dB of the track maximum. The inventory permits sample
  peaks instead of block true peaks. An all-silent track reports 0%.
- **Flat-topped peaks** are runs of at least 3 samples (relative tolerance 1e-5
  or one integer LSB, whichever is larger). Both neighbouring samples must prove
  a local extremum, and the absolute value must be within 1 dB of the track
  peak. Runs are counted per channel. Resampling and lossy coding may erase flat
  tops; slow or saturated waveforms may also produce them.

## Resolution

### Bits in use

- The OR of exact signed codes gives the normalized low-bit depth.
- The GCD of differences from the first code gives the exact affine lattice
  step. `observed_lattice_bits` is the ceil-log2 width of the observed span in
  lattice positions (`None` for constant samples).
- `used` is the smaller width for a demonstrable non-binary or offset affine
  lattice of at least three positions. Ordinary headroom does not prevent this
  reduction.
- An aligned binary grid retains the normalized count unless its span has a
  power-of-two count of at least four positions and at least that many samples.
  Two points alone do not establish an affine subset.
- Float PCM is tested exactly on the normalized 2^-52 grid, with no snapping.
  Arbitrary float PCM may report `NonIntegerGrid`. Silence uses zero bits.

This measures observed grid evidence. It does not establish the source bit
depth, and it does not prove that every lattice position was used.

### Effective bits

Effective bits are approximately `-noise_floor_dbfs / (20 log10 2)`. No ideal
quantizer or full-scale sine correction is applied. The album value uses the
pooled album noise floor, following the inventory's provisional rule. Zero
noise does not establish a finite bound on effective bits.

### Dither

- Uses the nominal integer spacing when eligible. Otherwise it requires exact
  zero-aligned binary spacing and a peak of no more than eight such LSBs.
- Both signs and the spectral-shape test are required.
- Exact integer-grid floats and padded integer PCM can qualify. Affine spacing
  alone does not establish a binary quantizer; for example, multiples of 100
  nominal codes have only four-code alignment and fail the magnitude gate.

Dither classification is a heuristic. It is not proof of provenance.

## Stereo

- **Correlation** is mean-removed Pearson covariance. Zero-variance correlation
  is 0.
- **Balance** is positive when the left channel is louder.
- **Width** is side/mid power in dB. Zero/zero stereo energy is defined as 0 dB.
- **Mono compatibility** is the non-negative loss from averaging the channels,
  relative to their average pre-sum power.
- **Inter-channel delay** is positive when the right channel lags the left.
  Delay accumulates upper-band cross power and performs one inverse FFT at
  finish.
- **Bass width** reports the cutoff in Hz below which the bass is effectively
  mono.

## Loudness

Loudness follows ITU-R BS.1770 K-weighting and EBU Tech 3342 loudness range.
Short-term measurements use complete three-second windows at 100 ms intervals.
A maximum over no complete window reports a reason, not a number.

### K-weighting

Short-term maximum, loudness over time, and track and continuous-album loudness
range use the conditioned native K-weighting realization in `true-peak`.
Measurement selection, gating, window clocks and album continuity are unchanged
by the conditioning; it reduces arithmetic error only.

## Albums

`AlbumAnalyzer::new(selection, settings)`, then for each track in order
`begin_track(format)`, zero or more `push_interleaved` calls and `end_track`,
then `finish`. Each track is decoded once. `Album::tracks()` exposes the ordered
track results. `Album::measure` applies each measurement's album reduction rule.

- **Continuous loudness range.** With `AlbumAnalyzer`, loudness range follows a
  continuous programme clock and filter across tracks with the same sample rate
  and channel roles, including windows that cross track boundaries.
- **Independent reports.** `Album::from_tracks(Vec<Track>)` accepts
  individually computed tracks with identical selections and detector settings.
  Independent statistics cannot reconstruct boundary windows, so album loudness
  range is `Outcome::CantTell` with a reason. The same applies when the rate or
  roles change between tracks. A single cached track is already one complete
  programme. No resampler or artificial per-track tail is used.
- `Album::loudness_method()` reports whether loudness range is continuous,
  unavailable or not requested. Other album measurements remain available.
- **Pooling.** Unavailable track results contribute no evidence to modes and
  medians over eligible tracks. If no track applies, the album returns the
  corresponding typed unavailable outcome. Power-based pooling weights by
  qualifying quiet time or programme time, never by track count, by sample
  count across mismatched sample rates, or by a mean in dB.

## Outcomes and curves

`Outcome::NotRequested`, `Outcome::NotApplicable`, `Outcome::CantTell(reason)`
and `Outcome::Value(value)` are distinct. The first three are never numeric.

- Exact zero power has a defined level of negative infinity. Positive infinity
  may describe an exact zero denominator. NaN is never used as a display
  sentinel.
- Loudness range with no eligible observations, and resolution or dynamic range
  unbounded because of pure silence, report a reason rather than a fabricated
  finite result.
- `Value::Curve` is ordered numerical data. `Value::Curves` holds per-track
  loudness curves for an album.
- Spectrum curves are one-sided power density in dBFS/Hz, with frequency in Hz.
  Album spectrum bins map to the finest native grid by linear energy splatting.
- Loudness points use an exclusive end time in seconds and LUFS.

## Noise records

`Track::noise_record()` exports the sufficient statistics of the selected noise
measurements only, as a `NoiseRecord` (schema version 2). Applications may
persist its plain fields in any cache format.

- Version 1 records must be regenerated from PCM. Their frequency distribution
  used a different, incorrect normalization.
- `NoiseSnapshot::from_record` validates masks, geometry, frames, power,
  thresholds and numeric values before accepting a record. Its `measure` and
  `measure_album` reuse the report arithmetic, without PCM or FFT.
- A record cannot supply measurements that were not originally selected.
- Weighting and band changes apply at read time. Changing the quiet threshold or
  the shortest gap requires a new analysis.
- Dither and click classifications do not change with frequency weighting or
  display band.
- A track with no qualifying quiet data has no spectrum. It never reports an
  invented zero noise measurement.

## Reference-recording comparisons

The `comparison` API accepts borrowed, interleaved decoded PCM pairs. A is
always the reference, B the recording under test. Input validation is the same
as the ordinary analyzer. The sample rates must match, including across album
pairs. There is no public resampling facility or automatic track matching.
Duration agreement is exact frame-count equality, independent of whether
an alignment can be found. Missing pairs cannot be inferred: the caller must
supply the intended complete set. An empty album is an input error. The
selection and report are independent of the existing 25 measurements. Results
use the existing `Outcome` distinctions. A resource or configuration error is
not a numerical observation. Album reducers which need all tracks do not
silently omit a failed track.

### Shared time and channel alignment

First test for exact decoded gain/polarity/channel equivalence on equal-length
pairs. Otherwise fit the map `j = i + delay + delta*(i - midpoint)` from A's
frame i to B's frame j. The delay is in B frames at the midpoint of A. The
search uses seven distributed anchors, two coarse grid phases, coarse block
means near 2 kHz, a duration-derived slope as a search hint, and an unwarped
alternative. Coarse windows are nominally 100 ms, with a search of approximately
2 s either side of the duration-based prediction. Competing hypotheses are
retained and tested for clock consensus rather than treating the highest local
correlation as an unambiguous match. Near-identical equal-duration material
uses independent local anchors near zero delay instead. Local refinements use
normalized least-squares error and a native fractional-delay evaluator. The
fit operates on delays, not large absolute timestamps. Compare a zero-stretch
integer fit against the fractional fit before committing to interpolation.

Bounds: nonidentical inputs need at least half a second, duration ratio
0.8–1.25, absolute clock slope at most 0.05, at least three reliable anchors
spanning at least one third of A, and fitted anchor residuals no greater than
3 ms. Common overlap must cover at least 80% of each recording. The sampled
whole-overlap correlation magnitude must be at least 0.60. Quiet, repetitive,
unrelated, edited, time-warped or substantially filtered recordings may fail
these tests; a passing fit does not prove common provenance. Large trims and
local edits are outside the intended envelope. Non-affine playback must pass
the short-time motion check below; null depth still removes only the fitted
affine trend, not individual local fluctuations.

A line through delays is a candidate, not proof of a shared clock. At each
separated refined anchor, independently remove scalar gain from the raw
waveform and its first differences (an upper-frequency-weighted projection).
In each projection divide the residual norm by the gain-orthogonal timing
derivative norm. This expresses mismatch on a frame scale and bounds the
magnitude of a linearized lag correction, not the physical clock error for
an arbitrary filter. Require the larger mismatch at every anchor to be at
most 10% of the candidate's cumulative delay excursion across the anchor
span, with a 1e-6 frame numerical observation allowance. This is not a ppm
deadband: clean tiny affine changes can pass. Substantial causal EQ, noise,
or dynamics differences can leave too little timing evidence for a small or
zero slope. The conservative decision is unavailable, not an assumed zero.

For nonlinear timing, a bounded validation pass at up to five nonuniform
short-window positions near each of the seven candidate anchors independently
fits local lag and slope. Require reliable motion on both sides of the fitted
slope, and mismatch in both projections no greater than 10% of the local
slope spread expressed as delay motion over the half-window. Require the
motion to exceed the numerical observation allowance. Fit the accepted affine
trend and its scatter to these distributed short-window delays, not the
possibly aliased long-window anchors. The original slope, delay and overlap
bounds still apply. If neither clock check passes, speed and digital-reference
timing drift are unavailable. Alignment may still be usable for a sample-grid
comparison, under the following deliberately narrow exception.

**Uncertified clock, supported integer grid.** After clock rejection only,
consider the rounded midpoint lag. Require each retained refined anchor and
the candidate affine lag at both record endpoints to lie within 0.01 frame
of this one integer. At every retained anchor, evaluate gain-fitted residual
power directly on the same samples for the integer hypothesis and both the
fitted affine and individually refined lag hypotheses (using the fitted
slope). Require finite integer residual/reference power no greater than 1.05
times the better fractional objective (about 0.212 dB excess power ratio
in dB). There is no absolute per-anchor residual ceiling: a quiet passage
can have greater relative quantization noise while still identifying the
grid. Each adjacent integer lag must
have more than four times the integer residual power, with a 1e-29 power
floor for this neighbor test. Retain the original distributed-anchor and
overlap checks; require whole-overlap sampled correlation magnitude at least
0.99999. These conservative evidence thresholds were chosen for close PCM
matches such as requantization, not as a universal speed deadband or as a
classifier for arbitrary mastering effects. The validated clock always has
priority, including resolvable sub-ppm slopes.

A supported integer fallback uses the original samples without interpolation
and can report null depth, rolling residual and unambiguous polarity/channel
results; it cannot certify zero speed or a drift trend. If the grid also
fails, alignment-dependent measurements remain unavailable. Tonal balance
and same-audio classification do not use this gate. No finite pair comparison
can separate every possible frequency-dependent phase change from true clock
motion; these are sufficient evidence checks for the tested classes of
material, not a general filter-identification method.

The sign of the common gain is free, with optional stereo permutation;
multichannel samples retain their declared order. Different channel counts
cannot be aligned in the sample domain. There is no extrapolation or padding.
`AlignmentSupport` identifies the overlap and whether interpolation was used.

Fractional positions use a normalized 256-tap beta-16 Kaiser-windowed sinc
with 8192 phase intervals and linear interpolation between phases. The
half-phase table is mirrored. Integer positions read the original samples
exactly. This is a finite-band measurement evaluator, not a claim about the
unknown continuous waveform or a replacement for sample-rate conversion.
The independent design-model sine tests at the stated fractional phases
measure worst residuals below -150 dB through 0.95 of Nyquist, but around
-10 dB at 0.99 of Nyquist. These are fixture results, not a uniform error
bound, and do not establish the native implementation's accuracy. Fractional
nulls include the evaluator error, clock-fit error and any sample-domain
aliasing; do not interpret deep fractional nulls as physical cancellation
below these effects. The caller may compare consistently bandlimited material
when this distinction matters. Exact integer comparisons avoid interpolation.

### Null depth

On the aligned common support, fit one signed amplitude gain g applied to B
by minimizing sum((A - gB)^2). Report 10 log10(sum((A - gB)^2)/sum(A^2)).
A more negative value indicates closer agreement; negative infinity denotes
zero residual. A silent reference or no usable aligned support gives
`CantTell`. A track's reported alignment is also its null measurement support.
The album value pools residual and reference energies separately before taking
the ratio; it is not an average of dB values. A separate gain is fit per pair.

The implementation conditions amplitudes by powers of two, computes residuals
relative to a rational anchor gain with FMA product-error recovery and a
compensated least-squares correction, and accumulates scaled norms. It does
not subtract two nearly equal powers or square an unconditioned tiny residual.
An integer-aligned zero is certified by exact binary significand cross
products; a computed zero without that proof is unavailable. Very deep
residuals can still lose information in intermediate binary64 arithmetic,
particularly with extreme within-track amplitude ranges or subnormal products;
there is no universal numerical floor guarantee. The rational oracle checks
specific nonzero residuals to about -5421 dB, not all possible PCM. Existing
optional precision interfaces remain available, with their original feature
defaults; comparisons themselves use binary64 plus the exact integer test.

### Tonal balance

Use the existing complementary-window one-sided spectrum, averaged over real
frames and channels. The frequency grid is `rate / n` with n the next power
of two at or above ceil(rate/6). Apply the gain that matches B's integrated
BS.1770 loudness to A. If either integrated loudness is unavailable, use
broadband spectral RMS matching where both powers are nonzero. Expose this
normalization choice in the result. Each bin is B minus A in dB after gain;
positive values mean more energy in B. Include every bin from DC to Nyquist.
The headline selects the largest absolute difference among bins within 80 dB
of the maximum bin of at least one recording, retaining its sign and Hz.
Both-zero bins have no ratio; a nonzero-to-zero ratio is infinite. A silent
recording may make normalization unavailable. The outer result is still a
curve with typed unavailable values rather than a fabricated EQ difference.
Album spectra pool real-frame-weighted power for each side; album loudness
uses independently windowed tracks with common BS.1770 gating. No waveform
alignment is required. This is a content-dependent spectral comparison, not a
transfer-function measurement, and does not separate EQ from speed, edit,
arrangement or dynamics differences. FFT leakage and estimator variance limit
low-energy bins. No smoothing is applied.

### Speed

For the affine B-frame slope delta, report `-100*delta/(1+delta)` percent
and `-1200*ln(1+delta)/ln(2)` cents. Positive means B plays faster; cents are
pitch-equivalent for a speed change, not independently measured pitch. The
formulas avoid cancellation near zero. Include empirical fit scatter in
percentage points, not a statistical confidence interval. For supported
non-affine playback, the reported speed is the finite-record affine trend;
its scatter describes the departure of observed local delays from that trend,
not a resolved constant physical rate. Exact gain-only waveform matches with
sufficient varying material take the zero-clock path.
Short or constant material cannot establish a clock. A supported integer-grid
fallback also does not establish a physical clock; speed is `CantTell` even
when sample-domain cancellation is available. Minimum resolvable speed
is signal-, duration-, bandwidth- and estimator-dependent; the model checks
1e-7 and 1e-9 slope fixtures, not a universal sensitivity guarantee. Album
speed is the median percent (average middle pair for even counts), with cents
calculated from that percent.

### Polarity and channels

Evaluate both stereo orders and the global sign by normalized waveform
correlation over aligned support. Require magnitude >=0.75, consistent
per-channel signs and, for stereo, a difference >0.02 between the absolute
correlation scores of the two orders. Jointly negligible channels are excluded
from sign-consistency tests. This reports same, inverted, swapped, or swapped
and inverted. Mono can report same/inverted; more than two channels have no
unambiguous stereo-order classification. Dual mono or similarly correlated
channels may be indeterminate. Mixed sign changes or channel-dependent
processing may not fit the global mapping. Album reports mixed when known
track values disagree and unavailable if a required track is indeterminate.

### Same audio

Compare original decoded sample bit patterns in order (including signed zero),
with equal channel counts and lengths. Otherwise test whether a single positive
finite binary64 amplitude factor maps every sample of A to the exact rounded
binary64 value of B. The monotone intersection of gain rounding intervals
handles subnormal products when a direct candidate fails. If no such multiplier
exists, test exact rational proportionality by the same binary-significand
cross products used to certify integer-aligned nulls. This admits, for
example, decoded integer PCM scaled by exactly 7/10 even if neither adjacent
binary64 gain reproduces all rounded products. For that proof the public gain
is the nearest representable binary64 value of the exact ratio, not a claim
that multiplication by the reported gain recreates every bit. Gain is A to B;
compatible zero signs are required and muting to all zero is not classified
as a gain-only equivalent. This is not a perceptual equality or approximate
gain comparison. Delay, channel swapping,
polarity inversion and speed are not removed. Album reports distinct counts
for bit-identical and additional gain-only pairs, with the supplied total.

### Track levels

Album only. Obtain native BS.1770 integrated loudness for each A and B track.
Subtract the album-wide B-minus-A integrated loudness offset (from pooled,
independently windowed track energies, with common gating) from each B-minus-A
track difference. Report the largest absolute residual in dB. Missing finite
integrated loudness, including insufficient windows or silence, makes the
result unavailable. Track-level roles are required for multichannel loudness.
A single pair returns `NotApplicable` when this metric is selected.

### Timing drift

Only if the caller declares A digital and the clock trend is resolved. A
supported integer-grid fallback alone does not establish that trend. Remove
the validated affine trend.
Fit a local affine time map and scalar gain in nominal 4 ms windows at 2 ms
spacing (integer-frame geometry), rather than differencing 50 ms delay
observations. The fractional-delay evaluator supplies both its value and the
derivative of the tabulated phase interpolation. Project the gain column out
of the local lag/slope normal equations. The fit requires informative,
well-conditioned timing motion across the window. Report the maximum absolute
relative speed departure from the fitted affine speed in percent, using
`100*(global_delta - local_delta)/(1 + local_delta)`.

One 40 ms seed search establishes the initial unambiguous branch within about
3 ms of the affine prediction. Subsequent fits track that branch using the
preceding lag and slope, with bounded corrections and at most six updates
per window; there are no repeated broad searches. Use one informative channel
for the scan so channel-dependent phase cannot create a false timing jump.
Only scan common support after removing the margins required for interpolation
and the seed/search geometry. Reject loss of lock, insufficient local support,
excessive local lag or slope, and excessive shape discrepancy relative to
observed slope motion (20% mismatch scale over the half-window, with the
1e-6 frame observation allowance). Do not interpolate across unknown gaps or
report a small peak where timing evidence is absent. Exact gain-only matches
with enough varying material take the zero path. Album reports the maximum
track result. The 4,000,000 observation limit bounds work; the full scan is
performed only when drift is selected against a digital reference.

The intended unweighted wow/flutter band includes 1–40 Hz. The independent
model checks a 0.25% sinusoidal speed modulation at 1, 5, 10, 20 and 40 Hz at
8 kHz with two phases, and 20 and 40 Hz at 48 kHz. All measured peaks fall
within 1.5% relative error of the analytic peak. The public API native tests
use a 10% relative-error acceptance target for these fixtures; they still
require native execution. These are fixture results, not a universal bound
for arbitrary music, modulation amplitudes, or frequencies. Slower changes
require sufficiently long informative support; modulation above 40 Hz is
not qualified and may be attenuated or aliased. This is not an IEC/DIN
weighted meter. Nonlinear edits or analog reference drift cannot be attributed
to B by this algorithm.

### Residual over time

Use the same alignment and single fitted gain as null depth. Calculate the
residual/reference energy ratio in dB for one-second rolling windows at
half-second hops. Rational half-second bucket boundaries avoid accumulating
sample-rate rounding error. Include a shortened final window when needed to
cover the tail, or one shortened window for a short pair. No joint silence
windows enter the statistics; zero-reference windows containing residual have
an infinite ratio. Report lower empirical median, nearest-rank 99th percentile,
maximum, and informative window count. The album returns the entire summary
of the track whose maximum is highest. A 4,000,000-window limit bounds stored
statistics. Alignment failure and unresolved arithmetic propagate as for null
depth. Individual window estimates remain subject to the same arithmetic and
interpolation limits.
