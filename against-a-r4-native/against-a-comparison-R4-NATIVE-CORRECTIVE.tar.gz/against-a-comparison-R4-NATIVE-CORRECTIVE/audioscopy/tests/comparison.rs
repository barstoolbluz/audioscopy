// SPDX-License-Identifier: GPL-2.0-or-later
//! Analytic and adversarial checks for the additive comparison API.
use audioscopy::comparison::{
    compare, compare_album, Measurement as M, Measurements, Pair, PolarityAndChannels as P,
    Recording, ReferenceSource, SameAudio, TonalNormalization,
};
use audioscopy::{Encoding, Error, Format, Outcome};
use std::f64::consts::TAU;

fn format(rate: u32, channels: usize) -> Format {
    Format {
        sample_rate: rate,
        channels,
        encoding: Encoding::Float,
        loudness_roles: None,
    }
}
fn pair<'a>(f: &'a Format, a: &'a [f64], b: &'a [f64]) -> Pair<'a> {
    Pair {
        reference: Recording {
            format: f,
            samples: a,
        },
        recording: Recording {
            format: f,
            samples: b,
        },
        reference_source: ReferenceSource::Digital,
    }
}
fn value<T: std::fmt::Debug>(outcome: Outcome<T>) -> T {
    match outcome {
        Outcome::Value(v) => v,
        other => panic!("expected value, got {other:?}"),
    }
}
fn close(actual: f64, expected: f64, tolerance: f64) {
    assert!(
        (actual - expected).abs() <= tolerance,
        "{actual:.16e} vs {expected:.16e} (tol {tolerance:e})"
    );
}

// A deterministic continuous-time signal with several incommensurate chirps
// and a changing envelope. Not generated using the alignment interpolator.
fn wave(t: f64, channel: usize) -> f64 {
    let c = channel as f64;
    let env = 0.74 + 0.19 * (TAU * (0.71 * t + 0.07 * c)).sin();
    env * (0.18 * (TAU * ((113.7 + 67.3 * c) * t + 3.21 * t * t)).sin()
        + 0.12 * (TAU * ((379.1 + 47.2 * c) * t + 7.13 * t * t + 0.13 * c)).cos()
        + 0.08 * (TAU * ((727.3 + 83.2 * c) * t + 11.61 * t * t + 0.03)).sin()
        + 0.04 * (TAU * ((982.7 - 71.0 * c) * t + 2.17 * t * t + 0.19 * c)).cos())
}
fn fixture(rate: u32, frames: usize, channels: usize, clock: impl Fn(f64) -> f64) -> Vec<f64> {
    (0..frames)
        .flat_map(|i| {
            let t = clock(i as f64) / f64::from(rate);
            (0..channels).map(move |c| wave(t, c))
        })
        .collect()
}

#[test]
fn selection_input_and_provenance() {
    let f = format(8000, 1);
    let a = vec![0.2; 32];
    let r = compare(pair(&f, &a, &a), Measurements::default()).unwrap();
    assert_eq!(r.same_audio, Outcome::NotRequested);
    assert_eq!(r.alignment, Outcome::NotRequested);
    assert!(r.duration.agrees());
    let r = compare(pair(&f, &a, &a), Measurements::new(&[M::TrackLevels])).unwrap();
    assert_eq!(r.track_levels_db, Outcome::NotApplicable);
    assert_eq!(r.alignment, Outcome::NotRequested);
    let mut p = pair(&f, &a, &a);
    p.reference_source = ReferenceSource::AnalogOrUnknown;
    let r = compare(p, Measurements::new(&[M::TimingDrift])).unwrap();
    assert!(matches!(r.timing_drift_percent, Outcome::CantTell(_)));
    assert_eq!(r.alignment, Outcome::NotRequested);
    let other = format(16000, 1);
    p.recording.format = &other;
    assert!(matches!(
        compare(p, Measurements::default()),
        Err(Error::Configuration(_))
    ));
    assert!(matches!(
        compare(pair(&f, &a, &[f64::NAN]), Measurements::default()),
        Err(Error::InvalidSample(0))
    ));
    assert!(matches!(
        compare(pair(&f, &a, &[]), Measurements::default()),
        Err(Error::Empty)
    ));
    assert!(matches!(
        compare_album(&[], Measurements::all()),
        Err(Error::Empty)
    ));
    assert_eq!(audioscopy::Measurement::ALL.len(), 25);
    assert_eq!(M::ALL.len(), 8);
    for bits in 0..=u8::MAX {
        assert_eq!(Measurements::from_bits(bits).bits(), bits);
    }
}

#[test]
fn exact_identity_gain_channel_and_sign() {
    let f = format(8000, 2);
    let a = fixture(8000, 12000, 2, |i| i);
    let selected = Measurements::new(&[
        M::SameAudio,
        M::NullDepth,
        M::Speed,
        M::PolarityAndChannels,
        M::TimingDrift,
        M::ResidualOverTime,
    ]);
    let r = compare(pair(&f, &a, &a), selected).unwrap();
    assert_eq!(value(r.same_audio), SameAudio::Same);
    assert_eq!(value(r.null_depth_db), f64::NEG_INFINITY);
    assert_eq!(value(r.speed).percent, 0.0);
    assert_eq!(value(r.polarity_and_channels), P::Same);
    assert_eq!(value(r.timing_drift_percent), 0.0);
    assert_eq!(value(r.residual_over_time).worst_db, f64::NEG_INFINITY);
    assert!(!value(r.alignment).fractional);
    let gain: Vec<_> = a.iter().map(|x| x * 0.25).collect();
    let r = compare(pair(&f, &a, &gain), selected).unwrap();
    assert_eq!(value(r.same_audio), SameAudio::SameAfterGain { gain: 0.25 });
    assert_eq!(value(r.null_depth_db), f64::NEG_INFINITY);
    let swapped: Vec<_> = a
        .as_chunks::<2>()
        .0
        .iter()
        .flat_map(|&[l, r]| [-r, -l])
        .collect();
    let r = compare(pair(&f, &a, &swapped), selected).unwrap();
    assert_eq!(value(r.same_audio), SameAudio::Different);
    assert_eq!(value(r.polarity_and_channels), P::SwappedAndInverted);
    assert_eq!(value(r.null_depth_db), f64::NEG_INFINITY);
    let dual: Vec<_> = a
        .as_chunks::<2>()
        .0
        .iter()
        .flat_map(|&[l, _]| [l, l])
        .collect();
    let r = compare(pair(&f, &dual, &dual), selected).unwrap();
    assert!(matches!(r.polarity_and_channels, Outcome::CantTell(_)));
    assert_eq!(value(r.null_depth_db), f64::NEG_INFINITY);
    // A gain need not itself be representable to yield an exact mathematical null.
    let m = format(8000, 1);
    let a: Vec<_> = (0..8000).map(|i| ((i % 9) as f64 - 4.0) / 32.0).collect();
    let b: Vec<_> = a.iter().map(|x| x * 3.0).collect();
    let r = compare(pair(&m, &a, &b), Measurements::new(&[M::NullDepth])).unwrap();
    assert_eq!(value(r.null_depth_db), f64::NEG_INFINITY);
}

#[test]
fn exact_gain_subnormal_rounding_and_signed_zero() {
    let f = format(8000, 1);
    let t = f64::from_bits(1);
    let a: [f64; 6] = [1.0, 0.75, -0.5, 0.25, -0.0, 0.125];
    let b = a.map(|x| x * (3.0 * t));
    let r = compare(pair(&f, &a, &b), Measurements::new(&[M::SameAudio])).unwrap();
    let SameAudio::SameAfterGain { gain } = value(r.same_audio) else {
        panic!("gain-only match lost");
    };
    for (x, y) in a.into_iter().zip(b) {
        assert_eq!((x * gain).to_bits(), y.to_bits());
    }
    let r = compare(
        pair(&f, &[0.0], &[-0.0]),
        Measurements::new(&[M::SameAudio]),
    )
    .unwrap();
    assert_eq!(value(r.same_audio), SameAudio::Different);
    let r = compare(pair(&f, &[0.5], &[0.0]), Measurements::new(&[M::SameAudio])).unwrap();
    assert_eq!(value(r.same_audio), SameAudio::Different);
}

#[test]
fn deep_null_and_energy_weighted_album() {
    let f = format(8000, 1);
    let a: Vec<_> = (0..12000)
        .map(|i| [0.25, -0.5, 0.0, 0.125, 0.0][i % 5])
        .collect();
    let mut b: Vec<_> = a.iter().map(|x| x * 0.5).collect();
    // The perturbation lies at a reference zero. Its square underflows at
    // the last two depths, but its energy ratio must remain distinguishable.
    for exponent in [-35, -53, -600, -900] {
        b[2] = 2.0_f64.powi(exponent);
        let expected = 20.0 * (exponent as f64 + 1.0) * std::f64::consts::LOG10_2
            - 10.0 * a.iter().map(|x| x * x).sum::<f64>().log10();
        let selection = Measurements::new(&[M::NullDepth, M::ResidualOverTime, M::Speed]);
        let r = compare(pair(&f, &a, &b), selection).unwrap();
        close(value(r.null_depth_db), expected, 1e-6);
        assert!(!value(r.alignment).fractional);
        assert_eq!(value(r.speed).percent, 0.0);
        assert!(value(r.residual_over_time).worst_db > expected);
        let quieter: Vec<_> = a.iter().map(|x| x * 0.125).collect();
        let album =
            compare_album(&[pair(&f, &a, &b), pair(&f, &quieter, &quieter)], selection).unwrap();
        close(
            value(album.null_depth_db),
            expected - 10.0 * (1.0 + 1.0 / 64.0_f64).log10(),
            1e-6,
        );
    }
}

// Material whose period divides a sparse scan stride must still be seen to
// vary. 12000 frames would give a stride of 5 to a 1-in-2048 scan.
#[test]
fn periodic_material_is_not_mistaken_for_constant() {
    let f = format(8000, 1);
    let a: Vec<_> = (0..12000)
        .map(|i| [0.25, -0.5, 0.0, 0.125, 0.0][i % 5])
        .collect();
    let b: Vec<_> = a.iter().map(|x| x * 0.5).collect();
    let selection = Measurements::new(&[M::NullDepth, M::Speed, M::TimingDrift]);
    let r = compare(pair(&f, &a, &b), selection).unwrap();
    assert_eq!(value(r.null_depth_db), f64::NEG_INFINITY);
    assert_eq!(value(r.speed).percent, 0.0);
    assert_eq!(value(r.timing_drift_percent), 0.0);
}

#[test]
fn shifted_integer_alignment_and_duration() {
    let f = format(8000, 1);
    let a = fixture(8000, 24000, 1, |i| i);
    let mut b = vec![0.0; 19];
    b.extend(a.iter().map(|x| x * 0.5));
    let r = compare(
        pair(&f, &a, &b),
        Measurements::new(&[M::NullDepth, M::Speed, M::SameAudio]),
    )
    .unwrap();
    assert!(!r.duration.agrees());
    assert_eq!(value(r.same_audio), SameAudio::Different);
    let support = value(r.alignment);
    close(support.midpoint_delay_frames, 19.0, 1e-6);
    assert!(!support.fractional);
    assert_eq!(value(r.null_depth_db), f64::NEG_INFINITY);
    close(value(r.speed).percent, 0.0, 1e-10);
}

#[test]
fn fractional_and_small_clock_changes() {
    let f = format(8000, 1);
    let a = fixture(8000, 32000, 1, |i| i);
    for (delta, delay) in [
        (-0.003, 19.25),
        (0.002, -8.4),
        (1e-7, 0.0),
        (1e-9, 0.0),
        (-0.04, 0.0),
        (0.04, 0.0),
        (0.001, 3500.0),
        (0.0, 0.003),
    ] {
        let n = (a.len() as f64 * (1.0 + delta) + delay).round() as usize;
        let b = fixture(8000, n, 1, |i| (i - delay) / (1.0 + delta));
        let r = compare(
            pair(&f, &a, &b),
            Measurements::new(&[M::Speed, M::NullDepth]),
        )
        .unwrap();
        let expected = -100.0 * delta / (1.0 + delta);
        let s = value(r.speed);
        // Interpolation is finite-band, so large shifts have a looser bound.
        // The near-zero fixture tests ppm and sub-ppm observability.
        close(
            s.percent,
            expected,
            if delta.abs() < 1e-6 { 2e-8 } else { 0.002 },
        );
        close(
            s.cents,
            -1200.0 * delta.ln_1p() / std::f64::consts::LN_2,
            if delta.abs() < 1e-6 { 4e-7 } else { 0.04 },
        );
        assert!(value(r.null_depth_db) < -35.0);
        let support = value(r.alignment);
        assert!(support.fractional);
        if delta == 0.0 {
            close(support.midpoint_delay_frames, delay, 0.001);
        }
    }
}

#[test]
fn drift_against_digital_and_reject_unrelated() {
    let f = format(8000, 1);
    let a = fixture(8000, 32000, 1, |i| i);
    let amplitude = 3.0; // 0.375 ms, 0.2356% peak speed at 1 Hz
    let b = fixture(8000, 32000, 1, |i| i + amplitude * (TAU * i / 8000.0).sin());
    let r = compare(
        pair(&f, &a, &b),
        Measurements::new(&[M::TimingDrift, M::Speed]),
    )
    .unwrap();
    let drift = value(r.timing_drift_percent);
    assert!(
        (0.12..0.35).contains(&drift),
        "unexpected peak drift {drift}"
    );
    let unrelated: Vec<_> = (0..a.len())
        .map(|i| 0.2 * (TAU * 2100.123 * i as f64 / 8000.0).sin())
        .collect();
    let r = compare(
        pair(&f, &a, &unrelated),
        Measurements::new(&[M::Speed, M::NullDepth, M::ResidualOverTime]),
    )
    .unwrap();
    assert!(matches!(r.speed, Outcome::CantTell(_)));
    assert!(matches!(r.null_depth_db, Outcome::CantTell(_)));
    assert!(matches!(r.residual_over_time, Outcome::CantTell(_)));
}

#[test]
fn tonal_and_album_levels() {
    let f = format(8000, 1);
    let a = fixture(8000, 16000, 1, |i| i);
    let b: Vec<_> = a.iter().map(|x| x * 0.5).collect();
    let r = compare(pair(&f, &a, &b), Measurements::new(&[M::TonalBalance])).unwrap();
    assert_eq!(r.alignment, Outcome::NotRequested);
    let t = value(r.tonal_balance);
    assert_eq!(t.normalization, TonalNormalization::IntegratedLoudness);
    close(value(t.gain_db), -20.0 * 0.5_f64.log10(), 1e-6);
    assert!(value(value(t.largest).difference_db).abs() < 1e-5);
    assert_eq!(t.curve.first().unwrap().frequency_hz, 0.0);
    assert_eq!(t.curve.last().unwrap().frequency_hz, 4000.0);
    let c: Vec<_> = a.iter().map(|x| x * 0.25).collect();
    let select = Measurements::new(&[M::TrackLevels, M::TonalBalance, M::SameAudio]);
    let r = compare_album(&[pair(&f, &a, &b), pair(&f, &a, &c)], select).unwrap();
    // Identical tracks: all blocks are above both gates, so the album power
    // ratio is the mean of the two track power ratios, not the mean of dB.
    let offset = 10.0 * ((0.25 + 0.0625) / 2.0_f64).log10();
    close(
        value(r.track_levels_db),
        (20.0 * 0.25_f64.log10() - offset).abs(),
        1e-6,
    );
    let counts = value(r.same_audio);
    assert_eq!(
        (counts.same, counts.same_after_gain, counts.total),
        (0, 2, 2)
    );
    close(value(value(r.tonal_balance).gain_db), -offset, 1e-6);
    let silent = vec![0.0; a.len()];
    let t = value(
        compare(pair(&f, &a, &silent), Measurements::new(&[M::TonalBalance]))
            .unwrap()
            .tonal_balance,
    );
    assert_eq!(t.normalization, TonalNormalization::Unavailable);
    assert!(matches!(t.gain_db, Outcome::CantTell(_)));
    assert_eq!(t.curve.len(), 1025);
}

#[test]
fn exact_rational_pcm_gain_not_representable_as_binary64() {
    // D-02: every pair is exactly proportional by 7/10, although neither
    // neighboring binary64 multiplier reproduces all rounded products.
    let a = [2560, 23040, -2560, -23040, 0].map(|x| f64::from(x) / 32768.0);
    let b = [1792, 16128, -1792, -16128, 0].map(|x| f64::from(x) / 32768.0);
    let selected = Measurements::new(&[M::SameAudio, M::NullDepth]);
    for encoding in [Encoding::Integer(16), Encoding::Float] {
        let f = Format {
            encoding,
            ..format(8000, 1)
        };
        let r = compare(pair(&f, &a, &b), selected).unwrap();
        assert_eq!(value(r.same_audio), SameAudio::SameAfterGain { gain: 0.7 });
        assert_eq!(value(r.null_depth_db), f64::NEG_INFINITY);
        let support = value(r.alignment);
        assert!(!support.fractional);
        assert_eq!(support.compared_frames, 5);
        assert_eq!(support.midpoint_delay_frames, 0.0);
        let album = compare_album(&[pair(&f, &a, &b)], selected).unwrap();
        let counts = value(album.same_audio);
        assert_eq!(
            (counts.same, counts.same_after_gain, counts.total),
            (0, 1, 1)
        );
        assert_eq!(value(album.null_depth_db), f64::NEG_INFINITY);
        let mut changed = b;
        changed[0] += 1.0 / 32768.0;
        let r = compare(pair(&f, &a, &changed), Measurements::new(&[M::SameAudio])).unwrap();
        assert_eq!(value(r.same_audio), SameAudio::Different);
        let mut zero_sign = b;
        zero_sign[4] = -0.0;
        let r = compare(pair(&f, &a, &zero_sign), Measurements::new(&[M::SameAudio])).unwrap();
        assert_eq!(value(r.same_audio), SameAudio::Different);
    }
}

fn flutter_fixture(rate: u32, frames: usize, frequency: f64, phase: f64) -> Vec<f64> {
    // Analytic instantaneous playback speed: 1 + .0025*cos(2*pi*f*t+phase).
    // This oracle does not use the production interpolation or timing model.
    let amplitude = 0.0025 * f64::from(rate) / (TAU * frequency);
    fixture(rate, frames, 1, |i| {
        i + amplitude * (TAU * frequency * i / f64::from(rate) + phase).sin()
    })
}

#[test]
fn wow_and_flutter_through_40_hz() {
    // D-01: each frequency has the same analytic peak. In R1 the 20 Hz
    // modulation aliases onto the old 50 ms observation grid.
    let selected = Measurements::new(&[M::TimingDrift, M::Speed]);
    for (rate, frequencies, phases) in [
        (
            8000_u32,
            &[1.0, 5.0, 10.0, 20.0, 40.0][..],
            &[0.0, 0.91][..],
        ),
        (48000_u32, &[20.0, 40.0][..], &[0.37][..]),
    ] {
        let f = format(rate, 1);
        let n = rate as usize * 4;
        let a = fixture(rate, n, 1, |i| i);
        for &frequency in frequencies {
            for &phase in phases {
                let b = flutter_fixture(rate, n, frequency, phase);
                let r = compare(pair(&f, &a, &b), selected).unwrap();
                let peak = value(r.timing_drift_percent);
                assert!(
                    (peak - 0.25).abs() <= 0.025,
                    "rate {rate}, {frequency} Hz, phase {phase}: peak {peak}%"
                );
                assert!(matches!(r.speed, Outcome::Value(_)));
                assert!(matches!(r.alignment, Outcome::Value(_)));
            }
        }
        // A constant affine rate is not wow/flutter; use a fractional offset
        // so this control cannot pass merely through the exact identity path.
        let delta = 0.002;
        let delay = 3.25;
        let b = fixture(
            rate,
            (n as f64 * (1.0 + delta) + delay).round() as usize,
            1,
            |i| (i - delay) / (1.0 + delta),
        );
        let r = compare(pair(&f, &a, &b), selected).unwrap();
        close(
            value(r.speed).percent,
            -100.0 * delta / (1.0 + delta),
            0.002,
        );
        assert!(value(r.timing_drift_percent) < 0.0005);
        let r = compare(pair(&f, &a, &a), selected).unwrap();
        assert_eq!(value(r.timing_drift_percent), 0.0);
        assert_eq!(value(r.speed).percent, 0.0);
    }
}

#[test]
fn drift_album_provenance_and_unobservable_gap() {
    let f = format(8000, 1);
    let a = fixture(8000, 32000, 1, |i| i);
    let b = flutter_fixture(8000, a.len(), 40.0, 0.91);
    let selected = Measurements::new(&[M::TimingDrift]);
    let track = compare(pair(&f, &a, &b), selected).unwrap();
    let peak = value(track.timing_drift_percent);
    let album = compare_album(&[pair(&f, &a, &a), pair(&f, &a, &b)], selected).unwrap();
    assert_eq!(value(album.timing_drift_percent), peak);
    let mut analog = pair(&f, &a, &b);
    analog.reference_source = ReferenceSource::AnalogOrUnknown;
    let r = compare(analog, selected).unwrap();
    assert!(matches!(r.timing_drift_percent, Outcome::CantTell(_)));
    assert_eq!(r.alignment, Outcome::NotRequested);
    let mut a = a;
    let mut b = b;
    // The gap is between widely separated alignment anchors. A scan must
    // not silently bridge an interval with no local timing information.
    a[9200..10200].fill(0.0);
    b[9200..10200].fill(0.0);
    let r = compare(pair(&f, &a, &b), selected).unwrap();
    assert!(matches!(r.timing_drift_percent, Outcome::CantTell(_)));
}

// D-03: a same-clock digital filter is not a clock warp. This continuous
// multicomponent sweep varies the filter's group-delay weighting over time.
fn clock_sweep(t: f64) -> f64 {
    0.4 * (TAU * (150.0 * t + 80.0 * t * t)).sin()
        + 0.15 * (TAU * (280.0 * t + 95.0 * t * t)).cos()
        + 0.07 * (TAU * (400.0 * t + 120.0 * t * t)).sin()
}

fn butterworth_lowpass(samples: &[f64], rate: u32, cutoff: f64) -> Vec<f64> {
    // Second-order Butterworth, bilinear transform with frequency prewarp;
    // fixed causal coefficients, zero initial state, no change of sample clock.
    let k = (std::f64::consts::PI * cutoff / f64::from(rate)).tan();
    let q = std::f64::consts::SQRT_2 * k;
    let norm = 1.0 / (1.0 + q + k * k);
    let b0 = k * k * norm;
    let a1 = 2.0 * (k * k - 1.0) * norm;
    let a2 = (1.0 - q + k * k) * norm;
    let (mut z1, mut z2) = (0.0, 0.0);
    samples
        .iter()
        .map(|&x| {
            let y = b0 * x + z1;
            z1 = 2.0 * b0 * x - a1 * y + z2;
            z2 = b0 * x - a2 * y;
            y
        })
        .collect()
}

#[test]
fn filter_phase_does_not_certify_a_small_clock_slope() {
    let selected =
        Measurements::new(&[M::Speed, M::NullDepth, M::TimingDrift, M::ResidualOverTime]);
    for rate in [8000_u32, 48000] {
        let f = format(rate, 1);
        let n = rate as usize * 4;
        let a: Vec<_> = (0..n)
            .map(|i| clock_sweep(i as f64 / f64::from(rate)))
            .collect();
        // Unfiltered, same-clock control.
        let r = compare(pair(&f, &a, &a), selected).unwrap();
        assert_eq!(value(r.speed).percent, 0.0);
        assert_eq!(value(r.null_depth_db), f64::NEG_INFINITY);
        assert_eq!(value(r.timing_drift_percent), 0.0);
        for cutoff in [1000.0, 3000.0] {
            let b = butterworth_lowpass(&a, rate, cutoff);
            let r = compare(pair(&f, &a, &b), selected).unwrap();
            // The conservative policy rejects these phase-ambiguous pairs.
            // The exact sample clock is unchanged, not a nonzero ppm shift.
            assert!(
                matches!(&r.speed, Outcome::CantTell(_)),
                "rate {rate}, cutoff {cutoff}: {:?}",
                r.speed
            );
            assert!(matches!(r.null_depth_db, Outcome::CantTell(_)));
            assert!(matches!(r.timing_drift_percent, Outcome::CantTell(_)));
            assert!(matches!(r.residual_over_time, Outcome::CantTell(_)));
            assert!(matches!(r.alignment, Outcome::CantTell(_)));
            // Requesting only null or only drift must not bypass the clock gate.
            for m in [M::NullDepth, M::TimingDrift] {
                let r = compare(pair(&f, &a, &b), Measurements::new(&[m])).unwrap();
                assert!(matches!(r.alignment, Outcome::CantTell(_)));
            }
            let r = compare(
                pair(&f, &a, &b),
                Measurements::new(&[M::SameAudio, M::TonalBalance]),
            )
            .unwrap();
            assert_eq!(r.alignment, Outcome::NotRequested);
            assert_eq!(value(r.same_audio), SameAudio::Different);
            assert!(matches!(r.tonal_balance, Outcome::Value(_)));
        }
        // An actual affine clock change plus ordinary EQ. Resolve it only
        // where supported; otherwise all clock-dependent alignment is absent.
        let delta = 0.002;
        let warped: Vec<_> = (0..(n as f64 * (1.0 + delta)).round() as usize)
            .map(|i| clock_sweep(i as f64 / (f64::from(rate) * (1.0 + delta))))
            .collect();
        let b = butterworth_lowpass(&warped, rate, 1000.0);
        let r = compare(pair(&f, &a, &b), selected).unwrap();
        match r.speed {
            Outcome::Value(speed) => {
                close(speed.percent, -100.0 * delta / (1.0 + delta), 0.002);
                assert!(matches!(r.alignment, Outcome::Value(_)));
                assert!(matches!(r.null_depth_db, Outcome::Value(_)));
                // Drift can be independently unavailable if local phase
                // evidence is insufficient even with a qualified affine fit.
            }
            Outcome::CantTell(_) => {
                assert!(matches!(r.alignment, Outcome::CantTell(_)));
                assert!(matches!(r.null_depth_db, Outcome::CantTell(_)));
                assert!(matches!(r.timing_drift_percent, Outcome::CantTell(_)));
            }
            other => panic!("unexpected speed outcome {other:?}"),
        }
    }
}

#[test]
fn original_multichirp_eq_is_not_clock_motion() {
    let f = format(8000, 1);
    let a = fixture(8000, 32000, 1, |i| i);
    for cutoff in [1000.0, 3000.0] {
        let b = butterworth_lowpass(&a, 8000, cutoff);
        let r = compare(
            pair(&f, &a, &b),
            Measurements::new(&[M::Speed, M::NullDepth, M::TimingDrift]),
        )
        .unwrap();
        assert!(matches!(r.speed, Outcome::CantTell(_)));
        assert!(matches!(r.null_depth_db, Outcome::CantTell(_)));
        assert!(matches!(r.timing_drift_percent, Outcome::CantTell(_)));
    }
}

// R2-AUD-01: a shared sample grid can be well established even though
// waveform noise prevents certification of a physical clock trend.
fn quantize_pcm(x: f64, bits: i32) -> f64 {
    let scale = 2.0_f64.powi(bits - 1);
    (x * scale).round_ties_even() / scale
}

fn uniform_dither(state: &mut u64) -> f64 {
    // Two separately seeded SplitMix64 streams; high 53 bits map into [0,1).
    // No dependency on a platform RNG or on the production estimator.
    *state = state.wrapping_add(0x9e37_79b9_7f4a_7c15);
    let mut z = *state;
    z = (z ^ (z >> 30)).wrapping_mul(0xbf58_476d_1ce4_e5b9);
    z = (z ^ (z >> 27)).wrapping_mul(0x94d0_49bb_1331_11eb);
    z ^= z >> 31;
    (z >> 11) as f64 * (1.0 / 9007199254740992.0)
}

// Independent ordinary least-squares oracle; these PCM nulls are well above
// binary64's arithmetic floor. Use one fitted gain over the entire support,
// then the specified one-second windows at half-second spacing, not a fresh
// fit in each window. No calls to production alignment or energy helpers.
fn direct_pcm_oracle(a: &[f64], b: &[f64], rate: usize) -> (f64, Vec<f64>) {
    assert_eq!(a.len(), b.len());
    let bb = b.iter().map(|y| y * y).sum::<f64>();
    let ab = a.iter().zip(b).map(|(x, y)| x * y).sum::<f64>();
    let gain = ab / bb;
    let depth = |start: usize, end: usize| {
        let aa = a[start..end].iter().map(|x| x * x).sum::<f64>();
        let rr = a[start..end]
            .iter()
            .zip(&b[start..end])
            .map(|(x, y)| (x - gain * y).powi(2))
            .sum::<f64>();
        10.0 * (rr / aa).log10()
    };
    // All fixtures here have exactly four seconds of support, at even rates.
    let mut windows: Vec<_> = (0..=a.len() - rate)
        .step_by(rate / 2)
        .map(|i| depth(i, i + rate))
        .collect();
    windows.sort_by(f64::total_cmp);
    (depth(0, a.len()), windows)
}

fn assert_requantized_grid(p: Pair<'_>, delay: usize, check_album: bool) {
    let a = p.reference.samples;
    let b = &p.recording.samples[delay..delay + a.len()];
    let (expected, windows) = direct_pcm_oracle(a, b, p.reference.format.sample_rate as usize);
    let selected = Measurements::new(&[
        M::NullDepth,
        M::ResidualOverTime,
        M::Speed,
        M::TimingDrift,
        M::PolarityAndChannels,
        M::SameAudio,
    ]);
    let r = compare(p, selected).unwrap();
    let support = value(r.alignment);
    assert!(!support.fractional);
    assert_eq!(support.first_reference_frame, 0);
    assert_eq!(support.compared_frames, a.len() as u64);
    assert_eq!(support.midpoint_delay_frames, delay as f64);
    close(value(r.null_depth_db), expected, 0.1);
    assert!(matches!(r.speed, Outcome::CantTell(_)));
    assert!(matches!(r.timing_drift_percent, Outcome::CantTell(_)));
    assert_eq!(value(r.same_audio), SameAudio::Different);
    assert_eq!(value(r.polarity_and_channels), P::Same);
    let summary = value(r.residual_over_time);
    assert_eq!(summary.windows, windows.len());
    close(summary.median_db, windows[(windows.len() - 1) / 2], 0.1);
    close(
        summary.percentile_99_db,
        windows[(99 * windows.len()).div_ceil(100) - 1],
        0.1,
    );
    close(summary.worst_db, *windows.last().unwrap(), 0.1);
    if check_album {
        let null_only = compare(p, Measurements::new(&[M::NullDepth])).unwrap();
        assert_eq!(value(null_only.alignment), support);
        close(value(null_only.null_depth_db), expected, 0.1);
        assert_eq!(null_only.speed, Outcome::NotRequested);
        assert_eq!(null_only.timing_drift_percent, Outcome::NotRequested);
        assert_eq!(null_only.residual_over_time, Outcome::NotRequested);
        let exact = pair(p.reference.format, a, a);
        let album = compare_album(&[p, exact], selected).unwrap();
        // The exact track adds equal reference energy but no residual.
        close(
            value(album.null_depth_db),
            expected - 10.0 * 2.0_f64.log10(),
            0.1,
        );
        assert_eq!(value(album.polarity_and_channels), P::Same);
        assert_eq!(value(album.residual_over_time), summary);
        let counts = value(album.same_audio);
        assert_eq!(
            (counts.same, counts.same_after_gain, counts.total),
            (1, 0, 2)
        );
        assert!(matches!(album.speed, Outcome::CantTell(_)));
        assert!(matches!(album.timing_drift_percent, Outcome::CantTell(_)));
    }
}

#[test]
fn requantized_pcm_preserves_integer_alignment_without_certifying_speed() {
    let rate = 44100;
    let f24 = Format {
        encoding: Encoding::Integer(24),
        ..format(rate, 1)
    };
    let f16 = Format {
        encoding: Encoding::Integer(16),
        ..format(rate, 1)
    };
    let a: Vec<_> = fixture(rate, rate as usize * 4, 1, |i| i)
        .into_iter()
        .map(|x| quantize_pcm(x, 24))
        .collect();
    let nearest: Vec<_> = a.iter().map(|&x| quantize_pcm(x, 16)).collect();
    let (mut u1, mut u2) = (13_u64, 14_u64);
    let dithered: Vec<_> = a
        .iter()
        .map(|&x| {
            (x * 32768.0 + uniform_dither(&mut u1) - uniform_dither(&mut u2)).round_ties_even()
                / 32768.0
        })
        .collect();
    for (samples, check_album) in [(&nearest[..], true), (&dithered[..], false)] {
        let p = Pair {
            reference: Recording {
                format: &f24,
                samples: &a,
            },
            recording: Recording {
                format: &f16,
                samples,
            },
            reference_source: ReferenceSource::Digital,
        };
        assert_requantized_grid(p, 0, check_album);
    }
    let f = format(48000, 1);
    let f24 = Format {
        encoding: Encoding::Integer(24),
        ..format(48000, 1)
    };
    let a = fixture(48000, 192000, 1, |i| i);
    let b: Vec<_> = a.iter().map(|&x| quantize_pcm(x, 24)).collect();
    let p = Pair {
        reference: Recording {
            format: &f,
            samples: &a,
        },
        recording: Recording {
            format: &f24,
            samples: &b,
        },
        reference_source: ReferenceSource::Digital,
    };
    assert_requantized_grid(p, 0, false);
}

#[test]
fn shifted_requantized_pcm_keeps_its_integer_grid() {
    let rate = 8000;
    let f24 = Format {
        encoding: Encoding::Integer(24),
        ..format(rate, 1)
    };
    let f16 = Format {
        encoding: Encoding::Integer(16),
        ..format(rate, 1)
    };
    let a: Vec<_> = fixture(rate, rate as usize * 4, 1, |i| i)
        .into_iter()
        .map(|x| quantize_pcm(x, 24))
        .collect();
    let mut b = vec![0.0; 19];
    b.extend(a.iter().map(|&x| quantize_pcm(x, 16)));
    let p = Pair {
        reference: Recording {
            format: &f24,
            samples: &a,
        },
        recording: Recording {
            format: &f16,
            samples: &b,
        },
        reference_source: ReferenceSource::Digital,
    };
    assert_requantized_grid(p, 19, false);
}

// R3-AUD-01: quantization residual is not a local alignment ceiling.
// These fixtures retain a distinguishable integer grid even when the
// relative residual at one or every anchor exceeds the former -60 dB gate.
#[test]
fn quiet_requantized_pcm_keeps_supported_integer_grid() {
    let rate = 44100;
    let f24 = Format {
        encoding: Encoding::Integer(24),
        ..format(rate, 1)
    };
    let f16 = Format {
        encoding: Encoding::Integer(16),
        ..format(rate, 1)
    };
    let base = fixture(rate, rate as usize * 4, 1, |i| i);
    // Include a normal-level control and both dithered and undithered
    // quiet material. The dynamic case has a quiet plateau at 2 s, with
    // 50 ms ramps, covering the middle retained alignment anchor.
    for (level, dither, dynamic) in [
        (1.0, true, false),
        (0.1, true, false),
        (0.03162277660168379, false, false),
        (1.0, true, true),
    ] {
        let a: Vec<_> = base
            .iter()
            .enumerate()
            .map(|(i, &x)| {
                let t = i as f64 / f64::from(rate);
                let envelope = if dynamic {
                    0.1 + 0.9 * (((t - 2.0).abs() - 0.15) / 0.05).clamp(0.0, 1.0)
                } else {
                    1.0
                };
                quantize_pcm(x * level * envelope, 24)
            })
            .collect();
        let (mut u1, mut u2) = (13_u64, 14_u64);
        let b: Vec<_> = a
            .iter()
            .map(|&x| {
                if dither {
                    (x * 32768.0 + uniform_dither(&mut u1) - uniform_dither(&mut u2))
                        .round_ties_even()
                        / 32768.0
                } else {
                    quantize_pcm(x, 16)
                }
            })
            .collect();
        let p = Pair {
            reference: Recording {
                format: &f24,
                samples: &a,
            },
            recording: Recording {
                format: &f16,
                samples: &b,
            },
            reference_source: ReferenceSource::Digital,
        };
        assert_requantized_grid(p, 0, dynamic);
    }
}
