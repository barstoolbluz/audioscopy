# Against A, R4 cumulative R3-AUD-01 corrective candidate

Date: 2026-11-27

**Native corrective applied.** The first native x86-64 run of R4 failed.
`R4-NATIVE-CORRECTIVE.md` describes the four corrections, and
`evidence/R4-NATIVE-code-delta.patch` is the exact delta. The operator
script now also gates rustfmt and strict Clippy. The text below describes
R4 as delivered.

Start with `BRIEF.md` (unaltered embedded commission) and `CHECKPOINT.md`.
This is a complete cumulative corrective source delivery, **not a native-qualified
release**. The two native runs are outstanding. It implements the unchanged
Against A brief, preserves the independent R1 acceptance audit's three
corrections, preserves the R2-AUD-01 sample-grid correction, and removes
the erroneous per-anchor residual ceiling (R3-AUD-01). See
`R4-CORRECTIVE-REPORT.md` and the retained historical corrective reports.
It does not implement SDM research.

- `audioscopy/`: baseline f8e92e5 plus the additive comparison API, tests,
  benchmark and definitions. No dependency or feature changes.
- `true-peak/`: byte-identical baseline 6a2f8f8.
- `operator/qualify.sh`: native qualification and evidence packaging.
- `flake.nix`, `flake.lock`: complete pinned development/qualification shell;
  the lock is copied unchanged from the supplied crate.
- `evidence/`: actual offline design-model results, source integrity audit,
  and exact corrective code delta. The new native tests and corrective
  reference script run in the original qualification matrix.
- `R1-MANIFEST-SHA256.txt`, `R2-MANIFEST-SHA256.txt`,
  `R3-MANIFEST-SHA256.txt`: retained input manifests.
- `R2-AUDIT.md`: supplied focused corrective instruction, unchanged.
- `BASELINE-MANIFEST-SHA256.txt`, `INPUT-README.md`,
  `changes-since-cp13-r2/`: supplied baseline provenance.
- `MANIFEST-SHA256.txt`: current payload checksums (excludes itself).

Immediate corrective input R3 archive SHA-256:
`9cc4485f999c9769a07852f425a5ee5ce173c023ba89f9d04390f720f311c2aa`.
Prior corrective input R2 archive SHA-256:
`9a78a8d2d524da16799f347f9cc0e1fa85f1dfc2c59391c0517de5b0a6dd7b11`.
Prior corrective input R1 archive SHA-256:
`4d172d9e43b9f54c3649464d5b51347efda29235994dfaa66c1909933bf3e45d`.
Original baseline archive SHA-256:
`d236ce657de35203b0346154c071d1e78609ea87440a11d2b553aed7a3d5346f`.
Both crates and the additive source are GPL-2.0-or-later.

## Native operator instructions

On the intended physical host, unpack into a fresh directory, verify the
outer checksum, and enter the directory containing this README. Nix with
flakes enabled is a prerequisite; the shell supplies the pinned Rust, C,
Python and archive tools. Initial dependency fetches require access to the
locked sources. No existing working tree or Cargo lock is modified.

x86-64 Linux:

```bash
nix develop --no-update-lock-file path:. --command bash operator/qualify.sh x86_64-linux
```

Apple Silicon macOS (native arm64, not Rosetta):

```bash
nix develop --no-update-lock-file path:. --command bash operator/qualify.sh aarch64-darwin
```

Each command writes a uniquely named evidence archive and SHA-256 sidecar
beside the source directory, including host/toolchain information, stage
exit codes and logs, source manifest, and status. A nonzero exit or non-PASS
status means qualification has not passed. Both the established vectorizer-
disabled configuration and unmodified release codegen are recorded. The
baseline documents a compiler defect in the latter; a failure is not waived.
Interrupted shell runs attempt to package their partial evidence; an abrupt
SIGKILL or power loss may leave the temporary directory instead. Use an
optional second argument to the operator script for a different evidence
output directory outside the source tree.

Read `audioscopy/docs/measurements.md` before interpreting a comparison.
The independent Python oracles are not execution of the Rust implementation.
