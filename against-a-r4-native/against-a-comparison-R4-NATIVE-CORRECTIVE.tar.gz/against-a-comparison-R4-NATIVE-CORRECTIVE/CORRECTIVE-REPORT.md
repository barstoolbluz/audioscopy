# Against A R2: D-01 through D-03 corrective

Date: 2026-11-27

Input: `against-a-comparison-R1.tar.gz`, SHA-256
`4d172d9e43b9f54c3649464d5b51347efda29235994dfaa66c1909933bf3e45d`.
All 198 R1 payload checksums passed before modification. BRIEF.md is unchanged.
Authority: the user's independent acceptance audit of R1, D-01 through D-03.

**Status: corrective implementation candidate; native qualification open.**

## D-01: flutter measurement

The 50 ms lag grid and 40 ms averaging window suppressed or aliased ordinary
flutter. The full drift scan now uses centered, nominal 4 ms local affine fits
at 2 ms spacing. A bounded Gauss-Newton step eliminates the scalar gain column
and solves for local lag and slope together. The derivative comes from the
existing piecewise-linear fractional-phase table; value and derivative share
one tap traversal. The initial long-window search preserves the ambiguity check;
subsequent windows track the preceding branch within a bounded neighborhood.
The scan rejects insufficient conditioning, lost lock, excessive mismatch,
and discontinuity. It never bridges unobservable gaps. It keeps one channel
for phase consistency and retains the original digital-provenance gate, exact
match shortcut and worst-track album reducer. It does not run for unrequested
drift. See the measurement definitions for margins, limits and work bounds.

The independent model checks twelve analytic 0.25% flutter fixtures at 8 and
48 kHz, 1 through 40 Hz with multiple phases, and constant affine controls.
All twelve peak results fall within 1.5% relative error. The new native tests
require 10% relative error on those cases, preserve the existing 1 Hz test,
check exact and constant-affine clocks, and cover album maximum, analog
provenance and a gap with no local timing support.

## D-02: exact rational PCM gain

Preserve the exact bit-pattern category and the rounded binary64 multiplier
existence test, including the interval search for subnormal products. If the
rounded-product proof fails, use the existing integer-significand proportionality
predicate on the original samples. A nonzero anchor, compatible signs/zeros and
a finite positive reporting ratio are required. No tolerance, arbitrary
precision dependency or new public gain type is introduced. The same predicate
feeds the exact alignment shortcut, so the short gain-only pair can yield an
integer-aligned negative-infinity null. A rational gain is reported rounded to
binary64; the public gain need not recreate the samples under rounded multiplication.

The exact 7/10 rational counterexample and its one-LSB mutation are retained as
analytic oracles. Native tests use both Integer(16) and Float encodings, null
support, album count, signed zero and one-LSB rejection. The existing rounded
product, subnormal, muting, channel and inversion fixtures remain unchanged.

## D-03: ambiguous EQ phase and clock motion

Keep R1's coarse search, refined anchor candidate, integer alternative, support
and mapping. A low-scatter line no longer suffices for a clock. Validate the
candidate against timing-normalized waveform discrepancy in raw and
first-differenced projections, each with independent gain elimination. Require
mismatch to be small relative to the observed cumulative motion, with a frame
observation allowance rather than a universal ppm deadband. A nonlinear timing
fallback evaluates up to 35 short, nonuniformly offset local observations.
Require independently supported slope departures on both sides of the trend,
and shape agreement relative to that motion. Fit the accepted affine trend and
scatter to those local lags so aliased long-window anchors do not masquerade as
an accurately resolved fixed rate. This is bounded validation, not a full drift
scan. If validation fails, all alignment-dependent measurements share the same
unavailability state; tonal and same-audio-only work remains independent.

The model rejects same-clock causal second-order Butterworth 1 and 3 kHz
low-pass cases on the original multichirp and a changing-frequency multicomponent
sweep, including a 48 kHz sweep. It retains all seven original affine cases,
including slopes 1e-7 and 1e-9, and resolves the genuine 0.002 slope plus EQ
controls within the stated test tolerance. Native fixtures reproduce the
analytic timebase controls and causal filter operations. No arbitrary filter
identification, ppm deadband or new resampling subsystem is introduced.

The audit's separate `eq_speed_sweep_probe.py`, `drift_probe.py` and evidence
archive were not available in this session. The audit gives the exact PCM and
modulation equations, which are retained. The new sweep is a fully specified
representative discriminating fixture rather than a claim of byte-identical
reproduction of the missing EQ probe. Its original candidate false speeds
are about -0.000805164% and -0.0000433262% at 8 kHz. Both are rejected by the
corrective model. The test and independent script retain the exact new sweep
coefficients and filter specification.

## Scope and qualification

No existing single-recording implementation, true-peak file, Cargo manifest,
Cargo lock, Nix lock, feature default, or license was changed. No dependency
was added. The only production changes are in the additive comparison module.
The existing benchmark remains the native throughput gate's evidence source.
The updated operator includes the new reference model and all public API tests
in the original native default/minimal/all-feature matrix, with the established
LLVM workaround and unmodified-codegen retry.

The independent model is not an execution of the Rust library. Its analytic
truth values do not depend on the implementation. This environment has no Rust,
Cargo or Nix; Rust distribution DNS lookup also failed. Native compilation,
actual Rust tests, formatting/lint status, performance and the two physical
host qualification runs remain unverified. No native failure or pass is
invented. An unsupported clock is conservatively unavailable; the two
projection mismatch checks are sufficient evidence checks, not a universal
proof against arbitrary mastering phase. The qualified-by-model modulation
fixtures do not establish a universal music-dependent error bound or a weighted
IEC/DIN result. The full native runs and evidence archives are required before
release qualification.

See `evidence/comparison-corrective-reference.log`,
`evidence/R2-prior-comparison-reference.log`, `evidence/R2-source-integrity.txt`
and `CHECKPOINT.md`. The exact R1-to-R2 production/test delta is retained in
`evidence/R2-code-delta.patch`.
