# Brief: audioscopy, comparison measurements ("Against A")

Date: 2026-11-27

## Outcome

audioscopy measures one recording against a reference recording of the same
material, called A. It gains the eight comparison measurements below, to the
same standard of correctness, rigour and native qualification as its existing
25 single-recording measurements.

## What audioscopy is

audioscopy is a standalone, general-purpose library for audio measurement,
published on its own. Decoded samples go in, measurements come out. It never
opens a file and carries no resampler.

TonePoet is one consumer. It is not a dependency, and audioscopy is not
coupled to it. No TonePoet names, types or interface concepts appear in
audioscopy. The measurement definitions below come from TonePoet's inventory;
everything else in that inventory (columns, ticks, defaults, caches, presets,
graph popups, screens) belongs to TonePoet and is out of scope.

## Baseline

`main` of both repositories, which already contain the native-qualified
CP13-R2 source plus the default-feature changes made since:

- `github.com/barstoolbluz/audioscopy`, commit `f8e92e5`
- `github.com/barstoolbluz/true-peak`, commit `6a2f8f8`

## Measurements

Each measures a recording against A. "Album" means a set of track pairs.

| Measurement | Reports | Album value | Can't tell when |
|---|---|---|---|
| Null depth | How completely the recording cancels against A after matching time, gain and speed, in dB | Energy over all paired tracks | Tracks don't pair, or alignment fails |
| Tonal balance | Largest EQ difference against A at matched loudness, with its frequency, such as `+2.4 dB at 10 kHz`; also the full difference curve as numbers | Album spectra | Never. Meaningful only between versions of the same mix. |
| Speed | Speed difference against A, in percent and cents | Median track | Alignment fails |
| Polarity and channels | `same`, `inverted`, `swapped`, or both | `mixed` when tracks differ | Channels too alike to tell left from right |
| Same audio | `same` (decoded samples bit-identical), `same after a gain change` with the gain, or `different` | Count of pairs that are the same, such as `5 of 5 same` | Never |
| Track levels | Largest change in the per-track integrated-loudness difference against A, after removing the album-wide offset, in dB | Defined for albums only; not applicable to a single track | Tracks don't pair |
| Timing drift | Wow and flutter, as peak speed variation against A, in percent | Worst track | A is not a digital source |
| Residual over time | The difference against A in rolling windows: median, 99th percentile and worst, in dB | Worst track | As Null depth |

## Required properties

- The existing 25 measurements, their results and the existing public API are
  unchanged. The comparison measurements are additive.
- Comparison inputs share one sample rate. Different rates are a configuration
  error: the caller converts.
- Which recordings form an album, and which tracks pair, is the caller's
  decision. audioscopy computes album values from the pairs it is given and
  reports when paired tracks do not agree in duration.
- A measurement that cannot be determined reports `can't tell` with a one-line
  reason, never a fabricated value. Not-applicable, not-requested and
  can't-tell stay distinct.
- Requesting a subset of measurements does only the work that subset needs.
- Results are trustworthy across their full reported range, including very
  deep nulls and very small speed differences, and their limits are stated.
- Binary64 stays the default arithmetic. The existing precision options remain
  available and on by default, and the user can opt out.
- Every code path is selected by ISA, never by processor model. Every build
  compiles and selects a correct path on any CPU of a supported ISA.
- C compiler warnings are errors only when `AUDIOSCOPY_NATIVE_WERROR=1`.
- Both crates stay GPL-2.0-or-later.
- Every tool needed to build, test and qualify comes from the Nix flake.

## Delivery

Complete cumulative `audioscopy/` and `true-peak/` source trees, with frozen
dependency locks. An operator kit that qualifies them natively with one
command per architecture, on x86-64 Linux and on aarch64 macOS, and returns
an evidence archive with its checksum. Documentation of each new measurement's
definition and limitations, at the standard of `docs/measurements.md`.
