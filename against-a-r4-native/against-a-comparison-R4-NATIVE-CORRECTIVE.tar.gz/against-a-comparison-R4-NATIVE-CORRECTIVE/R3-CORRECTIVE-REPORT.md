# Against A R3: focused R2-AUD-01 corrective

Date: 2026-11-27

Input: `against-a-comparison-R2-AUD01-03.tar.gz`, SHA-256
`9a78a8d2d524da16799f347f9cc0e1fa85f1dfc2c59391c0517de5b0a6dd7b11`.
All 206 R2 payload checksums verified on a fresh extraction. Authority:
unchanged `BRIEF.md` and the supplied `R2-AUDIT.md`. Earlier corrections
D-01 through D-03 are retained. The earlier `CORRECTIVE-REPORT.md` is a
historical R2 record, not the current sample-grid policy.

**Status: implementation candidate; native qualification open.**

## R2-AUD-01: distinguish sample-grid support from clock certification

The physical clock validation function is unchanged. If it succeeds, use
its validated clock as before. Only after it rejects, consider a constant
integer lag from the existing midpoint estimate. The fallback uses the
existing refined, distributed anchors and does not perform a new search.

Require all refined lags and both affine endpoint lags to agree with one
integer within 0.01 frame. On each retained anchor, require directly measured,
gain-fitted integer-grid residual/reference power at most 1e-6 (-60 dB),
and no more than 1.05 times the smaller of the fitted affine and refined
anchor lag residual powers. Evaluate those powers directly, not as a
subtraction of almost equal correlations. Require each adjacent integer
lag to have greater than four times the integer residual power (with a
1e-29 power floor in this neighbor comparison). Retain existing overlap
and mapping checks, with sampled whole-overlap correlation magnitude at
least 0.99999 for this fallback. The 5% power allowance corresponds to
approximately 0.212 dB; the 8 kHz float-to-24 fixture required 4.45%, while
all 44.1 kHz audit cases needed less than 1.04% when compared to the better
of the two fractional candidates. This is not a speed deadband or universal
criterion for arbitrary material. It is a conservative sample-grid exception.

The integer fallback sets `speed_known=false` and does not create a
fractional sampler for the final model. Direct sample access, fitted residual
energy, rolling residuals and unambiguous polarity/channel mapping remain
available. Speed and digital-reference drift independently return `CantTell`
with reasons. The drift scan is not run without a resolved clock trend.
No new public types, dependencies, features, album rules or selection paths
are introduced. A failed integer fallback remains unavailable. Exact identity,
gain and clean integer/affine clock paths retain priority.

## Verification performed here

The existing complete R2 independent model suite and original comparison
reference suite passed. The extended model independently generated four-second
multichirp PCM and direct least-squares oracle values. It admitted ten
zero-lag requantization cases at 8, 44.1 and 48 kHz, including both the audit's
NumPy TPDF streams (13/14) and the native fixture's deterministic SplitMix64
streams. The 19-frame shifted requantization control passed. Six retained EQ
fixtures rejected both clock certification and the integer fallback; clean
1e-9 and 1e-7 slopes, a 0.003-frame fractional delay, and a genuine larger
slope remained validated clocks. All twelve prior 0.25% flutter cases and
original affine controls passed, and the exact 7/10 oracle still passed.

| Audit fixture, 44.1 kHz | Direct integer-grid oracle | Model decision |
|---|---:|---|
| 24-bit to 16-bit nearest | -83.075883438 dB | Grid 0, clock unresolved |
| 24-bit to 16-bit TPDF (NumPy) | -78.288631828 dB | Grid 0, clock unresolved |
| Float to 24-bit nearest | -131.223350401 dB | Grid 0, clock unresolved |

These are independent oracle values and model admission results, not
measurements made by the Rust binary. The logs also retain the direct
rolling-window median/p99/worst and pooled equal-energy exact+test null
oracles. The native public API fixtures check nearest and deterministic
TPDF quantization at 44.1 kHz, float-to-24 at 48 kHz, the 19-frame shift at
8 kHz, full grid support, null and rolling results against a direct oracle
within 0.1 dB, polarity, same-audio, independent speed/drift unavailability,
null-only selection, pooled album null and worst-track residual. The native
fractional controls assert interpolation remains selected, including the
small constant fractional-delay case. The original deep integer null and
gain fixtures remain present. The separate original audit probe scripts are
not supplied in this round; the exact specified requantization inputs are
reproduced by the independent model. The retained R2 EQ controls were rerun;
no new claim is made about executing the separate original audit EQ probe.

## Scope and gates

Only production file changed from R2: `audioscopy/src/comparison/align.rs`.
No changes to the previous 25 measurements, comparison public API and energy
arithmetic, true-peak, Cargo or Nix manifests/locks, licensing, or feature
defaults. The same native operator and benchmark remain the qualification
entry points. The new model cases run as part of the existing corrective
reference script. The operator's shell syntax passes. See
`evidence/R3-source-integrity.txt`, `evidence/R3-code-delta.patch`,
`evidence/R3-corrective-reference.log`, and
`evidence/R3-prior-comparison-reference.log`.

Rust, Cargo and Nix are unavailable here. Compilation, native tests, lint
status, runtime, and both physical-host qualification runs remain unverified.
The model does not establish native numerical equivalence or throughput.
No native pass or failure is claimed. Run the unchanged operator commands
in README.md on x86-64 Linux and aarch64 macOS; retain both evidence archives
and hashes. Investigate actual failures without reopening accepted findings
or broadening scope unnecessarily.
