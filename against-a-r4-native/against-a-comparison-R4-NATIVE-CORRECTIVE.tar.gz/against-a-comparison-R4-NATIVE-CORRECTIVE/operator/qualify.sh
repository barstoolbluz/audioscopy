#!/usr/bin/env bash
# SPDX-License-Identifier: GPL-2.0-or-later
# Run inside the pinned root Nix development shell. Every run has fresh evidence.
set -euo pipefail
root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)
expected=${1:?usage: qualify.sh x86_64-linux or aarch64-darwin [evidence-directory]}
case "$expected" in x86_64-linux|aarch64-darwin) ;; *) printf 'Unsupported system: %s\n' "$expected" >&2; exit 2;; esac
out=${2:-$(dirname "$root")}
mkdir -p -- "$out"
out=$(cd -- "$out" && pwd -P)
case "$out/" in "$root/"*) echo 'Evidence output must be outside the source tree' >&2; exit 2;; esac
work=$(mktemp -d "${TMPDIR:-/tmp}/against-a-qualification.XXXXXXXX")
run_id="against-a-${expected}-$(date -u +%Y%m%dT%H%M%SZ)-${work##*.}"
logs="$work/$run_id"
mkdir -p "$logs"
status=INCOMPLETE
failed=0
printf 'stage\texit_code\n' > "$logs/stages.tsv"
finish() {
    local rc=$?
    trap - EXIT
    set +e
    if [ "$rc" -ne 0 ] && [ "$status" = PASS ]; then status=FAIL; fi
    printf '%s\nexit=%s\n' "$status" "$rc" > "$logs/STATUS.txt"
    local artifact="$out/$run_id.tar.gz"
    if tar -C "$work" -czf "$artifact.tmp" "$run_id" && mv -- "$artifact.tmp" "$artifact" && (cd "$out" && sha256sum "$run_id.tar.gz" > "$run_id.tar.gz.sha256.tmp" && mv "$run_id.tar.gz.sha256.tmp" "$run_id.tar.gz.sha256"); then
        printf '\nEvidence: %s\nChecksum: %s.sha256\nStatus: %s\n' "$artifact" "$artifact" "$status"
        rm -rf -- "$work"
    else
        printf 'Evidence packaging failed; retained working files: %s\n' "$work" >&2
        rc=1
    fi
    exit "$rc"
}
trap finish EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
stage() {
    local name=$1 rc=0
    shift
    printf '\n=== %s ===\n' "$name"
    { printf '+ '; printf '%q ' "$@"; printf '\n'; "$@"; } > "$logs/$name.log" 2>&1 || rc=$?
    printf '%s\t%s\n' "$name" "$rc" >> "$logs/stages.tsv"
    tail -n 8 "$logs/$name.log"
    if [ "$rc" -ne 0 ]; then failed=1; fi
    printf '%s: exit %s\n' "$name" "$rc"
    return 0
}
cd "$root"
cp MANIFEST-SHA256.txt "$logs/source-manifest.sha256"
cp flake.lock "$logs/flake.lock"
export PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
export AUDIOSCOPY_NATIVE_WERROR=1 CARGO_INCREMENTAL=0
unset RUSTFLAGS CARGO_ENCODED_RUSTFLAGS CARGO_BUILD_TARGET
stage 00-source-manifest sha256sum -c MANIFEST-SHA256.txt
stage 01-host bash -c 'set -e; uname -a; rustc -vV; cargo -V; cc --version; python3 -V; python3 -c "import numpy, scipy, mpmath, math; print(numpy.__version__, scipy.__version__, mpmath.__version__); assert hasattr(math, chr(102)+chr(109)+chr(97))"; case "$1" in x86_64-linux) test "$(uname -s):$(uname -m)" = Linux:x86_64; rustc -vV | grep -Fx "host: x86_64-unknown-linux-gnu";; aarch64-darwin) test "$(uname -s):$(uname -m)" = Darwin:arm64; rustc -vV | grep -Fx "host: aarch64-apple-darwin";; esac; rustc -V | grep -E "^rustc 1\.99\.1( |$)"' _ "$expected"
if [ "$failed" -ne 0 ]; then status=FAIL; exit 1; fi
for crate in true-peak audioscopy; do
    stage "05-$crate-fmt" cargo fmt --manifest-path "$crate/Cargo.toml" --all -- --check
    for config in default minimal all; do
        flags=()
        case "$config" in minimal) flags+=(--no-default-features);; all) flags+=(--all-features);; esac
        stage "06-$crate-clippy-$config" env CARGO_TARGET_DIR="$work/target-$crate-clippy" cargo clippy --manifest-path "$crate/Cargo.toml" --locked --all-targets "${flags[@]}" -- -D warnings
    done
    for config in default minimal all; do
        flags=()
        case "$config" in minimal) flags+=(--no-default-features);; all) flags+=(--all-features);; esac
        stage "10-$crate-$config" env RUSTFLAGS='-C llvm-args=--vectorize-loops=false' CARGO_TARGET_DIR="$work/target-$crate-established" cargo test --manifest-path "$crate/Cargo.toml" --locked --release --no-fail-fast --all-targets "${flags[@]}"
    done
    stage "20-$crate-default-codegen" env CARGO_TARGET_DIR="$work/target-$crate-default" cargo test --manifest-path "$crate/Cargo.toml" --locked --release --no-fail-fast --all-targets
    stage "25-$crate-doc-tests" env RUSTFLAGS='-C llvm-args=--vectorize-loops=false' CARGO_TARGET_DIR="$work/target-$crate-established" cargo test --manifest-path "$crate/Cargo.toml" --locked --release --doc
 done
stage 30-true-peak-offline python3 -B true-peak/qualification/run_offline_qualification.py
for file in reference_checks audit_reference r2_reference r3_reference r4_reference r5_reference comparison_reference comparison_corrective_reference; do
    stage "40-$file" python3 -B "audioscopy/qualification/$file.py"
done
for rate in 48000 192000; do
    stage "50-comparison-bench-$rate" env RUSTFLAGS='-C llvm-args=--vectorize-loops=false' CARGO_TARGET_DIR="$work/target-audioscopy-established" cargo run --manifest-path audioscopy/Cargo.toml --locked --release --example comparison_bench -- "$rate" 6
done
stage 90-source-manifest sha256sum -c MANIFEST-SHA256.txt
if [ "$failed" -ne 0 ]; then status=FAIL; exit 1; fi
status=PASS
