# Against A R2: resumable corrective checkpoint

## Identity and authority

Input `against-a-comparison-R1.tar.gz`, SHA-256
`4d172d9e43b9f54c3649464d5b51347efda29235994dfaa66c1909933bf3e45d`.
Original input `against-a-bundle-2026-11-27.tar.gz`, SHA-256
`d236ce657de35203b0346154c071d1e78609ea87440a11d2b553aed7a3d5346f`.
Baseline audioscopy f8e92e5, true-peak 6a2f8f8. Authority is the unchanged
embedded BRIEF.md plus the supplied independent D-01..03 audit. This is not SDM
research. The R1 manifest verified before changes; its copy is retained.

## Implemented corrective scope

- D-01: 4 ms local affine observations every 2 ms, joint gain/lag/slope fit,
  shared sampler derivative, bounded tracking, observability and phase checks.
  Exact, provenance, album and selection semantics preserved.
- D-02: exact rational gain fallback using existing significand proof, shared
  with exact alignment. Preserve rounded-product and signed-zero behavior.
- D-03: validate candidate clock against two gain-projected timing-mismatch
  observations; bounded independent short-time validation for nonlinear
  timing and re-fit trend from accepted local lags. Reject ambiguous phase
  instead of using a false resolved rate for null or drift.
- Add focused public API tests, independent reference script, and native
  operator stage. Update definitions and performance documentation.

## Evidence and limitations

See CORRECTIVE-REPORT.md. Independent analytic/NumPy model tests exercise
1, 5, 10, 20 and 40 Hz modulation, 8/48 kHz, exact rational PCM, tiny affine
slopes, causal EQ and genuine clock-plus-EQ controls. The separate audit
probe scripts were not accessible; the causal EQ sweep is a reproducible
representative fixture. The model is not native Rust execution.

Rust, Cargo and Nix remain unavailable in this environment; toolchain server
DNS failed. Native build, tests, formatting/lints, actual runtime, full flake
evaluation, both physical host runs and default-codegen status are unverified.
No compiler failure or native pass is claimed. Do not label this qualified
until those gates pass. See the report for conservative phase ambiguity policy,
finite modulation band and content-dependent support limitations.

## Resume / handoff

Use this complete cumulative tree as the next baseline. Verify the current
MANIFEST-SHA256.txt and outer checksum. Do not reconstruct from chat history.
Run the two commands in README.md on the actual target hosts, collect both
evidence archives and SHA-256 sidecars. The new public API fixtures run within
the original default/minimal/all feature matrix. Inspect actual failures;
repair focused defects only. The previous 25 measurements, true-peak tree,
Cargo manifests/locks and Nix locks must remain unchanged absent a demonstrated
in-scope defect. Use the existing benchmark results to decide whether any
additional performance work is justified.
