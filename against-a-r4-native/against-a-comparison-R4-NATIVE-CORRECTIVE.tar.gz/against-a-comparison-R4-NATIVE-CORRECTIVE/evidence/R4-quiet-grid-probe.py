import comparison_corrective_reference as r
import numpy as np
import math
rate=44100;r.r1.RATE=rate
t=np.arange(4*rate)/rate
base=r.r1.wave(t)
# Plateau around central retained anchor; 50 ms linear ramps.
env=.1+.9*np.clip((np.abs(t-2)-.15)/.05,0,1)
u=r.splitmix_uniform(13,len(t))-r.splitmix_uniform(14,len(t))
for label,scale,dither in [('normal TPDF',1,True),('quiet TPDF',.1,True),('quiet nearest',.03162277660168379,False),('one quiet passage TPDF',env,True)]:
    a=np.round(base*scale*2**23)/2**23
    b=np.round(a*2**15+(u if dither else 0))/2**15
    off,d,anchors=r.r1.estimate(a,b)
    clock,why=r.observable(a,b,off,d,anchors,rate)
    grid,reason=r.integer_grid(a,b,off,d,anchors,rate)
    depth,_=r.pcm_oracle(a,b,rate)
    print(label,depth,clock,grid,reason,'max lag',max(abs(l) for _,l in anchors),flush=True)
    for c,l in anchors:
        def loss(lag,delta,sinc):return r.r1.loss(a,b,c,lag,delta,rate//100,1,sinc)
        il=loss(0,0,False); nl=min(loss(-1,0,False),loss(1,0,False)); fl=min(loss(off+d*(c-len(a)//2),d,True),loss(l,d,True))
        print(f'  {c/rate:.2f}s lag {l:.9g} loss {10*math.log10(il):.6f} dB neighbor ratio {nl/il:.6f} fractional ratio {il/fl:.9f}',flush=True)
