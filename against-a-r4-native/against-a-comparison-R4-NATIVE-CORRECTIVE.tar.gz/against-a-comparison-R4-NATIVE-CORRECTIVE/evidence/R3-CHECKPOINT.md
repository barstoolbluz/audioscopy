# Against A R3: resumable focused corrective checkpoint

## Identity

Immediate input: `against-a-comparison-R2-AUD01-03.tar.gz`, SHA-256
`9a78a8d2d524da16799f347f9cc0e1fa85f1dfc2c59391c0517de5b0a6dd7b11`.
Retained R1 and original input provenance is in README.md, historical
`CORRECTIVE-REPORT.md`, `evidence/R2-CHECKPOINT.md`, and the input manifests.
Authority: unchanged BRIEF.md and supplied R2-AUDIT.md. Scope: R2-AUD-01
only; preserve D-01..03 and the previous 25 single-recording measurements.

## Current implementation

After unchanged R2 clock validation rejects, test a tightly supported constant
integer grid on distributed refined anchors using direct residual powers and
existing overlap/mapping. A passing fallback uses direct sample access and
marks `speed_known=false`. Null/rolling/polarity results remain independent
of clock certification. Speed/drift are unavailable, not assumed zero.
No new public API, dependency, locks or broad search. The earlier exact and
validated fractional/affine paths take priority.

## Evidence

Read R3-CORRECTIVE-REPORT.md for thresholds, scope and actual results. The
extended reference suite (including retained D-01..03) and prior reference
suite passed; the complete model logs and source delta are under evidence/.
Native public API tests were added but could not be run here: Rust, Cargo,
Nix are absent. Native build/tests, lints, default-codegen status and actual
performance remain open. Both physical hosts must pass the existing
qualification gate before calling the implementation qualified.

## Resume

Use the entire cumulative tree. Verify its current payload manifest and outer
SHA-256, then execute the unchanged README.md commands on the two target
hosts. Collect both checksummed evidence archives. Do not treat reference
model results as native execution. Make only corrections supported by actual
failures. Prior R2 report and checkpoint are historical records; current
policy is described in R3-CORRECTIVE-REPORT.md and measurement definitions.
